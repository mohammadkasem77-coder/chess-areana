# CHESS ARENA v2 — Payload-First Security Specification

## 1. Data Invariants
1. **Default-Deny Catch-All**: Every path not explicitly permitted is denied.
2. **Unique Username Enforcement**: `/usernames/{usernameLower}` maps lowercase usernames (`^[a-z0-9_]+$`) strictly to the owning `uid`. Only the owner or an Admin may release/claim an existing username.
3. **Profile Privacy & Anti-Privilege-Escalation**: Users can edit customization fields (`displayName`, `bio`, `country`, `avatar`, `chessExperience`, `learningJourney`, `mentorName`, `favoritePlayer`, `favoriteOpening`, `profileTheme`, `profileFrame`, `privacySections`, `following`, `blockedUids`, `completedVideos`, `favoriteVideos`), but CANNOT set `isBanned`, `banReason`, `uid`, `playerId`, `createdAt`, or admin roles.
4. **PII Isolation**: Email and security metadata live solely in `/users/{userId}/private/{docId}` readable only by `isOwner(userId)` or `isAdmin()`.
5. **Room Chat & Spectator Separation**: `/room_chats/{messageId}` requires `senderUid == request.auth.uid`, valid `roomId`, bounded text (`<= 300`), and forbids client updates. List queries require `isSignedIn()` and evaluate `resource.data.roomId is string && resource.data.channel in ['room', 'spectator']` (and sender/admin delete only).
6. **Admin-Only Content & Immutable Audit Logs**: `/learning_videos`, `/announcements`, `/app_config` writes require `isAdmin()`. `/admin_logs` permits `create` and `read` only by `isAdmin()`, and strictly forbids `update` and `delete`.

## 2. The "Dirty Dozen" Payloads (Must All Return PERMISSION_DENIED)
1. **Privilege Escalation on User Create**: `{ uid: "u1", ..., isBanned: false, role: "super_admin" }` (ghost `role` field).
2. **Username Hijack**: User `u2` overwriting `/usernames/magnus` owned by `u1`.
3. **User Self-Unban**: Banned user `u1` sending `update` with `isBanned: false`.
4. **PII Blanket Read**: User `u2` calling `get` on `/users/u1/private/info`.
5. **Spoofed Room Chat Sender**: User `u2` creating `/room_chats/msg1` with `senderUid: "u1"`.
6. **Oversized Chat Payload (DoW)**: User `u1` sending `/room_chats/msg2` with `text` > 300 characters.
7. **Unverified Admin Email Spoof**: Unverified token (`email_verified: false`) attempting write to `/app_config/ui`.
8. **Non-Admin Learning Video Injection**: Regular user creating `/learning_videos/vid1`.
9. **Audit Log Tampering**: Even an admin attempting to `update` or `delete` `/admin_logs/log1`.
10. **Match History Forgery**: User `u3` creating `/matches/m1` where `whiteId: "u1"` and `blackId: "u2"`.
11. **Terminal Tournament Mutation**: User updating `/tournaments/t1` when `status == 'completed'`.
12. **ID Poisoning**: Creating document with 200-char ID or special characters `../admin`.
