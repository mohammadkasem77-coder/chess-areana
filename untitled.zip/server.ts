import express, { Request, Response, NextFunction } from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { WebSocketServer, WebSocket } from 'ws';
import { Chess } from 'chess.js';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const PORT = Number(process.env.PORT || 3000);
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'afifx';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'afifx1234';
const OWNER_ADMIN_EMAIL = 'mohammadkasem77@gmail.com';
const ADMIN_SECRET =
  process.env.ADMIN_SESSION_SECRET ||
  crypto.createHash('sha256').update(`${ADMIN_USERNAME}:${ADMIN_PASSWORD}:chess-arena`).digest('hex');

const DATA_DIR = path.resolve(process.cwd(), 'data');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
const STORE_FILE = path.join(DATA_DIR, 'arena-store.json');

let FIREBASE_API_KEY = '';
try {
  const fbCfgPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
  if (fs.existsSync(fbCfgPath)) {
    const fbCfg = JSON.parse(fs.readFileSync(fbCfgPath, 'utf-8')) as { apiKey?: string };
    FIREBASE_API_KEY = fbCfg.apiKey || '';
  }
} catch {
  // ignore
}

interface TimeControlPayload {
  id: string;
  label: string;
  category: string;
  initialSeconds: number;
  incrementSeconds: number;
}

interface PrivacySections {
  stats: boolean;
  matchHistory: boolean;
  achievements: boolean;
  learningJourney: boolean;
  friends: boolean;
  favoriteOpenings: boolean;
}

interface StoredUser {
  uid: string;
  playerId: string;
  username: string;
  displayName?: string;
  bio?: string;
  country: string;
  avatar: string;
  chessExperience?: string;
  learningJourney?: string;
  mentorName?: string;
  favoritePlayer?: string;
  favoriteOpening?: string;
  profileTheme?: string;
  profileFrame?: string;
  privacySections?: PrivacySections;
  rating: number;
  peakRating: number;
  puzzleRating: number;
  puzzlesSolved: number;
  xp: number;
  level: number;
  points: number;
  wins: number;
  losses: number;
  draws: number;
  winStreak: number;
  bestWinStreak: number;
  totalMoves: number;
  fastestWinSeconds: number;
  longestMatchSeconds: number;
  totalMatchDurationSeconds: number;
  isBanned: boolean;
  banReason?: string;
  privacyAllowMessages: 'everyone' | 'friends' | 'none';
  privacyAllowInvites: 'everyone' | 'friends' | 'none';
  lastUsernameChangeAt?: string;
  achievements: string[];
  following?: string[];
  blockedUids?: string[];
  completedVideos?: string[];
  favoriteVideos?: string[];
  createdAt: string;
  updatedAt: string;
  isGuest?: boolean;
}

interface StoredMatch {
  matchId: string;
  whiteId: string;
  whiteName: string;
  whiteRating: number;
  blackId: string;
  blackName: string;
  blackRating: number;
  pgn: string;
  fen: string;
  winner: 'white' | 'black' | 'draw';
  resultReason: string;
  timeControl: string;
  mode: string;
  durationSeconds: number;
  moveCount: number;
  ratingDeltaWhite: number;
  ratingDeltaBlack: number;
  createdAt: string;
}

interface RoomChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  role: 'player' | 'spectator' | 'system';
  channel?: 'room' | 'spectator';
  text: string;
  timestamp: string;
  emoji?: string;
}

interface RoomParticipant {
  uid: string;
  playerId: string;
  username: string;
  rating: number;
  country: string;
  avatar: string;
  role: 'player' | 'spectator';
  color?: 'w' | 'b';
  connected: boolean;
}

interface ServerRoom {
  roomId: string;
  roomName: string;
  ownerId: string;
  ownerName: string;
  gameMode: string;
  timeControl: TimeControlPayload;
  maxSpectators: number;
  passwordHash: string | null;
  allowSpectatorChat: boolean;
  status: 'waiting' | 'playing' | 'finished' | 'closed';
  chess: Chess;
  whiteTimeMs: number;
  blackTimeMs: number;
  lastMoveAt: number | null;
  startedAt: number | null;
  lastMove?: { from: string; to: string };
  winner?: 'white' | 'black' | 'draw';
  resultReason?: string;
  drawOfferFrom: string | null;
  participants: RoomParticipant[];
  chat: RoomChatMessage[];
  createdAt: string;
  isMatchmaking?: boolean;
  isTournamentMatch?: boolean;
  tournamentId?: string;
  tournamentMatchId?: string;
}

interface StoredTournament {
  tournamentId: string;
  title: string;
  format: 'knockout' | 'round_robin';
  visibility: 'public' | 'private';
  status: 'registration' | 'active' | 'completed';
  timeControl: string;
  maxPlayers: number;
  createdBy: string;
  creatorName: string;
  participants: string[];
  participantDetails: { uid: string; username: string; rating: number; country: string }[];
  matches: {
    id: string;
    round: number;
    whiteUid?: string;
    whiteName: string;
    blackUid?: string;
    blackName: string;
    winnerUid?: string;
    status: 'pending' | 'active' | 'completed';
    roomId?: string;
  }[];
  standings: {
    uid: string;
    username: string;
    rating: number;
    points: number;
    wins: number;
    draws: number;
    losses: number;
  }[];
  createdAt: string;
  updatedAt: string;
}

interface StoredReport {
  reportId: string;
  reporterUid: string;
  reportedPlayerId: string;
  reportedUsername?: string;
  reason: string;
  details: string;
  status: 'open' | 'reviewed' | 'resolved' | 'dismissed';
  createdAt: string;
  updatedAt: string;
}

interface StoredAnnouncement {
  announcementId: string;
  title: string;
  body: string;
  active: boolean;
  createdAt: string;
}

interface StoredLearningVideo {
  videoId: string;
  youtubeId?: string;
  playlistId?: string;
  title: string;
  description: string;
  category: string;
  author: string;
  isPlaylist: boolean;
  createdAt: string;
}

interface UiConfigState {
  siteTitle: string;
  heroHeadline: string;
  heroSubtitle: string;
  heroImageUrl?: string;
  accentColor: string;
  canvasColor: string;
  surfaceColor: string;
  defaultBoardTheme: string;
  defaultPieceStyle: string;
  bannerText: string;
  dailyTip?: string;
  allowGuestPlay: boolean;
  maintenanceMode: boolean;
  showLeaderboards: boolean;
  showTournaments: boolean;
  showTraining: boolean;
  showPlayersDirectory?: boolean;
  navLabels?: Record<string, string>;
  buttonLabels?: Record<string, string>;
  sectionOrder?: string[];
  updatedAt: string;
}

interface UiVersionSnapshot {
  versionId: string;
  savedBy: string;
  label: string;
  config: UiConfigState;
  createdAt: string;
}

type AdminRole = 'super_admin' | 'moderator';

interface StoredModerator {
  id: string;
  username: string;
  passwordHash: string;
  role: AdminRole;
  permissions: string[];
  createdAt: string;
  createdBy: string;
}

interface AuditLogEntry {
  logId: string;
  actor: string;
  actorRole: AdminRole;
  action: string;
  target?: string;
  details?: string;
  createdAt: string;
}

interface SuspiciousAlert {
  id: string;
  uid: string;
  username: string;
  reason: string;
  timestamp: string;
}

interface PersistedStore {
  users: Record<string, StoredUser>;
  matches: StoredMatch[];
  tournaments: StoredTournament[];
  reports: StoredReport[];
  announcements: StoredAnnouncement[];
  learningVideos: StoredLearningVideo[];
  suspiciousAlerts: SuspiciousAlert[];
  uiConfig: UiConfigState;
  uiDraftConfig: UiConfigState | null;
  uiVersions: UiVersionSnapshot[];
  moderators: StoredModerator[];
  auditLogs: AuditLogEntry[];
}

const DEFAULT_UI_CONFIG: UiConfigState = {
  siteTitle: 'CHESS ARENA',
  heroHeadline: 'Master the Board Across the Globe',
  heroSubtitle:
    'Compete in ranked worldwide matchmaking, private rooms, and grandmaster training with live synchronized clocks.',
  heroImageUrl: '/src/assets/images/hero_chess_arena_1794980498823.jpg',
  accentColor: '#D4AF37',
  canvasColor: '#0A0A0C',
  surfaceColor: '#141418',
  defaultBoardTheme: 'classic_wood',
  defaultPieceStyle: 'staunton',
  bannerText: '',
  dailyTip: 'Checks, Captures, Threats — scan forcing moves on every critical turn.',
  allowGuestPlay: true,
  maintenanceMode: false,
  showLeaderboards: true,
  showTournaments: true,
  showTraining: true,
  showPlayersDirectory: true,
  navLabels: {
    dashboard: 'Dashboard',
    play: 'Play Arena',
    players: 'Players',
    training: 'Learning',
    tournaments: 'Tournaments',
    leaderboards: 'Rankings',
  },
  buttonLabels: {
    playWorldwide: 'Play Worldwide',
    playComputer: 'Play vs Computer',
    privateRoom: 'Private Room',
    dailyPuzzle: 'Daily Puzzle',
  },
  sectionOrder: ['hero', 'metrics', 'challenges', 'matches', 'social', 'leaderboard', 'notifications'],
  updatedAt: new Date().toISOString(),
};

const DEFAULT_LEARNING_VIDEOS: StoredLearningVideo[] = [
  {
    videoId: 'vid_gotham_beginner',
    youtubeId: 'OCSbzArwB10',
    title: 'How To Play Chess: The Ultimate Beginner Guide',
    description: 'Complete walkthrough of chess board setup, piece movement, castling, en passant, and core strategy.',
    category: 'Beginner Chess Lessons',
    author: 'GothamChess',
    isPlaylist: false,
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    videoId: 'vid_rules_explained',
    youtubeId: 'RFiO0qWji7A',
    title: 'How To Play Chess (For Beginners)',
    description: 'Step-by-step explanation of piece rules, check, checkmate, draws, and practical opening habits.',
    category: 'Chess Rules Explained',
    author: 'Random Chess Person',
    isPlaylist: false,
    createdAt: '2026-01-02T00:00:00Z',
  },
  {
    videoId: 'vid_25_openings',
    youtubeId: 'Mlhye6n7ug4',
    title: '25 Opening Principles Every Chess Player Should Know!',
    description: 'Essential central control, piece mobilization, and king safety heuristics for consistent openings.',
    category: 'Opening Principles',
    author: 'Critical Chess',
    isPlaylist: false,
    createdAt: '2026-01-03T00:00:00Z',
  },
  {
    videoId: 'vid_e4_crush',
    youtubeId: 'Qdyik5UwBtM',
    title: 'Learn to CRUSH with 1. e4 | 10-Minute Chess Openings',
    description: 'Dynamic 1.e4 repertoire covering sharp tactical responses against 1...e5, c5, e6, and c6.',
    category: 'Opening Principles',
    author: 'GothamChess',
    isPlaylist: false,
    createdAt: '2026-01-04T00:00:00Z',
  },
  {
    videoId: 'vid_london_system',
    youtubeId: '49H728S_VjM',
    title: 'Learn the London System | 10-Minute Chess Openings',
    description: 'Build a reliable, blunder-resistant opening pyramid with 1.d4 and 2.Bf4.',
    category: 'Opening Principles',
    author: 'GothamChess',
    isPlaylist: false,
    createdAt: '2026-01-05T00:00:00Z',
  },
  {
    videoId: 'vid_caro_kann',
    youtubeId: 'rmbU97iftC8',
    title: 'Learn the Caro-Kann Defense | 10-Minute Chess Openings',
    description: 'Solid, counter-attacking defense as Black against 1.e4 built on resilient pawn structure.',
    category: 'Opening Principles',
    author: 'GothamChess',
    isPlaylist: false,
    createdAt: '2026-01-06T00:00:00Z',
  },
  {
    videoId: 'vid_tactics_all',
    youtubeId: 'W1gWHIpQNVU',
    title: 'All The Chess Tactics You NEED To Know',
    description: 'Master forks, pins, skewers, discovered attacks, deflection, and tactical calculation.',
    category: 'Tactical Puzzles',
    author: 'Chess.com',
    isPlaylist: false,
    createdAt: '2026-01-07T00:00:00Z',
  },
  {
    videoId: 'vid_12_endgames',
    youtubeId: 'oWDPxirOPJk',
    title: '12 Endgames That Every Player Should Know! | The Dynamic Dozen',
    description: 'Saint Louis Chess Club grandmaster breakdown of opposition, Lucena, Philidor, and minor piece endings.',
    category: 'Endgame Training',
    author: 'Saint Louis Chess Club',
    isPlaylist: false,
    createdAt: '2026-01-08T00:00:00Z',
  },
  {
    videoId: 'vid_43_endgames',
    youtubeId: 'Zt8Op8Iscx0',
    title: '43 Essential Endgame Principles (From Beginner to Master)',
    description: 'Comprehensive endgame manual covering king activation, passed pawns, rook endings, and zugzwang.',
    category: 'Endgame Training',
    author: 'Critical Chess',
    isPlaylist: false,
    createdAt: '2026-01-09T00:00:00Z',
  },
  {
    videoId: 'vid_42_middlegame',
    youtubeId: 'frYioDppIWA',
    title: '42 Middlegame Principles to Improve Your Chess Strategy!',
    description: 'Deep positional strategy: weak squares, minority attacks, bishop pair, and pawn breaks.',
    category: 'Advanced Chess Strategies',
    author: 'Critical Chess',
    isPlaylist: false,
    createdAt: '2026-01-10T00:00:00Z',
  },
  {
    videoId: 'vid_carlsen_rules',
    youtubeId: 'D-c_hFQPrag',
    title: "Carlsen's 13 Rules To Play Chess So Well It's Almost Unfair",
    description: 'Positional intuition, practical decision-making, and relentless endgame squeeze insights.',
    category: 'Grandmaster Lessons',
    author: 'Remote Chess Academy',
    isPlaylist: false,
    createdAt: '2026-01-11T00:00:00Z',
  },
  {
    videoId: 'vid_ai_analysis',
    youtubeId: 'F3KsdeUDSrA',
    title: 'Gotham vs. Gotham-Bot: Can I Beat My AI Clone?',
    description: 'Instructive real-time commentary analyzing plans, sacrifices, and engine evaluations.',
    category: 'Chess Game Analysis',
    author: 'GothamChess',
    isPlaylist: false,
    createdAt: '2026-01-12T00:00:00Z',
  },
  {
    videoId: 'vid_euwe_tal',
    youtubeId: '1eZXKF1l1SA',
    title: "The Greatest Chess Game You've Never Seen || Euwe vs Tal (1960)",
    description: 'Brilliant tactical fireworks between World Champions Max Euwe and Mikhail Tal.',
    category: 'Famous Chess Matches',
    author: "agadmator's Chess Channel",
    isPlaylist: false,
    createdAt: '2026-01-13T00:00:00Z',
  },
];

function loadStore(): PersistedStore {
  try {
    if (fs.existsSync(STORE_FILE)) {
      const raw = fs.readFileSync(STORE_FILE, 'utf-8');
      const parsed = JSON.parse(raw) as Partial<PersistedStore>;
      return {
        users: parsed.users || {},
        matches: parsed.matches || [],
        tournaments: parsed.tournaments || [],
        reports: parsed.reports || [],
        announcements: parsed.announcements || [],
        learningVideos:
          Array.isArray(parsed.learningVideos) && parsed.learningVideos.length > 0
            ? parsed.learningVideos
            : [...DEFAULT_LEARNING_VIDEOS],
        suspiciousAlerts: parsed.suspiciousAlerts || [],
        uiConfig: { ...DEFAULT_UI_CONFIG, ...(parsed.uiConfig || {}) },
        uiDraftConfig: parsed.uiDraftConfig || null,
        uiVersions: parsed.uiVersions || [],
        moderators: parsed.moderators || [],
        auditLogs: parsed.auditLogs || [],
      };
    }
  } catch (err) {
    console.error('Failed to load arena-store.json, initializing fresh store:', err);
  }
  return {
    users: {},
    matches: [],
    tournaments: [],
    reports: [],
    announcements: [
      {
        announcementId: 'ann_welcome_2026',
        title: 'Obsidian Crown Championship 2026',
        body: 'Worldwide Bullet, Blitz, Rapid, and Classical queues are now live. Enter tournaments from the Arena lobby.',
        active: true,
        createdAt: new Date().toISOString(),
      },
    ],
    learningVideos: [...DEFAULT_LEARNING_VIDEOS],
    suspiciousAlerts: [],
    uiConfig: { ...DEFAULT_UI_CONFIG },
    uiDraftConfig: null,
    uiVersions: [],
    moderators: [],
    auditLogs: [],
  };
}

const store: PersistedStore = loadStore();

let saveTimer: NodeJS.Timeout | null = null;
function persistStore() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(STORE_FILE, JSON.stringify(store, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to persist arena-store.json:', err);
    }
  }, 250);
}

function recordAudit(actor: string, actorRole: AdminRole, action: string, target?: string, details?: string) {
  store.auditLogs.unshift({
    logId: `log_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    actor,
    actorRole,
    action,
    target,
    details,
    createdAt: new Date().toISOString(),
  });
  if (store.auditLogs.length > 400) store.auditLogs.length = 400;
}

// --- Admin Token Helpers (RBAC) ---
interface AdminSession {
  u: string;
  role: AdminRole;
  permissions: string[];
  exp: number;
}

function signAdminToken(username: string, role: AdminRole, permissions: string[]): string {
  const payload = Buffer.from(
    JSON.stringify({ u: username, role, permissions, exp: Date.now() + 1000 * 60 * 60 * 12 })
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', ADMIN_SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

function verifyAdminToken(token: string | undefined): AdminSession | null {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [payload, sig] = parts;
  const expected = crypto.createHmac('sha256', ADMIN_SECRET).update(payload).digest('base64url');
  try {
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf-8')) as AdminSession;
    if (data.exp <= Date.now()) return null;
    if (data.role === 'super_admin' && (data.u === ADMIN_USERNAME || data.u === OWNER_ADMIN_EMAIL)) {
      return data;
    }
    if (data.role === 'moderator' && store.moderators.some((m) => m.username === data.u)) {
      return data;
    }
    return null;
  } catch {
    return null;
  }
}

interface AdminRequest extends Request {
  adminSession?: AdminSession;
}

function requireAdmin(req: AdminRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : undefined;
  const session = verifyAdminToken(token);
  if (!session) {
    res.status(401).json({ error: 'Unauthorized administrator access' });
    return;
  }
  req.adminSession = session;
  next();
}

function requireSuperAdmin(req: AdminRequest, res: Response, next: NextFunction) {
  requireAdmin(req, res, () => {
    if (req.adminSession?.role !== 'super_admin') {
      res.status(403).json({ error: 'Super Admin privileges required for this action.' });
      return;
    }
    next();
  });
}

// --- Simple Rate Limiter ---
const rateBuckets = new Map<string, { count: number; resetAt: number }>();
function rateLimit(maxPerMinute: number) {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || 'unknown';
    const now = Date.now();
    const bucket = rateBuckets.get(ip);
    if (!bucket || bucket.resetAt < now) {
      rateBuckets.set(ip, { count: 1, resetAt: now + 60000 });
      next();
      return;
    }
    bucket.count++;
    if (bucket.count > maxPerMinute) {
      res.status(429).json({ error: 'Rate limit exceeded. Please slow down.' });
      return;
    }
    next();
  };
}

// --- Real-Time Multiplayer State ---
interface ConnectedClient {
  ws: WebSocket;
  uid: string;
  playerId: string;
  username: string;
  rating: number;
  country: string;
  avatar: string;
  isGuest: boolean;
  roomId: string | null;
  msgTimestamps: number[];
  chatSpamTimestamps: number[];
  lastChatText?: string;
  lastChatAt?: number;
}

const clients = new Map<WebSocket, ConnectedClient>();
const userSockets = new Map<string, Set<WebSocket>>();
const rooms = new Map<string, ServerRoom>();

interface MatchmakingTicket {
  uid: string;
  playerId: string;
  username: string;
  rating: number;
  country: string;
  avatar: string;
  timeControl: TimeControlPayload;
  queuedAt: number;
  ws: WebSocket;
}
const matchmakingQueue: MatchmakingTicket[] = [];

function serializeRoom(room: ServerRoom) {
  const now = Date.now();
  let whiteTimeMs = room.whiteTimeMs;
  let blackTimeMs = room.blackTimeMs;
  if (room.status === 'playing' && room.lastMoveAt) {
    const delta = Math.max(0, now - room.lastMoveAt);
    if (room.chess.turn() === 'w') {
      whiteTimeMs = Math.max(0, whiteTimeMs - delta);
    } else {
      blackTimeMs = Math.max(0, blackTimeMs - delta);
    }
  }
  return {
    roomId: room.roomId,
    roomName: room.roomName,
    ownerId: room.ownerId,
    ownerName: room.ownerName,
    gameMode: room.gameMode,
    timeControl: room.timeControl,
    maxSpectators: room.maxSpectators,
    hasPassword: !!room.passwordHash,
    allowSpectatorChat: room.allowSpectatorChat,
    status: room.status,
    fen: room.chess.fen(),
    pgn: room.chess.pgn(),
    turn: room.chess.turn(),
    whiteTimeMs,
    blackTimeMs,
    lastMoveAt: room.lastMoveAt,
    lastMove: room.lastMove,
    winner: room.winner,
    resultReason: room.resultReason,
    drawOfferFrom: room.drawOfferFrom,
    participants: room.participants,
    chat: room.chat.slice(-100),
    elapsedSeconds: room.startedAt ? Math.floor((now - room.startedAt) / 1000) : 0,
    moveNumber: room.chess.moveNumber(),
    createdAt: room.createdAt,
  };
}

function sendWs(ws: WebSocket, type: string, payload: unknown) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type, payload }));
  }
}

function broadcastAll(type: string, payload: unknown) {
  const data = JSON.stringify({ type, payload });
  for (const [ws] of clients) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(data);
    }
  }
}

function broadcastRoom(room: ServerRoom, type: string, payload: unknown) {
  const data = JSON.stringify({ type, payload });
  for (const p of room.participants) {
    const sockets = userSockets.get(p.uid);
    if (sockets) {
      for (const s of sockets) {
        if (s.readyState === WebSocket.OPEN) {
          s.send(data);
        }
      }
    }
  }
}

function getOnlinePlayersList() {
  const map = new Map<
    string,
    {
      uid: string;
      playerId: string;
      username: string;
      rating: number;
      country: string;
      avatar: string;
      inGame: boolean;
    }
  >();
  for (const c of clients.values()) {
    map.set(c.uid, {
      uid: c.uid,
      playerId: c.playerId,
      username: c.username,
      rating: c.rating,
      country: c.country,
      avatar: c.avatar,
      inGame: !!c.roomId && rooms.get(c.roomId)?.status === 'playing',
    });
  }
  return Array.from(map.values());
}

function getPublicRoomsSummary() {
  const list: ReturnType<typeof serializeRoom>[] = [];
  for (const r of rooms.values()) {
    if (!r.isMatchmaking && r.status !== 'closed') {
      list.push(serializeRoom(r));
    }
  }
  return list;
}

function computeEloDelta(ratingA: number, ratingB: number, scoreA: number, gamesPlayedA: number): number {
  const k = gamesPlayedA < 20 ? 32 : ratingA >= 2200 ? 16 : 24;
  const expectedA = 1 / (1 + Math.pow(10, (ratingB - ratingA) / 400));
  return Math.round(k * (scoreA - expectedA));
}

function finalizeServerMatch(
  room: ServerRoom,
  winner: 'white' | 'black' | 'draw',
  reason: string
) {
  if (room.status === 'finished' || room.status === 'closed') return;
  room.status = 'finished';
  room.winner = winner;
  room.resultReason = reason;

  const whiteP = room.participants.find((p) => p.role === 'player' && p.color === 'w');
  const blackP = room.participants.find((p) => p.role === 'player' && p.color === 'b');
  const durationSeconds = room.startedAt ? Math.max(1, Math.floor((Date.now() - room.startedAt) / 1000)) : 0;

  let deltaW = 0;
  let deltaB = 0;

  if (whiteP && blackP) {
    const uW = store.users[whiteP.uid];
    const uB = store.users[blackP.uid];
    const scoreW = winner === 'white' ? 1 : winner === 'draw' ? 0.5 : 0;
    const scoreB = 1 - scoreW;

    const rW = uW ? uW.rating : whiteP.rating;
    const rB = uB ? uB.rating : blackP.rating;

    if (!whiteP.uid.startsWith('guest_') && !blackP.uid.startsWith('guest_')) {
      deltaW = computeEloDelta(rW, rB, scoreW, uW ? uW.wins + uW.losses + uW.draws : 0);
      deltaB = computeEloDelta(rB, rW, scoreB, uB ? uB.wins + uB.losses + uB.draws : 0);
    }

    const movesCount = room.chess.history().length;

    if (uW) {
      uW.rating = Math.max(100, uW.rating + deltaW);
      uW.peakRating = Math.max(uW.peakRating, uW.rating);
      uW.totalMoves += Math.ceil(movesCount / 2);
      uW.totalMatchDurationSeconds += durationSeconds;
      if (durationSeconds > uW.longestMatchSeconds) uW.longestMatchSeconds = durationSeconds;
      if (winner === 'white') {
        uW.wins += 1;
        uW.winStreak += 1;
        uW.bestWinStreak = Math.max(uW.bestWinStreak, uW.winStreak);
        uW.xp += 60;
        uW.points += 35;
        if (uW.fastestWinSeconds === 0 || durationSeconds < uW.fastestWinSeconds) {
          uW.fastestWinSeconds = durationSeconds;
        }
      } else if (winner === 'black') {
        uW.losses += 1;
        uW.winStreak = 0;
        uW.xp += 20;
        uW.points += 10;
      } else {
        uW.draws += 1;
        uW.xp += 35;
        uW.points += 20;
      }
      uW.level = Math.max(1, Math.floor(uW.xp / 250) + 1);
      uW.updatedAt = new Date().toISOString();
    }

    if (uB) {
      uB.rating = Math.max(100, uB.rating + deltaB);
      uB.peakRating = Math.max(uB.peakRating, uB.rating);
      uB.totalMoves += Math.floor(movesCount / 2);
      uB.totalMatchDurationSeconds += durationSeconds;
      if (durationSeconds > uB.longestMatchSeconds) uB.longestMatchSeconds = durationSeconds;
      if (winner === 'black') {
        uB.wins += 1;
        uB.winStreak += 1;
        uB.bestWinStreak = Math.max(uB.bestWinStreak, uB.winStreak);
        uB.xp += 60;
        uB.points += 35;
        if (uB.fastestWinSeconds === 0 || durationSeconds < uB.fastestWinSeconds) {
          uB.fastestWinSeconds = durationSeconds;
        }
      } else if (winner === 'white') {
        uB.losses += 1;
        uB.winStreak = 0;
        uB.xp += 20;
        uB.points += 10;
      } else {
        uB.draws += 1;
        uB.xp += 35;
        uB.points += 20;
      }
      uB.level = Math.max(1, Math.floor(uB.xp / 250) + 1);
      uB.updatedAt = new Date().toISOString();
    }

    const matchRecord: StoredMatch = {
      matchId: `m_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      whiteId: whiteP.uid,
      whiteName: whiteP.username,
      whiteRating: rW,
      blackId: blackP.uid,
      blackName: blackP.username,
      blackRating: rB,
      pgn: room.chess.pgn(),
      fen: room.chess.fen(),
      winner,
      resultReason: reason,
      timeControl: room.timeControl.label,
      mode: room.isMatchmaking ? 'matchmaking' : room.isTournamentMatch ? 'tournament' : 'private',
      durationSeconds,
      moveCount: movesCount,
      ratingDeltaWhite: deltaW,
      ratingDeltaBlack: deltaB,
      createdAt: new Date().toISOString(),
    };

    store.matches.unshift(matchRecord);
    if (store.matches.length > 500) store.matches.length = 500;

    if (movesCount < 4 && durationSeconds < 3 && winner !== 'draw') {
      store.suspiciousAlerts.unshift({
        id: `alt_${Date.now()}`,
        uid: winner === 'white' ? whiteP.uid : blackP.uid,
        username: winner === 'white' ? whiteP.username : blackP.username,
        reason: 'Rapid forfeit / abrupt early match termination',
        timestamp: new Date().toISOString(),
      });
    }

    if (room.isTournamentMatch && room.tournamentId && room.tournamentMatchId) {
      const tourn = store.tournaments.find((t) => t.tournamentId === room.tournamentId);
      if (tourn) {
        const tm = tourn.matches.find((m) => m.id === room.tournamentMatchId);
        if (tm) {
          tm.status = 'completed';
          tm.winnerUid = winner === 'white' ? whiteP.uid : winner === 'black' ? blackP.uid : undefined;
          const stW = tourn.standings.find((s) => s.uid === whiteP.uid);
          const stB = tourn.standings.find((s) => s.uid === blackP.uid);
          if (stW && stB) {
            if (winner === 'white') {
              stW.points += 1;
              stW.wins += 1;
              stB.losses += 1;
            } else if (winner === 'black') {
              stB.points += 1;
              stB.wins += 1;
              stW.losses += 1;
            } else {
              stW.points += 0.5;
              stB.points += 0.5;
              stW.draws += 1;
              stB.draws += 1;
            }
          }
          const allDone = tourn.matches.every((m) => m.status === 'completed');
          if (allDone) {
            tourn.status = 'completed';
          }
          tourn.updatedAt = new Date().toISOString();
          broadcastAll('tournaments:updated', store.tournaments);
        }
      }
    }

    persistStore();
    broadcastRoom(room, 'game:ended', {
      room: serializeRoom(room),
      matchRecord,
      ratingDeltaWhite: deltaW,
      ratingDeltaBlack: deltaB,
    });
  } else {
    broadcastRoom(room, 'room:updated', serializeRoom(room));
  }
}

// Clock & Matchmaking interval loops
setInterval(() => {
  const now = Date.now();
  for (const room of rooms.values()) {
    if (room.status === 'playing' && room.lastMoveAt) {
      const delta = now - room.lastMoveAt;
      if (room.chess.turn() === 'w' && room.whiteTimeMs - delta <= 0) {
        room.whiteTimeMs = 0;
        finalizeServerMatch(room, 'black', 'White flagged (Time expired)');
      } else if (room.chess.turn() === 'b' && room.blackTimeMs - delta <= 0) {
        room.blackTimeMs = 0;
        finalizeServerMatch(room, 'white', 'Black flagged (Time expired)');
      }
    }
  }

  for (let i = 0; i < matchmakingQueue.length; i++) {
    const p1 = matchmakingQueue[i];
    if (p1.ws.readyState !== WebSocket.OPEN) {
      matchmakingQueue.splice(i, 1);
      i--;
      continue;
    }
    const waitSec = (now - p1.queuedAt) / 1000;
    const maxDiff = Math.min(1200, 120 + waitSec * 30);

    for (let j = i + 1; j < matchmakingQueue.length; j++) {
      const p2 = matchmakingQueue[j];
      if (p2.ws.readyState !== WebSocket.OPEN) continue;
      if (p1.uid === p2.uid) continue;
      if (p1.timeControl.id !== p2.timeControl.id) continue;

      if (Math.abs(p1.rating - p2.rating) <= maxDiff) {
        matchmakingQueue.splice(j, 1);
        matchmakingQueue.splice(i, 1);
        i--;

        const p1White = Math.random() >= 0.5;
        const white = p1White ? p1 : p2;
        const black = p1White ? p2 : p1;

        const roomId = `MM-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
        const room: ServerRoom = {
          roomId,
          roomName: `Ranked ${p1.timeControl.label} Match`,
          ownerId: white.uid,
          ownerName: white.username,
          gameMode: p1.timeControl.category,
          timeControl: p1.timeControl,
          maxSpectators: 20,
          passwordHash: null,
          allowSpectatorChat: true,
          status: 'playing',
          chess: new Chess(),
          whiteTimeMs: p1.timeControl.initialSeconds * 1000,
          blackTimeMs: p1.timeControl.initialSeconds * 1000,
          lastMoveAt: Date.now(),
          startedAt: Date.now(),
          drawOfferFrom: null,
          participants: [
            {
              uid: white.uid,
              playerId: white.playerId,
              username: white.username,
              rating: white.rating,
              country: white.country,
              avatar: white.avatar,
              role: 'player',
              color: 'w',
              connected: true,
            },
            {
              uid: black.uid,
              playerId: black.playerId,
              username: black.username,
              rating: black.rating,
              country: black.country,
              avatar: black.avatar,
              role: 'player',
              color: 'b',
              connected: true,
            },
          ],
          chat: [
            {
              id: `sys_${Date.now()}`,
              senderId: 'system',
              senderName: 'Chess Arena',
              role: 'system',
              channel: 'room',
              text: `Ranked match started: ${white.username} (White) vs ${black.username} (Black).`,
              timestamp: new Date().toISOString(),
            },
          ],
          createdAt: new Date().toISOString(),
          isMatchmaking: true,
        };

        rooms.set(roomId, room);
        const c1 = clients.get(white.ws);
        const c2 = clients.get(black.ws);
        if (c1) c1.roomId = roomId;
        if (c2) c2.roomId = roomId;

        const serialized = serializeRoom(room);
        sendWs(white.ws, 'matchmaking:found', serialized);
        sendWs(black.ws, 'matchmaking:found', serialized);
        broadcastAll('presence:update', getOnlinePlayersList());
        break;
      }
    }
  }
}, 250);

function isUsernameTaken(username: string, excludeUid?: string): boolean {
  const target = username.trim().toLowerCase();
  return Object.values(store.users).some(
    (u) => u.uid !== excludeUid && u.username.trim().toLowerCase() === target
  );
}

function sanitizeUserForViewer(target: StoredUser, viewerUid?: string): StoredUser {
  if (viewerUid && viewerUid === target.uid) return target;
  const ps = target.privacySections || {
    stats: true,
    matchHistory: true,
    achievements: true,
    learningJourney: true,
    friends: true,
    favoriteOpenings: true,
  };
  return {
    ...target,
    achievements: ps.achievements ? target.achievements : [],
    learningJourney: ps.learningJourney ? target.learningJourney : '',
    mentorName: ps.learningJourney ? target.mentorName : '',
    favoriteOpening: ps.favoriteOpenings ? target.favoriteOpening : '',
    favoritePlayer: ps.favoriteOpenings ? target.favoritePlayer : '',
  };
}

async function startServer() {
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }

  const app = express();
  app.use(express.json({ limit: '3mb' }));
  app.use('/uploads', express.static(UPLOADS_DIR));

  const server = http.createServer(app);
  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (request, socket, head) => {
    const pathname = new URL(
      request.url || '/',
      `http://${request.headers.host || 'localhost'}`
    ).pathname;
    if (pathname === '/ws') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    }
  });

  // --- REST API Endpoints ---
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', onlinePlayers: clients.size, activeRooms: rooms.size });
  });

  app.get('/api/bootstrap', (_req, res) => {
    const leaderboard = Object.values(store.users)
      .filter((u) => !u.isBanned)
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 100);
    res.json({
      uiConfig: store.uiConfig,
      announcements: store.announcements.filter((a) => a.active),
      learningVideos: store.learningVideos,
      leaderboard,
      tournaments: store.tournaments,
      publicRooms: getPublicRoomsSummary(),
      recentMatches: store.matches.slice(0, 40),
    });
  });

  app.get('/api/users/check-username', (req, res) => {
    const username = String(req.query.username || '').trim();
    const uid = req.query.uid ? String(req.query.uid) : undefined;
    if (username.length < 2 || username.length > 32) {
      res.json({ available: false, reason: 'Username must be between 2 and 32 characters.' });
      return;
    }
    if (!/^[a-zA-Z0-9_ -]+$/.test(username)) {
      res.json({ available: false, reason: 'Use only letters, numbers, spaces, _ or -.' });
      return;
    }
    const taken = isUsernameTaken(username, uid);
    res.json({
      available: !taken,
      reason: taken ? 'This username is already taken by another player.' : undefined,
    });
  });

  app.post('/api/users/change-username', rateLimit(15), (req, res) => {
    const { uid, newUsername } = req.body as { uid?: string; newUsername?: string };
    if (!uid || !newUsername) {
      res.status(400).json({ error: 'uid and newUsername are required.' });
      return;
    }
    const user = store.users[uid];
    if (!user) {
      res.status(404).json({ error: 'Player record not found.' });
      return;
    }
    const clean = String(newUsername).trim().slice(0, 32);
    if (clean.length < 2 || !/^[a-zA-Z0-9_ -]+$/.test(clean)) {
      res.status(400).json({ error: 'Username must be 2–32 alphanumeric/underscore/hyphen characters.' });
      return;
    }
    if (clean.toLowerCase() === user.username.toLowerCase()) {
      user.username = clean;
      user.updatedAt = new Date().toISOString();
      persistStore();
      res.json({ user });
      return;
    }
    if (user.lastUsernameChangeAt) {
      const daysSince = (Date.now() - new Date(user.lastUsernameChangeAt).getTime()) / (1000 * 60 * 60 * 24);
      if (daysSince < 7) {
        const waitDays = Math.ceil(7 - daysSince);
        res.status(429).json({
          error: `Username change cooldown active. You can change again in ${waitDays} day(s).`,
        });
        return;
      }
    }
    if (isUsernameTaken(clean, uid)) {
      res.status(409).json({ error: 'Username is already taken.' });
      return;
    }
    user.username = clean;
    user.lastUsernameChangeAt = new Date().toISOString();
    user.updatedAt = new Date().toISOString();
    persistStore();
    res.json({ user });
  });

  app.post('/api/users/upload-avatar', rateLimit(20), (req, res) => {
    const { uid, dataUrl } = req.body as { uid?: string; dataUrl?: string };
    if (!uid || !dataUrl) {
      res.status(400).json({ error: 'uid and image dataUrl are required.' });
      return;
    }
    const match = /^data:image\/(png|jpeg|jpg|webp|gif);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
    if (!match) {
      res.status(400).json({ error: 'Unsupported image format. Upload PNG, JPG, WEBP, or GIF.' });
      return;
    }
    const ext = match[1] === 'jpeg' ? 'jpg' : match[1];
    const buf = Buffer.from(match[2], 'base64');
    if (buf.length > 1.5 * 1024 * 1024) {
      res.status(413).json({ error: 'Avatar image exceeds 1.5MB limit.' });
      return;
    }
    const safeUid = uid.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40) || 'user';
    const filename = `${safeUid}_${Date.now()}.${ext}`;
    fs.writeFileSync(path.join(UPLOADS_DIR, filename), buf);
    const avatarUrl = `/uploads/${filename}`;
    if (store.users[uid]) {
      store.users[uid].avatar = avatarUrl;
      store.users[uid].updatedAt = new Date().toISOString();
      persistStore();
    }
    res.json({ avatarUrl });
  });

  app.post('/api/users/sync', rateLimit(80), (req, res) => {
    const body = req.body as Partial<StoredUser>;
    if (!body.uid || !body.username) {
      res.status(400).json({ error: 'Missing uid or username' });
      return;
    }
    const existing = store.users[body.uid];
    if (existing?.isBanned) {
      res.status(403).json({
        error: 'Account banned',
        isBanned: true,
        banReason: existing.banReason || 'Violated platform rules',
      });
      return;
    }

    let safeUsername = String(body.username).trim().slice(0, 32) || 'Player';
    if (!existing && isUsernameTaken(safeUsername, body.uid)) {
      safeUsername = `${safeUsername.slice(0, 24)}_${String(body.uid).slice(-4).toUpperCase()}`;
    } else if (existing && body.username !== existing.username && isUsernameTaken(safeUsername, body.uid)) {
      safeUsername = existing.username;
    }

    const now = new Date().toISOString();
    const merged: StoredUser = existing
      ? {
          ...existing,
          username: safeUsername,
          displayName: body.displayName !== undefined ? String(body.displayName).slice(0, 40) : existing.displayName,
          bio: body.bio !== undefined ? String(body.bio).slice(0, 400) : existing.bio,
          country: body.country ? String(body.country).slice(0, 64) : existing.country,
          avatar: body.avatar ? String(body.avatar).slice(0, 256) : existing.avatar,
          chessExperience:
            body.chessExperience !== undefined ? String(body.chessExperience).slice(0, 64) : existing.chessExperience,
          learningJourney:
            body.learningJourney !== undefined ? String(body.learningJourney).slice(0, 600) : existing.learningJourney,
          mentorName: body.mentorName !== undefined ? String(body.mentorName).slice(0, 64) : existing.mentorName,
          favoritePlayer:
            body.favoritePlayer !== undefined ? String(body.favoritePlayer).slice(0, 64) : existing.favoritePlayer,
          favoriteOpening:
            body.favoriteOpening !== undefined ? String(body.favoriteOpening).slice(0, 80) : existing.favoriteOpening,
          profileTheme:
            body.profileTheme !== undefined ? String(body.profileTheme).slice(0, 32) : existing.profileTheme,
          profileFrame:
            body.profileFrame !== undefined ? String(body.profileFrame).slice(0, 32) : existing.profileFrame,
          privacySections: body.privacySections || existing.privacySections,
          privacyAllowMessages: body.privacyAllowMessages || existing.privacyAllowMessages,
          privacyAllowInvites: body.privacyAllowInvites || existing.privacyAllowInvites,
          puzzlesSolved: Math.max(existing.puzzlesSolved, Number(body.puzzlesSolved || 0)),
          puzzleRating: body.puzzleRating ? Number(body.puzzleRating) : existing.puzzleRating,
          xp: Math.max(existing.xp, Number(body.xp || 0)),
          points: Math.max(existing.points, Number(body.points || 0)),
          achievements: Array.isArray(body.achievements)
            ? Array.from(new Set([...existing.achievements, ...body.achievements])).slice(0, 50)
            : existing.achievements,
          following: Array.isArray(body.following) ? body.following.slice(0, 200) : existing.following || [],
          blockedUids: Array.isArray(body.blockedUids) ? body.blockedUids.slice(0, 200) : existing.blockedUids || [],
          completedVideos: Array.isArray(body.completedVideos)
            ? body.completedVideos.slice(0, 200)
            : existing.completedVideos || [],
          favoriteVideos: Array.isArray(body.favoriteVideos)
            ? body.favoriteVideos.slice(0, 200)
            : existing.favoriteVideos || [],
          updatedAt: now,
        }
      : {
          uid: String(body.uid).slice(0, 128),
          playerId: String(body.playerId || `CA-${Date.now().toString().slice(-6)}`).slice(0, 32),
          username: safeUsername,
          displayName: body.displayName ? String(body.displayName).slice(0, 40) : safeUsername,
          bio: body.bio ? String(body.bio).slice(0, 400) : '',
          country: String(body.country || 'Global').slice(0, 64),
          avatar: String(body.avatar || '/src/assets/images/avatar_knight_obsidian_1794980498230.jpg'),
          chessExperience: String(body.chessExperience || 'Club Player').slice(0, 64),
          learningJourney: String(body.learningJourney || '').slice(0, 600),
          mentorName: String(body.mentorName || '').slice(0, 64),
          favoritePlayer: String(body.favoritePlayer || '').slice(0, 64),
          favoriteOpening: String(body.favoriteOpening || 'Italian Game').slice(0, 80),
          profileTheme: String(body.profileTheme || 'obsidian_gold').slice(0, 32),
          profileFrame: String(body.profileFrame || 'gold_laurel').slice(0, 32),
          privacySections: body.privacySections || {
            stats: true,
            matchHistory: true,
            achievements: true,
            learningJourney: true,
            friends: true,
            favoriteOpenings: true,
          },
          rating: 1200,
          peakRating: 1200,
          puzzleRating: 1200,
          puzzlesSolved: 0,
          xp: 0,
          level: 1,
          points: 100,
          wins: 0,
          losses: 0,
          draws: 0,
          winStreak: 0,
          bestWinStreak: 0,
          totalMoves: 0,
          fastestWinSeconds: 0,
          longestMatchSeconds: 0,
          totalMatchDurationSeconds: 0,
          isBanned: false,
          privacyAllowMessages: 'everyone',
          privacyAllowInvites: 'everyone',
          achievements: [],
          following: [],
          blockedUids: [],
          completedVideos: [],
          favoriteVideos: [],
          createdAt: now,
          updatedAt: now,
          isGuest: body.isGuest,
        };
    merged.level = Math.max(1, Math.floor(merged.xp / 250) + 1);
    store.users[merged.uid] = merged;
    persistStore();
    res.json({ user: merged });
  });

  app.get('/api/users/search', (req, res) => {
    const q = String(req.query.q || '').trim().toLowerCase();
    const exact = req.query.exact === 'true';
    const viewerUid = req.query.viewerUid ? String(req.query.viewerUid) : undefined;
    const onlineSet = new Set(getOnlinePlayersList().map((o) => o.uid));

    const list = Object.values(store.users).filter((u) => {
      if (u.isBanned) return false;
      if (!q) return true;
      if (exact) {
        return u.username.toLowerCase() === q || u.playerId.toLowerCase() === q;
      }
      return (
        u.username.toLowerCase().includes(q) ||
        u.playerId.toLowerCase().includes(q) ||
        (u.displayName || '').toLowerCase().includes(q) ||
        u.country.toLowerCase().includes(q)
      );
    });

    res.json({
      users: list.slice(0, 50).map((u) => ({
        ...sanitizeUserForViewer(u, viewerUid),
        online: onlineSet.has(u.uid),
      })),
    });
  });

  app.get('/api/users/:uid', (req, res) => {
    const target = store.users[req.params.uid];
    if (!target || target.isBanned) {
      res.status(404).json({ error: 'Player not found.' });
      return;
    }
    const viewerUid = req.query.viewerUid ? String(req.query.viewerUid) : undefined;
    const sanitized = sanitizeUserForViewer(target, viewerUid);
    const allowHistory =
      viewerUid === target.uid || target.privacySections?.matchHistory !== false;
    const recentMatches = allowHistory
      ? store.matches
          .filter((m) => m.whiteId === target.uid || m.blackId === target.uid)
          .slice(0, 15)
      : [];
    res.json({
      user: sanitized,
      recentMatches,
      online: userSockets.has(target.uid),
    });
  });

  app.post('/api/users/follow', rateLimit(40), (req, res) => {
    const { uid, targetUid, follow } = req.body as { uid?: string; targetUid?: string; follow?: boolean };
    if (!uid || !targetUid || !store.users[uid]) {
      res.status(400).json({ error: 'Invalid follow request' });
      return;
    }
    const list = new Set(store.users[uid].following || []);
    if (follow) list.add(targetUid);
    else list.delete(targetUid);
    store.users[uid].following = Array.from(list).slice(0, 200);
    store.users[uid].updatedAt = new Date().toISOString();
    persistStore();
    res.json({ following: store.users[uid].following });
  });

  app.post('/api/users/block', rateLimit(40), (req, res) => {
    const { uid, targetUid, block } = req.body as { uid?: string; targetUid?: string; block?: boolean };
    if (!uid || !targetUid || !store.users[uid]) {
      res.status(400).json({ error: 'Invalid block request' });
      return;
    }
    const list = new Set(store.users[uid].blockedUids || []);
    if (block) list.add(targetUid);
    else list.delete(targetUid);
    store.users[uid].blockedUids = Array.from(list).slice(0, 200);
    store.users[uid].updatedAt = new Date().toISOString();
    persistStore();
    res.json({ blockedUids: store.users[uid].blockedUids });
  });

  app.post('/api/matches/offline-sync', rateLimit(30), (req, res) => {
    const { uid, matches } = req.body as { uid?: string; matches?: StoredMatch[] };
    if (!uid || !Array.isArray(matches)) {
      res.status(400).json({ error: 'Invalid sync payload' });
      return;
    }
    const user = store.users[uid];
    if (!user || user.isBanned) {
      res.status(403).json({ error: 'User unavailable or banned' });
      return;
    }

    const syncedIds: string[] = [];
    for (const m of matches.slice(0, 20)) {
      if (!m.matchId || !m.pgn) continue;
      const validator = new Chess();
      try {
        validator.loadPgn(m.pgn);
      } catch {
        continue;
      }
      if (!store.matches.some((ex) => ex.matchId === m.matchId)) {
        store.matches.unshift({ ...m, mode: 'offline' });
        user.xp += 25;
        user.points += 15;
        user.level = Math.max(1, Math.floor(user.xp / 250) + 1);
      }
      syncedIds.push(m.matchId);
    }
    persistStore();
    res.json({ syncedIds, user });
  });

  app.post('/api/reports', rateLimit(20), (req, res) => {
    const { reporterUid, reportedPlayerId, reportedUsername, reason, details } = req.body as Partial<StoredReport>;
    if (!reporterUid || !reportedPlayerId || !reason) {
      res.status(400).json({ error: 'Missing required report fields' });
      return;
    }
    const report: StoredReport = {
      reportId: `rep_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      reporterUid: String(reporterUid).slice(0, 128),
      reportedPlayerId: String(reportedPlayerId).slice(0, 128),
      reportedUsername: reportedUsername ? String(reportedUsername).slice(0, 64) : undefined,
      reason: String(reason).slice(0, 120),
      details: String(details || '').slice(0, 1000),
      status: 'open',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    store.reports.unshift(report);
    persistStore();
    res.json({ report });
  });

  app.get('/api/learning-videos', (_req, res) => {
    res.json({ videos: store.learningVideos });
  });

  // --- Gemini AI Post-Match Analysis Route ---
  app.post('/api/ai/analyze-match', rateLimit(20), async (req, res) => {
    const { pgn, playerColor, mistakesSummary } = req.body as {
      pgn?: string;
      playerColor?: 'w' | 'b';
      mistakesSummary?: string;
    };

    if (!pgn) {
      res.status(400).json({ error: 'PGN is required for analysis.' });
      return;
    }

    if (!process.env.GEMINI_API_KEY) {
      res.status(503).json({
        error: 'Gemini API key is not configured in Settings > Secrets. Local engine analysis remains available.',
      });
      return;
    }

    try {
      const ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const prompt = `You are a Chess Grandmaster Coach analyzing a completed game.
Player perspective: ${playerColor === 'b' ? 'Black' : 'White'}
PGN:
${pgn.slice(0, 4000)}

Engine Mistake Summary:
${(mistakesSummary || 'None supplied').slice(0, 1500)}

Provide a concise, actionable 3-part review in plain prose:
1. Opening & Phase Transition assessment
2. Critical Mistake or Turning Point explanation (why the mistake lost advantage and what stronger plan existed)
3. Specific tactical/strategic drill recommendation for improvement.`;

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: prompt,
      });

      res.json({ analysis: response.text || 'Analysis completed.' });
    } catch (err) {
      console.error('Gemini AI analysis error:', err);
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Failed to generate AI coaching report.',
      });
    }
  });

  // --- Admin & Moderator RBAC Routes (Protected Server-Side) ---
  app.post('/api/admin/login', rateLimit(15), async (req, res) => {
    const { username, password } = req.body as { username?: string; password?: string };
    const cleanUser = String(username || '').trim();
    const cleanPass = String(password || '');

    if (cleanUser === ADMIN_USERNAME && cleanPass === ADMIN_PASSWORD) {
      const perms = ['*'];
      const token = signAdminToken(ADMIN_USERNAME, 'super_admin', perms);
      recordAudit(ADMIN_USERNAME, 'super_admin', 'admin_login', 'console', 'Signed in via credentials');
      persistStore();
      res.json({ token, username: ADMIN_USERNAME, role: 'super_admin', permissions: perms });
      return;
    }

    const mod = store.moderators.find((m) => m.username.toLowerCase() === cleanUser.toLowerCase());
    if (mod && (await bcrypt.compare(cleanPass, mod.passwordHash))) {
      const token = signAdminToken(mod.username, mod.role, mod.permissions);
      recordAudit(mod.username, mod.role, 'moderator_login', 'console', 'Moderator signed in');
      persistStore();
      res.json({ token, username: mod.username, role: mod.role, permissions: mod.permissions });
      return;
    }

    res.status(401).json({ error: 'Invalid staff or administrator credentials.' });
  });

  app.post('/api/admin/firebase-login', rateLimit(15), async (req, res) => {
    const { idToken } = req.body as { idToken?: string };
    if (!idToken || !FIREBASE_API_KEY) {
      res.status(400).json({ error: 'Firebase verification not available.' });
      return;
    }
    try {
      const verifyRes = await fetch(
        `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${FIREBASE_API_KEY}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ idToken }),
        }
      );
      if (!verifyRes.ok) {
        res.status(401).json({ error: 'Invalid Firebase identity token.' });
        return;
      }
      const data = (await verifyRes.json()) as {
        users?: { email?: string; emailVerified?: boolean; localId?: string }[];
      };
      const account = data.users?.[0];
      if (!account || !account.emailVerified || account.email !== OWNER_ADMIN_EMAIL) {
        res.status(403).json({ error: 'Only the verified platform owner account may use single-sign-on Admin access.' });
        return;
      }
      const perms = ['*'];
      const token = signAdminToken(OWNER_ADMIN_EMAIL, 'super_admin', perms);
      recordAudit(OWNER_ADMIN_EMAIL, 'super_admin', 'admin_sso_login', 'console', 'Verified Firebase owner login');
      persistStore();
      res.json({ token, username: OWNER_ADMIN_EMAIL, role: 'super_admin', permissions: perms });
    } catch {
      res.status(500).json({ error: 'Failed to verify Firebase administrator identity.' });
    }
  });

  app.get('/api/admin/me', requireAdmin, (req: AdminRequest, res) => {
    res.json({
      username: req.adminSession?.u,
      role: req.adminSession?.role,
      permissions: req.adminSession?.permissions || [],
    });
  });

  app.get('/api/admin/overview', requireAdmin, (req: AdminRequest, res) => {
    res.json({
      role: req.adminSession?.role,
      username: req.adminSession?.u,
      permissions: req.adminSession?.permissions || [],
      users: Object.values(store.users),
      activeRooms: Array.from(rooms.values()).map(serializeRoom),
      tournaments: store.tournaments,
      reports: store.reports,
      announcements: store.announcements,
      learningVideos: store.learningVideos,
      suspiciousAlerts: store.suspiciousAlerts,
      uiConfig: store.uiConfig,
      uiDraftConfig: store.uiDraftConfig,
      uiVersions: store.uiVersions.slice(0, 20),
      moderators:
        req.adminSession?.role === 'super_admin'
          ? store.moderators.map(({ id, username, role, permissions, createdAt, createdBy }) => ({
              id,
              username,
              role,
              permissions,
              createdAt,
              createdBy,
            }))
          : [],
      auditLogs: store.auditLogs.slice(0, 100),
      onlineCount: clients.size,
      totalMatches: store.matches.length,
    });
  });

  // --- Visual Editor Draft / Publish / Rollback (Super Admin Only) ---
  app.post('/api/admin/ui-draft', requireSuperAdmin, (req: AdminRequest, res) => {
    const incoming = req.body as Partial<UiConfigState>;
    store.uiDraftConfig = {
      ...(store.uiDraftConfig || store.uiConfig),
      ...incoming,
      updatedAt: new Date().toISOString(),
    };
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'save_ui_draft', 'app_config/ui');
    persistStore();
    res.json({ uiDraftConfig: store.uiDraftConfig });
  });

  app.delete('/api/admin/ui-draft', requireSuperAdmin, (req: AdminRequest, res) => {
    store.uiDraftConfig = null;
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'discard_ui_draft', 'app_config/ui');
    persistStore();
    res.json({ ok: true });
  });

  app.post('/api/admin/ui-config', requireSuperAdmin, (req: AdminRequest, res) => {
    const { label, ...incoming } = req.body as Partial<UiConfigState> & { label?: string };
    // Save snapshot of previous live config for rollback
    store.uiVersions.unshift({
      versionId: `ver_${Date.now()}`,
      savedBy: req.adminSession!.u,
      label: label || `Published ${new Date().toLocaleString()}`,
      config: { ...store.uiConfig },
      createdAt: new Date().toISOString(),
    });
    if (store.uiVersions.length > 25) store.uiVersions.length = 25;

    store.uiConfig = {
      ...store.uiConfig,
      ...incoming,
      updatedAt: new Date().toISOString(),
    };
    store.uiDraftConfig = null;
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'publish_ui_live', 'app_config/ui', label);
    persistStore();
    broadcastAll('ui:config_updated', store.uiConfig);
    res.json({ uiConfig: store.uiConfig, uiVersions: store.uiVersions });
  });

  app.post('/api/admin/ui-restore', requireSuperAdmin, (req: AdminRequest, res) => {
    const { versionId } = req.body as { versionId?: string };
    const found = store.uiVersions.find((v) => v.versionId === versionId);
    if (!found) {
      res.status(404).json({ error: 'Version snapshot not found.' });
      return;
    }
    store.uiVersions.unshift({
      versionId: `ver_${Date.now()}`,
      savedBy: req.adminSession!.u,
      label: `Before restore (${found.label})`,
      config: { ...store.uiConfig },
      createdAt: new Date().toISOString(),
    });
    store.uiConfig = { ...found.config, updatedAt: new Date().toISOString() };
    store.uiDraftConfig = null;
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'restore_ui_version', versionId);
    persistStore();
    broadcastAll('ui:config_updated', store.uiConfig);
    res.json({ uiConfig: store.uiConfig, uiVersions: store.uiVersions });
  });

  // --- Player Management ---
  app.post('/api/admin/ban', requireAdmin, (req: AdminRequest, res) => {
    const { uid, reason } = req.body as { uid?: string; reason?: string };
    if (!uid) {
      res.status(400).json({ error: 'uid is required' });
      return;
    }
    const user = store.users[uid];
    if (user) {
      user.isBanned = true;
      user.banReason = reason || 'Banned by administrator';
      user.updatedAt = new Date().toISOString();
    } else {
      store.users[uid] = {
        uid,
        playerId: uid,
        username: uid,
        country: 'Global',
        avatar: '/src/assets/images/avatar_knight_obsidian_1794980498230.jpg',
        rating: 1200,
        peakRating: 1200,
        puzzleRating: 1200,
        puzzlesSolved: 0,
        xp: 0,
        level: 1,
        points: 0,
        wins: 0,
        losses: 0,
        draws: 0,
        winStreak: 0,
        bestWinStreak: 0,
        totalMoves: 0,
        fastestWinSeconds: 0,
        longestMatchSeconds: 0,
        totalMatchDurationSeconds: 0,
        isBanned: true,
        banReason: reason || 'Banned by administrator',
        privacyAllowMessages: 'none',
        privacyAllowInvites: 'none',
        achievements: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    }

    const sockets = userSockets.get(uid);
    if (sockets) {
      for (const s of sockets) {
        sendWs(s, 'auth:banned', { reason: store.users[uid].banReason });
        s.close();
      }
    }
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'ban_user', uid, reason);
    persistStore();
    broadcastAll('presence:update', getOnlinePlayersList());
    res.json({ user: store.users[uid] });
  });

  app.post('/api/admin/unban', requireAdmin, (req: AdminRequest, res) => {
    const { uid } = req.body as { uid?: string };
    if (!uid || !store.users[uid]) {
      res.status(404).json({ error: 'Player not found' });
      return;
    }
    store.users[uid].isBanned = false;
    store.users[uid].banReason = '';
    store.users[uid].updatedAt = new Date().toISOString();
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'unban_user', uid);
    persistStore();
    res.json({ user: store.users[uid] });
  });

  app.post('/api/admin/user-update', requireAdmin, (req: AdminRequest, res) => {
    const { uid, username, rating, xp, points, bio, country } = req.body as {
      uid?: string;
      username?: string;
      rating?: number;
      xp?: number;
      points?: number;
      bio?: string;
      country?: string;
    };
    if (!uid || !store.users[uid]) {
      res.status(404).json({ error: 'Player not found' });
      return;
    }
    const u = store.users[uid];
    if (username && !isUsernameTaken(username, uid)) u.username = String(username).slice(0, 32);
    if (typeof rating === 'number') {
      u.rating = Math.max(100, Math.min(4000, Math.round(rating)));
      u.peakRating = Math.max(u.peakRating, u.rating);
    }
    if (typeof xp === 'number') {
      u.xp = Math.max(0, Math.round(xp));
      u.level = Math.max(1, Math.floor(u.xp / 250) + 1);
    }
    if (typeof points === 'number') u.points = Math.max(0, Math.round(points));
    if (typeof bio === 'string') u.bio = bio.slice(0, 400);
    if (typeof country === 'string') u.country = country.slice(0, 64);
    u.updatedAt = new Date().toISOString();
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'update_user', uid);
    persistStore();
    res.json({ user: u });
  });

  app.delete('/api/admin/users/:uid', requireSuperAdmin, (req: AdminRequest, res) => {
    const uid = req.params.uid;
    if (!store.users[uid]) {
      res.status(404).json({ error: 'Player not found' });
      return;
    }
    delete store.users[uid];
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'delete_user', uid);
    persistStore();
    res.json({ ok: true });
  });

  app.post('/api/admin/adjust-rating', requireAdmin, (req: AdminRequest, res) => {
    const { uid, rating } = req.body as { uid?: string; rating?: number };
    if (!uid || !store.users[uid] || typeof rating !== 'number') {
      res.status(400).json({ error: 'Invalid player or rating' });
      return;
    }
    store.users[uid].rating = Math.max(100, Math.min(4000, Math.round(rating)));
    store.users[uid].peakRating = Math.max(store.users[uid].peakRating, store.users[uid].rating);
    store.users[uid].updatedAt = new Date().toISOString();
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'adjust_rating', uid, `New Elo: ${store.users[uid].rating}`);
    persistStore();
    res.json({ user: store.users[uid] });
  });

  app.post('/api/admin/rankings/reset', requireSuperAdmin, (req: AdminRequest, res) => {
    for (const u of Object.values(store.users)) {
      u.rating = 1200;
      u.winStreak = 0;
      u.updatedAt = new Date().toISOString();
    }
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'reset_all_rankings', 'leaderboard');
    persistStore();
    res.json({ ok: true });
  });

  // --- Room, Chat & Announcements ---
  app.post('/api/admin/room-close', requireAdmin, (req: AdminRequest, res) => {
    const { roomId } = req.body as { roomId?: string };
    const room = roomId ? rooms.get(roomId) : undefined;
    if (!room) {
      res.status(404).json({ error: 'Room not found' });
      return;
    }
    room.status = 'closed';
    broadcastRoom(room, 'room:closed', { roomId, reason: 'Closed by administrator' });
    rooms.delete(roomId!);
    broadcastAll('rooms:list', getPublicRoomsSummary());
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'close_room', roomId);
    persistStore();
    res.json({ ok: true });
  });

  app.post('/api/admin/chat-delete', requireAdmin, (req: AdminRequest, res) => {
    const { roomId, messageId } = req.body as { roomId?: string; messageId?: string };
    const room = roomId ? rooms.get(roomId) : undefined;
    if (!room || !messageId) {
      res.status(404).json({ error: 'Room or message not found' });
      return;
    }
    room.chat = room.chat.filter((m) => m.id !== messageId);
    broadcastRoom(room, 'room:updated', serializeRoom(room));
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'delete_chat_message', `${roomId}/${messageId}`);
    persistStore();
    res.json({ ok: true });
  });

  app.post('/api/admin/reports/status', requireAdmin, (req: AdminRequest, res) => {
    const { reportId, status } = req.body as { reportId?: string; status?: StoredReport['status'] };
    const rep = store.reports.find((r) => r.reportId === reportId);
    if (!rep || !status) {
      res.status(404).json({ error: 'Report not found' });
      return;
    }
    rep.status = status;
    rep.updatedAt = new Date().toISOString();
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'update_report', reportId, status);
    persistStore();
    res.json({ report: rep });
  });

  app.post('/api/admin/announcements', requireAdmin, (req: AdminRequest, res) => {
    const { title, body, active } = req.body as Partial<StoredAnnouncement>;
    if (!title || !body) {
      res.status(400).json({ error: 'Title and body required' });
      return;
    }
    const ann: StoredAnnouncement = {
      announcementId: `ann_${Date.now()}`,
      title: String(title).slice(0, 100),
      body: String(body).slice(0, 500),
      active: active !== false,
      createdAt: new Date().toISOString(),
    };
    store.announcements.unshift(ann);
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'create_announcement', ann.announcementId, ann.title);
    persistStore();
    broadcastAll('announcements:updated', store.announcements.filter((a) => a.active));
    res.json({ announcement: ann });
  });

  app.delete('/api/admin/announcements/:id', requireAdmin, (req: AdminRequest, res) => {
    store.announcements = store.announcements.filter((a) => a.announcementId !== req.params.id);
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'delete_announcement', req.params.id);
    persistStore();
    broadcastAll('announcements:updated', store.announcements.filter((a) => a.active));
    res.json({ ok: true });
  });

  // --- Learning Videos CRUD ---
  app.post('/api/admin/learning-videos', requireAdmin, (req: AdminRequest, res) => {
    const { title, description, category, author, youtubeId, playlistId, isPlaylist } = req.body as Partial<StoredLearningVideo>;
    if (!title || !category || (!youtubeId && !playlistId)) {
      res.status(400).json({ error: 'Title, category, and YouTube Video ID or Playlist ID are required.' });
      return;
    }
    const vid: StoredLearningVideo = {
      videoId: `vid_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      youtubeId: youtubeId ? String(youtubeId).trim().slice(0, 32) : undefined,
      playlistId: playlistId ? String(playlistId).trim().slice(0, 64) : undefined,
      title: String(title).trim().slice(0, 120),
      description: String(description || '').trim().slice(0, 500),
      category: String(category).trim().slice(0, 64),
      author: String(author || 'Chess Arena Academy').trim().slice(0, 64),
      isPlaylist: !!isPlaylist,
      createdAt: new Date().toISOString(),
    };
    store.learningVideos.unshift(vid);
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'add_learning_video', vid.videoId, vid.title);
    persistStore();
    broadcastAll('learning:updated', store.learningVideos);
    res.json({ video: vid, learningVideos: store.learningVideos });
  });

  app.delete('/api/admin/learning-videos/:videoId', requireAdmin, (req: AdminRequest, res) => {
    store.learningVideos = store.learningVideos.filter((v) => v.videoId !== req.params.videoId);
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'delete_learning_video', req.params.videoId);
    persistStore();
    broadcastAll('learning:updated', store.learningVideos);
    res.json({ ok: true, learningVideos: store.learningVideos });
  });

  // --- Tournament Admin Controls ---
  app.delete('/api/admin/tournaments/:id', requireAdmin, (req: AdminRequest, res) => {
    store.tournaments = store.tournaments.filter((t) => t.tournamentId !== req.params.id);
    recordAudit(req.adminSession!.u, req.adminSession!.role, 'delete_tournament', req.params.id);
    persistStore();
    broadcastAll('tournaments:updated', store.tournaments);
    res.json({ ok: true });
  });

  // --- Security & Moderator Management (Super Admin Only) ---
  app.post('/api/admin/moderators', requireSuperAdmin, async (req: AdminRequest, res) => {
    const { username, password, permissions } = req.body as {
      username?: string;
      password?: string;
      permissions?: string[];
    };
    const clean = String(username || '').trim();
    if (clean.length < 3 || !password || password.length < 6) {
      res.status(400).json({ error: 'Moderator username (>=3 chars) and password (>=6 chars) required.' });
      return;
    }
    if (clean.toLowerCase() === ADMIN_USERNAME.toLowerCase() || store.moderators.some((m) => m.username.toLowerCase() === clean.toLowerCase())) {
      res.status(409).json({ error: 'Staff username already exists.' });
      return;
    }
    const mod: StoredModerator = {
      id: `mod_${Date.now()}`,
      username: clean,
      passwordHash: await bcrypt.hash(password, 8),
      role: 'moderator',
      permissions: Array.isArray(permissions) ? permissions : ['players', 'rooms', 'chat', 'reports'],
      createdAt: new Date().toISOString(),
      createdBy: req.adminSession!.u,
    };
    store.moderators.push(mod);
    recordAudit(req.adminSession!.u, 'super_admin', 'create_moderator', clean, mod.permissions.join(','));
    persistStore();
    res.json({
      moderator: {
        id: mod.id,
        username: mod.username,
        role: mod.role,
        permissions: mod.permissions,
        createdAt: mod.createdAt,
        createdBy: mod.createdBy,
      },
    });
  });

  app.delete('/api/admin/moderators/:id', requireSuperAdmin, (req: AdminRequest, res) => {
    store.moderators = store.moderators.filter((m) => m.id !== req.params.id);
    recordAudit(req.adminSession!.u, 'super_admin', 'remove_moderator', req.params.id);
    persistStore();
    res.json({ ok: true });
  });

  // --- Database Management (Super Admin Only) ---
  app.get('/api/admin/db-export', requireSuperAdmin, (req: AdminRequest, res) => {
    recordAudit(req.adminSession!.u, 'super_admin', 'export_database', 'arena-store.json');
    persistStore();
    res.json({
      exportedAt: new Date().toISOString(),
      counts: {
        users: Object.keys(store.users).length,
        matches: store.matches.length,
        tournaments: store.tournaments.length,
        learningVideos: store.learningVideos.length,
        reports: store.reports.length,
        auditLogs: store.auditLogs.length,
      },
      data: store,
    });
  });

  app.post('/api/admin/db-cleanup', requireSuperAdmin, (req: AdminRequest, res) => {
    const beforeReports = store.reports.length;
    store.reports = store.reports.filter((r) => r.status === 'open');
    const removedReports = beforeReports - store.reports.length;
    recordAudit(req.adminSession!.u, 'super_admin', 'db_cleanup', 'reports', `Removed ${removedReports} resolved reports`);
    persistStore();
    res.json({ ok: true, removedReports });
  });

  // --- WebSocket Real-Time Engine ---
  wss.on('connection', (ws) => {
    ws.on('message', async (raw) => {
      let msg: { type: string; payload?: Record<string, unknown> };
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        return;
      }

      const client = clients.get(ws);

      if (client) {
        const now = Date.now();
        client.msgTimestamps = client.msgTimestamps.filter((t) => now - t < 10000);
        if (client.msgTimestamps.length > 45) {
          sendWs(ws, 'error:notice', { message: 'Action rate limit exceeded. Wait a moment.' });
          return;
        }
        client.msgTimestamps.push(now);
      }

      if (msg.type === 'auth:identify') {
        const p = (msg.payload || {}) as {
          uid?: string;
          playerId?: string;
          username?: string;
          rating?: number;
          country?: string;
          avatar?: string;
          isGuest?: boolean;
        };
        if (!p.uid || !p.username) return;

        const existingUser = store.users[p.uid];
        if (existingUser?.isBanned) {
          sendWs(ws, 'auth:banned', { reason: existingUser.banReason || 'Account suspended' });
          return;
        }

        const c: ConnectedClient = {
          ws,
          uid: p.uid,
          playerId: p.playerId || existingUser?.playerId || p.uid,
          username: existingUser?.username || p.username,
          rating: existingUser?.rating ?? p.rating ?? 1200,
          country: existingUser?.country || p.country || 'Global',
          avatar: existingUser?.avatar || p.avatar || '/src/assets/images/avatar_knight_obsidian_1794980498230.jpg',
          isGuest: !!p.isGuest,
          roomId: null,
          msgTimestamps: [],
          chatSpamTimestamps: [],
        };

        for (const room of rooms.values()) {
          const part = room.participants.find((pt) => pt.uid === c.uid);
          if (part && room.status !== 'closed') {
            part.connected = true;
            c.roomId = room.roomId;
            sendWs(ws, 'room:reconnected', serializeRoom(room));
            broadcastRoom(room, 'room:updated', serializeRoom(room));
            break;
          }
        }

        clients.set(ws, c);
        if (!userSockets.has(c.uid)) userSockets.set(c.uid, new Set());
        userSockets.get(c.uid)!.add(ws);

        sendWs(ws, 'ui:config_updated', store.uiConfig);
        sendWs(ws, 'rooms:list', getPublicRoomsSummary());
        sendWs(ws, 'tournaments:updated', store.tournaments);
        sendWs(ws, 'learning:updated', store.learningVideos);
        broadcastAll('presence:update', getOnlinePlayersList());
        return;
      }

      if (!client) {
        sendWs(ws, 'error:notice', { message: 'Please identify before performing actions.' });
        return;
      }

      if (store.users[client.uid]?.isBanned) {
        sendWs(ws, 'auth:banned', { reason: store.users[client.uid].banReason });
        ws.close();
        return;
      }

      switch (msg.type) {
        case 'matchmaking:join': {
          const tc = (msg.payload?.timeControl || {
            id: '5+0',
            label: '5+0',
            category: 'blitz',
            initialSeconds: 300,
            incrementSeconds: 0,
          }) as TimeControlPayload;

          const idx = matchmakingQueue.findIndex((t) => t.uid === client.uid);
          if (idx >= 0) matchmakingQueue.splice(idx, 1);

          matchmakingQueue.push({
            uid: client.uid,
            playerId: client.playerId,
            username: client.username,
            rating: client.rating,
            country: client.country,
            avatar: client.avatar,
            timeControl: tc,
            queuedAt: Date.now(),
            ws,
          });
          sendWs(ws, 'matchmaking:queued', { timeControl: tc });
          break;
        }

        case 'matchmaking:leave': {
          const idx = matchmakingQueue.findIndex((t) => t.uid === client.uid);
          if (idx >= 0) matchmakingQueue.splice(idx, 1);
          sendWs(ws, 'matchmaking:cancelled', {});
          break;
        }

        case 'room:create': {
          const p = (msg.payload || {}) as {
            roomId?: string;
            roomName?: string;
            password?: string;
            gameMode?: string;
            timeControl?: TimeControlPayload;
            maxSpectators?: number;
            playAs?: 'w' | 'b' | 'random';
            allowSpectatorChat?: boolean;
          };

          const cleanCode = (p.roomId || `ARENA-${Math.random().toString(36).substring(2, 6).toUpperCase()}`)
            .replace(/[^a-zA-Z0-9_-]/g, '')
            .toUpperCase()
            .slice(0, 24);

          if (!cleanCode) {
            sendWs(ws, 'error:notice', { message: 'Invalid room code.' });
            return;
          }
          if (rooms.has(cleanCode)) {
            sendWs(ws, 'error:notice', { message: `Room ID "${cleanCode}" already exists.` });
            return;
          }

          const tc: TimeControlPayload = p.timeControl || {
            id: '10+0',
            label: '10+0',
            category: 'rapid',
            initialSeconds: 600,
            incrementSeconds: 0,
          };

          const passwordHash =
            p.password && String(p.password).trim().length > 0
              ? await bcrypt.hash(String(p.password).trim(), 8)
              : null;

          const ownerColor: 'w' | 'b' =
            p.playAs === 'b' ? 'b' : p.playAs === 'random' ? (Math.random() > 0.5 ? 'w' : 'b') : 'w';

          const room: ServerRoom = {
            roomId: cleanCode,
            roomName: String(p.roomName || `${client.username}'s Arena`).slice(0, 60),
            ownerId: client.uid,
            ownerName: client.username,
            gameMode: String(p.gameMode || tc.category),
            timeControl: tc,
            maxSpectators: Math.max(0, Math.min(100, Number(p.maxSpectators ?? 25))),
            passwordHash,
            allowSpectatorChat: p.allowSpectatorChat !== false,
            status: 'waiting',
            chess: new Chess(),
            whiteTimeMs: tc.initialSeconds * 1000,
            blackTimeMs: tc.initialSeconds * 1000,
            lastMoveAt: null,
            startedAt: null,
            drawOfferFrom: null,
            participants: [
              {
                uid: client.uid,
                playerId: client.playerId,
                username: client.username,
                rating: client.rating,
                country: client.country,
                avatar: client.avatar,
                role: 'player',
                color: ownerColor,
                connected: true,
              },
            ],
            chat: [
              {
                id: `sys_${Date.now()}`,
                senderId: 'system',
                senderName: 'Chess Arena',
                role: 'system',
                channel: 'room',
                text: `Room ${cleanCode} created by ${client.username}.`,
                timestamp: new Date().toISOString(),
              },
            ],
            createdAt: new Date().toISOString(),
          };

          rooms.set(cleanCode, room);
          client.roomId = cleanCode;
          sendWs(ws, 'room:joined', serializeRoom(room));
          broadcastAll('rooms:list', getPublicRoomsSummary());
          break;
        }

        case 'room:join': {
          const p = (msg.payload || {}) as {
            roomId?: string;
            password?: string;
            role?: 'player' | 'spectator';
          };
          const roomId = String(p.roomId || '').trim().toUpperCase();
          const room = rooms.get(roomId);
          if (!room || room.status === 'closed') {
            sendWs(ws, 'error:notice', { message: `Room "${roomId}" not found or closed.` });
            return;
          }

          const existingPart = room.participants.find((pt) => pt.uid === client.uid);
          if (!existingPart && room.passwordHash) {
            const supplied = String(p.password || '').trim();
            const ok = supplied.length > 0 && (await bcrypt.compare(supplied, room.passwordHash));
            if (!ok) {
              sendWs(ws, 'error:notice', { message: 'Incorrect room password.' });
              return;
            }
          }

          const desiredRole = p.role === 'spectator' ? 'spectator' : 'player';

          if (existingPart) {
            existingPart.connected = true;
            if (desiredRole === 'spectator' && existingPart.role === 'player' && room.status === 'waiting') {
              existingPart.role = 'spectator';
              delete existingPart.color;
            } else if (desiredRole === 'player' && existingPart.role === 'spectator' && room.status === 'waiting') {
              const players = room.participants.filter((pt) => pt.role === 'player');
              if (players.length < 2) {
                existingPart.role = 'player';
                existingPart.color = players.some((pl) => pl.color === 'w') ? 'b' : 'w';
              }
            }
          } else {
            if (desiredRole === 'player') {
              const currentPlayers = room.participants.filter((pt) => pt.role === 'player');
              if (currentPlayers.length >= 2) {
                sendWs(ws, 'error:notice', {
                  message: 'Room already has 2 players. You may join as a spectator.',
                });
                return;
              }
              const takenColor = currentPlayers[0]?.color;
              const color: 'w' | 'b' = takenColor === 'w' ? 'b' : 'w';
              room.participants.push({
                uid: client.uid,
                playerId: client.playerId,
                username: client.username,
                rating: client.rating,
                country: client.country,
                avatar: client.avatar,
                role: 'player',
                color,
                connected: true,
              });
            } else {
              const currentSpecs = room.participants.filter((pt) => pt.role === 'spectator');
              if (currentSpecs.length >= room.maxSpectators) {
                sendWs(ws, 'error:notice', { message: 'Spectator capacity for this room is full.' });
                return;
              }
              room.participants.push({
                uid: client.uid,
                playerId: client.playerId,
                username: client.username,
                rating: client.rating,
                country: client.country,
                avatar: client.avatar,
                role: 'spectator',
                connected: true,
              });
            }
          }

          client.roomId = roomId;
          room.chat.push({
            id: `sys_${Date.now()}_${Math.random()}`,
            senderId: 'system',
            senderName: 'Chess Arena',
            role: 'system',
            channel: desiredRole === 'spectator' ? 'spectator' : 'room',
            text: `${client.username} joined as ${desiredRole}.`,
            timestamp: new Date().toISOString(),
          });

          sendWs(ws, 'room:joined', serializeRoom(room));
          broadcastRoom(room, 'room:updated', serializeRoom(room));
          broadcastAll('rooms:list', getPublicRoomsSummary());
          break;
        }

        case 'room:toggle_spectator_chat': {
          const roomId = client.roomId;
          const room = roomId ? rooms.get(roomId) : undefined;
          if (!room || room.ownerId !== client.uid) return;
          room.allowSpectatorChat = !room.allowSpectatorChat;
          room.chat.push({
            id: `sys_${Date.now()}`,
            senderId: 'system',
            senderName: 'Chess Arena',
            role: 'system',
            channel: 'spectator',
            text: room.allowSpectatorChat
              ? 'Room owner enabled spectator chat.'
              : 'Room owner disabled spectator chat.',
            timestamp: new Date().toISOString(),
          });
          broadcastRoom(room, 'room:updated', serializeRoom(room));
          break;
        }

        case 'room:switch_role': {
          const roomId = client.roomId;
          const room = roomId ? rooms.get(roomId) : undefined;
          if (!room || room.status !== 'waiting') return;
          const part = room.participants.find((pt) => pt.uid === client.uid);
          if (!part) return;
          const targetRole = msg.payload?.role === 'spectator' ? 'spectator' : 'player';
          if (targetRole === 'spectator') {
            const specs = room.participants.filter((pt) => pt.role === 'spectator').length;
            if (specs >= room.maxSpectators) {
              sendWs(ws, 'error:notice', { message: 'Spectator limit reached.' });
              return;
            }
            part.role = 'spectator';
            delete part.color;
          } else {
            const players = room.participants.filter((pt) => pt.role === 'player');
            if (players.length >= 2) {
              sendWs(ws, 'error:notice', { message: 'Both player seats are occupied.' });
              return;
            }
            part.role = 'player';
            part.color = players.some((pl) => pl.color === 'w') ? 'b' : 'w';
          }
          broadcastRoom(room, 'room:updated', serializeRoom(room));
          break;
        }

        case 'room:start': {
          const roomId = client.roomId;
          const room = roomId ? rooms.get(roomId) : undefined;
          if (!room || room.ownerId !== client.uid) return;
          const players = room.participants.filter((pt) => pt.role === 'player');
          if (players.length < 2) {
            sendWs(ws, 'error:notice', { message: 'Need 2 players seated to start the match.' });
            return;
          }
          room.chess = new Chess();
          room.whiteTimeMs = room.timeControl.initialSeconds * 1000;
          room.blackTimeMs = room.timeControl.initialSeconds * 1000;
          room.status = 'playing';
          room.startedAt = Date.now();
          room.lastMoveAt = Date.now();
          room.winner = undefined;
          room.resultReason = undefined;
          room.drawOfferFrom = null;
          room.lastMove = undefined;
          room.chat.push({
            id: `sys_${Date.now()}`,
            senderId: 'system',
            senderName: 'Chess Arena',
            role: 'system',
            channel: 'room',
            text: 'Match started. Good luck!',
            timestamp: new Date().toISOString(),
          });
          broadcastRoom(room, 'room:updated', serializeRoom(room));
          broadcastAll('rooms:list', getPublicRoomsSummary());
          break;
        }

        case 'room:kick': {
          const roomId = client.roomId;
          const room = roomId ? rooms.get(roomId) : undefined;
          const targetUid = String(msg.payload?.targetUid || '');
          if (!room || room.ownerId !== client.uid || targetUid === client.uid) return;
          room.participants = room.participants.filter((pt) => pt.uid !== targetUid);
          const targetSockets = userSockets.get(targetUid);
          if (targetSockets) {
            for (const s of targetSockets) {
              const tc = clients.get(s);
              if (tc && tc.roomId === roomId) tc.roomId = null;
              sendWs(s, 'room:kicked', { roomId, reason: 'Removed by room owner.' });
            }
          }
          broadcastRoom(room, 'room:updated', serializeRoom(room));
          broadcastAll('rooms:list', getPublicRoomsSummary());
          break;
        }

        case 'room:close': {
          const roomId = client.roomId;
          const room = roomId ? rooms.get(roomId) : undefined;
          if (!room || room.ownerId !== client.uid) return;
          room.status = 'closed';
          broadcastRoom(room, 'room:closed', {
            roomId,
            reason: 'The room owner closed this room.',
          });
          for (const pt of room.participants) {
            const sockets = userSockets.get(pt.uid);
            if (sockets) {
              for (const s of sockets) {
                const c = clients.get(s);
                if (c && c.roomId === roomId) c.roomId = null;
              }
            }
          }
          rooms.delete(roomId!);
          broadcastAll('rooms:list', getPublicRoomsSummary());
          break;
        }

        case 'room:leave': {
          const roomId = client.roomId;
          const room = roomId ? rooms.get(roomId) : undefined;
          if (!room) return;
          const part = room.participants.find((pt) => pt.uid === client.uid);
          if (part?.role === 'player' && room.status === 'playing') {
            const winner = part.color === 'w' ? 'black' : 'white';
            finalizeServerMatch(room, winner, `${part.username} left the match`);
          }
          room.participants = room.participants.filter((pt) => pt.uid !== client.uid);
          client.roomId = null;
          if (room.participants.length === 0) {
            rooms.delete(roomId!);
          } else {
            broadcastRoom(room, 'room:updated', serializeRoom(room));
          }
          broadcastAll('rooms:list', getPublicRoomsSummary());
          break;
        }

        case 'game:move': {
          const roomId = String(msg.payload?.roomId || client.roomId || '');
          const room = rooms.get(roomId);
          if (!room || room.status !== 'playing') return;

          const player = room.participants.find((pt) => pt.uid === client.uid && pt.role === 'player');
          if (!player) {
            sendWs(ws, 'error:notice', { message: 'Spectators cannot make moves.' });
            return;
          }
          if (room.chess.turn() !== player.color) {
            sendWs(ws, 'error:notice', { message: 'Not your turn.' });
            return;
          }

          const from = String(msg.payload?.from || '');
          const to = String(msg.payload?.to || '');
          const promotion = msg.payload?.promotion ? String(msg.payload.promotion) : undefined;

          try {
            const moveResult = room.chess.move({
              from,
              to,
              promotion: promotion as 'q' | 'r' | 'b' | 'n' | undefined,
            });
            if (!moveResult) {
              sendWs(ws, 'error:notice', { message: 'Illegal move.' });
              return;
            }

            const now = Date.now();
            if (room.lastMoveAt) {
              const elapsed = now - room.lastMoveAt;
              if (player.color === 'w') {
                room.whiteTimeMs = Math.max(0, room.whiteTimeMs - elapsed) + room.timeControl.incrementSeconds * 1000;
              } else {
                room.blackTimeMs = Math.max(0, room.blackTimeMs - elapsed) + room.timeControl.incrementSeconds * 1000;
              }
            }
            room.lastMoveAt = now;
            room.lastMove = { from: moveResult.from, to: moveResult.to };
            room.drawOfferFrom = null;

            if (room.chess.isCheckmate()) {
              const winner = player.color === 'w' ? 'white' : 'black';
              finalizeServerMatch(room, winner, 'Checkmate');
            } else if (room.chess.isStalemate()) {
              finalizeServerMatch(room, 'draw', 'Stalemate');
            } else if (room.chess.isThreefoldRepetition()) {
              finalizeServerMatch(room, 'draw', 'Draw by threefold repetition');
            } else if (room.chess.isInsufficientMaterial()) {
              finalizeServerMatch(room, 'draw', 'Draw by insufficient material');
            } else if (room.chess.isDraw()) {
              finalizeServerMatch(room, 'draw', 'Draw by 50-move rule');
            } else {
              broadcastRoom(room, 'room:updated', serializeRoom(room));
            }
          } catch {
            sendWs(ws, 'error:notice', { message: 'Invalid move.' });
          }
          break;
        }

        case 'game:resign': {
          const roomId = String(msg.payload?.roomId || client.roomId || '');
          const room = rooms.get(roomId);
          if (!room || room.status !== 'playing') return;
          const player = room.participants.find((pt) => pt.uid === client.uid && pt.role === 'player');
          if (!player) return;
          const winner = player.color === 'w' ? 'black' : 'white';
          finalizeServerMatch(room, winner, `${player.username} resigned`);
          break;
        }

        case 'game:draw_offer': {
          const roomId = String(msg.payload?.roomId || client.roomId || '');
          const room = rooms.get(roomId);
          if (!room || room.status !== 'playing') return;
          const player = room.participants.find((pt) => pt.uid === client.uid && pt.role === 'player');
          if (!player) return;
          room.drawOfferFrom = client.uid;
          broadcastRoom(room, 'room:updated', serializeRoom(room));
          break;
        }

        case 'game:draw_response': {
          const roomId = String(msg.payload?.roomId || client.roomId || '');
          const room = rooms.get(roomId);
          if (!room || room.status !== 'playing' || !room.drawOfferFrom) return;
          const player = room.participants.find((pt) => pt.uid === client.uid && pt.role === 'player');
          if (!player || room.drawOfferFrom === client.uid) return;
          if (msg.payload?.accept) {
            finalizeServerMatch(room, 'draw', 'Draw by mutual agreement');
          } else {
            room.drawOfferFrom = null;
            broadcastRoom(room, 'room:updated', serializeRoom(room));
          }
          break;
        }

        case 'room:chat': {
          const roomId = String(msg.payload?.roomId || client.roomId || '');
          const room = rooms.get(roomId);
          if (!room) return;
          const part = room.participants.find((pt) => pt.uid === client.uid);
          if (!part) return;

          const now = Date.now();
          client.chatSpamTimestamps = client.chatSpamTimestamps.filter((t) => now - t < 8000);
          if (client.chatSpamTimestamps.length >= 5) {
            sendWs(ws, 'error:notice', { message: 'Slow down — chat spam protection triggered.' });
            return;
          }

          const text = String(msg.payload?.text || '').trim().slice(0, 300);
          const emoji = msg.payload?.emoji ? String(msg.payload.emoji).slice(0, 12) : undefined;
          if (!text && !emoji) return;

          if (client.lastChatText === text && client.lastChatAt && now - client.lastChatAt < 3000) {
            sendWs(ws, 'error:notice', { message: 'Duplicate message ignored by spam filter.' });
            return;
          }

          let channel: 'room' | 'spectator' = msg.payload?.channel === 'spectator' ? 'spectator' : 'room';
          // Enforce spectator permissions so spectators never interfere with player chat
          if (part.role === 'spectator') {
            if (!room.allowSpectatorChat) {
              sendWs(ws, 'error:notice', { message: 'Spectator chat has been disabled by the room owner.' });
              return;
            }
            channel = 'spectator';
          }

          client.chatSpamTimestamps.push(now);
          client.lastChatText = text;
          client.lastChatAt = now;

          const chatMsg: RoomChatMessage = {
            id: `chat_${now}_${Math.random().toString(36).slice(2, 6)}`,
            senderId: client.uid,
            senderName: client.username,
            senderAvatar: client.avatar,
            role: part.role,
            channel,
            text,
            emoji,
            timestamp: new Date().toISOString(),
          };

          room.chat.push(chatMsg);
          if (room.chat.length > 150) room.chat.shift();
          broadcastRoom(room, 'room:updated', serializeRoom(room));
          break;
        }

        case 'friend:invite': {
          const targetUid = String(msg.payload?.targetUid || '');
          const timeControl = (msg.payload?.timeControl || {
            id: '5+0',
            label: '5+0',
            category: 'blitz',
            initialSeconds: 300,
            incrementSeconds: 0,
          }) as TimeControlPayload;

          const targetUser = store.users[targetUid];
          if (targetUser?.privacyAllowInvites === 'none') {
            sendWs(ws, 'error:notice', { message: 'This player has disabled match invitations.' });
            return;
          }

          const roomId = `FR-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
          const room: ServerRoom = {
            roomId,
            roomName: `${client.username} vs ${targetUser?.username || 'Friend'}`,
            ownerId: client.uid,
            ownerName: client.username,
            gameMode: timeControl.category,
            timeControl,
            maxSpectators: 10,
            passwordHash: null,
            allowSpectatorChat: true,
            status: 'waiting',
            chess: new Chess(),
            whiteTimeMs: timeControl.initialSeconds * 1000,
            blackTimeMs: timeControl.initialSeconds * 1000,
            lastMoveAt: null,
            startedAt: null,
            drawOfferFrom: null,
            participants: [
              {
                uid: client.uid,
                playerId: client.playerId,
                username: client.username,
                rating: client.rating,
                country: client.country,
                avatar: client.avatar,
                role: 'player',
                color: 'w',
                connected: true,
              },
            ],
            chat: [],
            createdAt: new Date().toISOString(),
          };
          rooms.set(roomId, room);
          client.roomId = roomId;
          sendWs(ws, 'room:joined', serializeRoom(room));

          const targetSockets = userSockets.get(targetUid);
          if (targetSockets) {
            for (const s of targetSockets) {
              sendWs(s, 'friend:invited', {
                roomId,
                fromUid: client.uid,
                fromUsername: client.username,
                fromRating: client.rating,
                timeControl,
              });
            }
          }
          break;
        }

        case 'tournament:create': {
          const p = (msg.payload || {}) as {
            title?: string;
            format?: 'knockout' | 'round_robin';
            visibility?: 'public' | 'private';
            timeControl?: string;
            maxPlayers?: number;
          };
          const title = String(p.title || '').trim().slice(0, 80);
          if (title.length < 3) {
            sendWs(ws, 'error:notice', { message: 'Tournament title must be at least 3 characters.' });
            return;
          }
          const tourn: StoredTournament = {
            tournamentId: `TR-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
            title,
            format: p.format === 'round_robin' ? 'round_robin' : 'knockout',
            visibility: p.visibility === 'private' ? 'private' : 'public',
            status: 'registration',
            timeControl: String(p.timeControl || '5+0'),
            maxPlayers: Math.max(2, Math.min(32, Number(p.maxPlayers || 8))),
            createdBy: client.uid,
            creatorName: client.username,
            participants: [client.uid],
            participantDetails: [
              {
                uid: client.uid,
                username: client.username,
                rating: client.rating,
                country: client.country,
              },
            ],
            matches: [],
            standings: [
              {
                uid: client.uid,
                username: client.username,
                rating: client.rating,
                points: 0,
                wins: 0,
                draws: 0,
                losses: 0,
              },
            ],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          store.tournaments.unshift(tourn);
          persistStore();
          broadcastAll('tournaments:updated', store.tournaments);
          break;
        }

        case 'tournament:join': {
          const tourn = store.tournaments.find((t) => t.tournamentId === msg.payload?.tournamentId);
          if (!tourn || tourn.status !== 'registration') return;
          if (tourn.participants.includes(client.uid)) return;
          if (tourn.participants.length >= tourn.maxPlayers) {
            sendWs(ws, 'error:notice', { message: 'Tournament is full.' });
            return;
          }
          tourn.participants.push(client.uid);
          tourn.participantDetails.push({
            uid: client.uid,
            username: client.username,
            rating: client.rating,
            country: client.country,
          });
          tourn.standings.push({
            uid: client.uid,
            username: client.username,
            rating: client.rating,
            points: 0,
            wins: 0,
            draws: 0,
            losses: 0,
          });
          tourn.updatedAt = new Date().toISOString();
          persistStore();
          broadcastAll('tournaments:updated', store.tournaments);
          break;
        }

        case 'tournament:start': {
          const tourn = store.tournaments.find((t) => t.tournamentId === msg.payload?.tournamentId);
          if (!tourn || tourn.createdBy !== client.uid || tourn.status !== 'registration') return;
          if (tourn.participantDetails.length < 2) {
            sendWs(ws, 'error:notice', { message: 'At least 2 players are needed to start.' });
            return;
          }
          tourn.status = 'active';
          tourn.matches = [];
          const players = [...tourn.participantDetails];
          if (tourn.format === 'round_robin') {
            let matchIdx = 1;
            for (let i = 0; i < players.length; i++) {
              for (let j = i + 1; j < players.length; j++) {
                tourn.matches.push({
                  id: `tm_${tourn.tournamentId}_${matchIdx++}`,
                  round: 1,
                  whiteUid: players[i].uid,
                  whiteName: players[i].username,
                  blackUid: players[j].uid,
                  blackName: players[j].username,
                  status: 'pending',
                });
              }
            }
          } else {
            for (let i = 0; i < players.length; i += 2) {
              const w = players[i];
              const b = players[i + 1];
              if (b) {
                tourn.matches.push({
                  id: `tm_${tourn.tournamentId}_${i / 2 + 1}`,
                  round: 1,
                  whiteUid: w.uid,
                  whiteName: w.username,
                  blackUid: b.uid,
                  blackName: b.username,
                  status: 'pending',
                });
              } else {
                tourn.matches.push({
                  id: `tm_${tourn.tournamentId}_bye_${i}`,
                  round: 1,
                  whiteUid: w.uid,
                  whiteName: w.username,
                  blackName: 'BYE',
                  winnerUid: w.uid,
                  status: 'completed',
                });
              }
            }
          }
          tourn.updatedAt = new Date().toISOString();
          persistStore();
          broadcastAll('tournaments:updated', store.tournaments);
          break;
        }

        case 'tournament:launch_match': {
          const tourn = store.tournaments.find((t) => t.tournamentId === msg.payload?.tournamentId);
          const tm = tourn?.matches.find((m) => m.id === msg.payload?.matchId);
          if (!tourn || !tm || !tm.whiteUid || !tm.blackUid) return;
          if (client.uid !== tm.whiteUid && client.uid !== tm.blackUid) return;

          if (tm.roomId && rooms.has(tm.roomId)) {
            const existingRoom = rooms.get(tm.roomId)!;
            client.roomId = existingRoom.roomId;
            sendWs(ws, 'room:joined', serializeRoom(existingRoom));
            return;
          }

          const [minsStr, incStr] = tourn.timeControl.split('+');
          const tc: TimeControlPayload = {
            id: tourn.timeControl,
            label: tourn.timeControl,
            category: 'blitz',
            initialSeconds: Math.max(60, Number(minsStr || 5) * 60),
            incrementSeconds: Math.max(0, Number(incStr || 0)),
          };

          const whiteDetail = tourn.participantDetails.find((p) => p.uid === tm.whiteUid)!;
          const blackDetail = tourn.participantDetails.find((p) => p.uid === tm.blackUid)!;
          const roomId = `TM-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

          const room: ServerRoom = {
            roomId,
            roomName: `${tourn.title} — Round ${tm.round}`,
            ownerId: tourn.createdBy,
            ownerName: tourn.creatorName,
            gameMode: 'tournament',
            timeControl: tc,
            maxSpectators: 50,
            passwordHash: null,
            allowSpectatorChat: true,
            status: 'playing',
            chess: new Chess(),
            whiteTimeMs: tc.initialSeconds * 1000,
            blackTimeMs: tc.initialSeconds * 1000,
            lastMoveAt: Date.now(),
            startedAt: Date.now(),
            drawOfferFrom: null,
            participants: [
              {
                uid: whiteDetail.uid,
                playerId: whiteDetail.uid,
                username: whiteDetail.username,
                rating: whiteDetail.rating,
                country: whiteDetail.country,
                avatar: '/src/assets/images/avatar_knight_obsidian_1794980498230.jpg',
                role: 'player',
                color: 'w',
                connected: true,
              },
              {
                uid: blackDetail.uid,
                playerId: blackDetail.uid,
                username: blackDetail.username,
                rating: blackDetail.rating,
                country: blackDetail.country,
                avatar: '/src/assets/images/avatar_queen_gold_1794980498804.jpg',
                role: 'player',
                color: 'b',
                connected: true,
              },
            ],
            chat: [],
            createdAt: new Date().toISOString(),
            isTournamentMatch: true,
            tournamentId: tourn.tournamentId,
            tournamentMatchId: tm.id,
          };

          tm.roomId = roomId;
          tm.status = 'active';
          rooms.set(roomId, room);
          persistStore();
          broadcastAll('tournaments:updated', store.tournaments);

          for (const uid of [whiteDetail.uid, blackDetail.uid]) {
            const socks = userSockets.get(uid);
            if (socks) {
              for (const s of socks) {
                const c = clients.get(s);
                if (c) c.roomId = roomId;
                sendWs(s, 'room:joined', serializeRoom(room));
              }
            }
          }
          break;
        }
      }
    });

    ws.on('close', () => {
      const client = clients.get(ws);
      if (!client) return;
      clients.delete(ws);

      const qIdx = matchmakingQueue.findIndex((t) => t.ws === ws);
      if (qIdx >= 0) matchmakingQueue.splice(qIdx, 1);

      const socks = userSockets.get(client.uid);
      if (socks) {
        socks.delete(ws);
        if (socks.size === 0) {
          userSockets.delete(client.uid);
          if (client.roomId) {
            const room = rooms.get(client.roomId);
            if (room) {
              const part = room.participants.find((pt) => pt.uid === client.uid);
              if (part) {
                part.connected = false;
                broadcastRoom(room, 'room:updated', serializeRoom(room));
              }
            }
          }
        }
      }
      broadcastAll('presence:update', getOnlinePlayersList());
    });
  });

  // --- Vite Middleware / Production Static Serve ---
  if (process.env.NODE_ENV !== 'production') {
    if (process.env.DISABLE_HMR === 'true') {
      // Serve a clean no-socket Vite client shim when HMR is disabled so Vite 8 never attempts an unconfigured port 24678 WebSocket
      app.get('/@vite/client', (_req, res) => {
        res.type('application/javascript').send(`
const sheetsMap = new Map();
const linkSheetsMap = new Map();
if (typeof document !== 'undefined') {
  document.querySelectorAll('style[data-vite-dev-id]').forEach((el) => {
    sheetsMap.set(el.getAttribute('data-vite-dev-id'), el);
  });
  document.querySelectorAll('link[rel="stylesheet"][data-vite-dev-id]').forEach((el) => {
    linkSheetsMap.set(el.getAttribute('data-vite-dev-id'), el);
  });
}
export class ErrorOverlay extends HTMLElement {}
export function updateStyle(id, content) {
  if (linkSheetsMap.has(id)) return;
  let style = sheetsMap.get(id);
  if (!style) {
    style = document.createElement('style');
    style.setAttribute('type', 'text/css');
    style.setAttribute('data-vite-dev-id', id);
    style.textContent = content;
    document.head.appendChild(style);
    sheetsMap.set(id, style);
  } else if (style.textContent !== content) {
    style.textContent = content;
  }
}
export function removeStyle(id) {
  const style = sheetsMap.get(id);
  if (style && style.parentNode) style.parentNode.removeChild(style);
  sheetsMap.delete(id);
}
export function createHotContext() {
  return {
    data: {},
    accept() {},
    acceptExports() {},
    dispose() {},
    prune() {},
    decline() {},
    invalidate() {},
    on() {},
    off() {},
    send() {},
  };
}
export function injectQuery(url) {
  return url;
}
`);
      });
    }

    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        allowedHosts: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : { server },
        ws: { server },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`CHESS ARENA server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
