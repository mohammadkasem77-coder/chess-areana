import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import {
  Ban,
  Bell,
  BookOpen,
  LayoutDashboard,
  Menu,
  Swords,
  Trophy,
  Award,
  User as UserIcon,
  Users,
  X,
} from 'lucide-react';
import { AdminPanelView } from './components/AdminPanelView';
import { AuthModal } from './components/AuthModal';
import { DashboardView } from './components/DashboardView';
import { GameMatchPage } from './components/GameMatchPage';
import { LeaderboardView } from './components/LeaderboardView';
import { PlayArenaView } from './components/PlayArenaView';
import { PlayersDirectoryView } from './components/PlayersDirectoryView';
import { ProfileSettingsView } from './components/ProfileSettingsView';
import { OfflineIndicator, PWAInstallButton } from './components/PWAInstallButton';
import { TournamentsView } from './components/TournamentsView';
import { TrainingCenterView } from './components/TrainingCenterView';
import { VisualEditorOverlay, VisualEditTarget } from './components/VisualEditorOverlay';
import { AVATAR_OPTIONS } from './data/themes';
import { DEFAULT_LEARNING_VIDEOS } from './data/trainingData';
import { auth } from './firebase';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import {
  ensureUserProfile,
  fetchActiveAnnouncementsFirestore,
  fetchLeaderboardUsers,
  fetchLearningVideosFirestore,
  fetchUiConfigFirestore,
  fetchUserMatches,
  respondFriendRequestDoc,
  saveMatchRecordToFirestore,
  sendFriendRequestDoc,
  submitPlayerReportDoc,
  subscribeFriendRequests,
  updateUserProfileFields,
} from './services/firestoreService';
import {
  Announcement,
  AppUiConfig,
  BoardThemeId,
  FriendRequest,
  LearningVideo,
  LocalMatchSetup,
  MatchRecord,
  NotificationItem,
  PieceStyleId,
  PrivateRoomState,
  PuzzleItem,
  Tournament,
  UserPreferences,
  UserProfile,
} from './types/chess';
import {
  getOfflineMatches,
  markOfflineMatchesSynced,
  saveOfflineMatch,
} from './utils/offlineStorage';
import { soundFX } from './utils/soundFX';

const DEFAULT_UI_CONFIG: AppUiConfig = {
  siteTitle: 'CHESS ARENA',
  heroHeadline: 'Master the Board Across the Globe',
  heroSubtitle:
    'Compete in ranked worldwide matchmaking, private rooms, and grandmaster training with live synchronized clocks.',
  heroImageUrl: '/src/assets/images/hero_chess_arena_1794980498823.jpg',
  accentColor: '#D4AF37',
  canvasColor: '#0A0A0C',
  surfaceColor: '#141418',
  defaultBoardTheme: 'classic_wood',
  defaultPieceStyle: 'staunton',
  bannerText: '',
  dailyTip: '',
  allowGuestPlay: true,
  maintenanceMode: false,
  showLeaderboards: true,
  showTournaments: true,
  showTraining: true,
  showPlayersDirectory: true,
  navLabels: {
    dashboard: 'Dashboard',
    play: 'Play Arena',
    players: 'Players',
    training: 'Learning',
    tournaments: 'Tournaments',
    leaderboards: 'Rankings',
  },
  sectionOrder: ['banner', 'hero', 'dailyTip', 'metrics', 'mainGrid'],
  updatedAt: new Date().toISOString(),
};

const DEFAULT_PREFERENCES: UserPreferences = {
  colorMode: 'dark',
  soundEnabled: true,
  notifyInvites: true,
  notifyMessages: true,
  notifyTournaments: true,
  highContrast: false,
  largeText: false,
  reducedMotion: false,
};

function loadPreferences(): UserPreferences {
  try {
    const raw = localStorage.getItem('ca_preferences');
    if (raw) return { ...DEFAULT_PREFERENCES, ...JSON.parse(raw) };
  } catch {
    // ignore
  }
  return DEFAULT_PREFERENCES;
}

function createGuestUser(): UserProfile {
  let savedId = localStorage.getItem('ca_guest_uid');
  if (!savedId) {
    savedId = `guest_${Math.random().toString(36).substring(2, 10)}`;
    localStorage.setItem('ca_guest_uid', savedId);
  }
  const suffix = savedId.slice(-4).toUpperCase();
  const savedProfile = localStorage.getItem('ca_guest_profile');
  if (savedProfile) {
    try {
      return JSON.parse(savedProfile) as UserProfile;
    } catch {
      // fallback
    }
  }
  return {
    uid: savedId,
    playerId: `CA-GUEST-${suffix}`,
    username: `Challenger_${suffix}`,
    displayName: `Challenger_${suffix}`,
    bio: '',
    country: 'Global',
    avatar: AVATAR_OPTIONS[0].url,
    chessExperience: 'Casual Player',
    learningJourney: '',
    mentorName: '',
    favoritePlayer: '',
    favoriteOpening: 'Italian Game',
    profileTheme: 'obsidian_gold',
    profileFrame: 'gold_laurel',
    privacySections: {
      stats: true,
      matchHistory: true,
      achievements: true,
      learningJourney: true,
      friends: true,
      favoriteOpenings: true,
    },
    rating: 1200,
    peakRating: 1200,
    puzzleRating: 1200,
    puzzlesSolved: 0,
    xp: 0,
    level: 1,
    points: 100,
    wins: 0,
    losses: 0,
    draws: 0,
    winStreak: 0,
    bestWinStreak: 0,
    totalMoves: 0,
    fastestWinSeconds: 0,
    longestMatchSeconds: 0,
    totalMatchDurationSeconds: 0,
    isBanned: false,
    privacyAllowMessages: 'everyone',
    privacyAllowInvites: 'everyone',
    dailyLoginStreak: 1,
    lastDailyClaim: '',
    achievements: [],
    following: [],
    blockedUids: [],
    completedVideos: [],
    favoriteVideos: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isGuest: true,
  };
}

export default function App() {
  const isOnline = useOnlineStatus();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [playSubMode, setPlaySubMode] = useState<string>('ai');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [mobileMoreOpen, setMobileMoreOpen] = useState(false);

  const [user, setUser] = useState<UserProfile>(() => createGuestUser());
  const [preferences, setPreferences] = useState<UserPreferences>(() => loadPreferences());
  const [uiConfig, setUiConfig] = useState<AppUiConfig>(DEFAULT_UI_CONFIG);
  const [boardTheme, setBoardTheme] = useState<BoardThemeId>('classic_wood');
  const [pieceStyle, setPieceStyle] = useState<PieceStyleId>('staunton');

  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [learningVideos, setLearningVideos] = useState<LearningVideo[]>(DEFAULT_LEARNING_VIDEOS);
  const [leaderboard, setLeaderboard] = useState<UserProfile[]>([]);
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [publicRooms, setPublicRooms] = useState<PrivateRoomState[]>([]);
  const [onlinePlayers, setOnlinePlayers] = useState<
    {
      uid: string;
      playerId: string;
      username: string;
      rating: number;
      country: string;
      avatar: string;
      inGame: boolean;
    }[]
  >([]);
  const [recentMatches, setRecentMatches] = useState<MatchRecord[]>(() => getOfflineMatches());
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  const [wsConnected, setWsConnected] = useState(false);
  const [activeRoom, setActiveRoom] = useState<PrivateRoomState | null>(null);
  const [localMatchSetup, setLocalMatchSetup] = useState<LocalMatchSetup | null>(null);
  const [roomClosedMsg, setRoomClosedMsg] = useState<string | null>(null);
  const [matchmakingQueued, setMatchmakingQueued] = useState(false);
  const [replayMatch, setReplayMatch] = useState<MatchRecord | null>(null);
  const [bannedNotice, setBannedNotice] = useState<string | null>(null);
  const [wsToast, setWsToast] = useState<string | null>(null);
  const [puzzlesToday, setPuzzlesToday] = useState(0);
  const [matchesToday, setMatchesToday] = useState(0);

  // Interactive Visual Editor State (Super Admin Only)
  const [visualEditMode, setVisualEditMode] = useState(false);
  const [visualToken, setVisualToken] = useState('');
  const [visualHistory, setVisualHistory] = useState<AppUiConfig[]>([]);
  const [visualHistoryIdx, setVisualHistoryIdx] = useState(-1);
  const [selectedVisualTarget, setSelectedVisualTarget] = useState<VisualEditTarget>('heroHeadline');
  const [visualSaveStatus, setVisualSaveStatus] = useState('');

  const wsRef = useRef<WebSocket | null>(null);
  const userRef = useRef<UserProfile>(user);
  userRef.current = user;

  const activeVisualConfig =
    visualEditMode && visualHistory[visualHistoryIdx]
      ? visualHistory[visualHistoryIdx]
      : uiConfig;

  // Apply dynamic UI colors from Admin / Visual Editor
  useEffect(() => {
    document.documentElement.style.setProperty('--arena-canvas', activeVisualConfig.canvasColor);
    document.documentElement.style.setProperty('--arena-surface', activeVisualConfig.surfaceColor);
    document.documentElement.style.setProperty('--arena-accent', activeVisualConfig.accentColor);
  }, [activeVisualConfig]);

  // Apply user accessibility & appearance preferences
  useEffect(() => {
    soundFX.muted = !preferences.soundEnabled;
    const root = document.documentElement;
    root.classList.toggle('light-theme', preferences.colorMode === 'light');
    root.classList.toggle('high-contrast', preferences.highContrast);
    root.classList.toggle('large-text', preferences.largeText);
    root.classList.toggle('reduced-motion', preferences.reducedMotion);
    localStorage.setItem('ca_preferences', JSON.stringify(preferences));
  }, [preferences]);

  // Load initial bootstrap data from server + Firestore
  useEffect(() => {
    if (!isOnline) return;
    fetch('/api/bootstrap')
      .then((r) => r.json())
      .then((data) => {
        if (data.uiConfig) {
          setUiConfig((prev) => ({ ...prev, ...data.uiConfig }));
          setBoardTheme((data.uiConfig.defaultBoardTheme as BoardThemeId) || 'classic_wood');
          setPieceStyle((data.uiConfig.defaultPieceStyle as PieceStyleId) || 'staunton');
        }
        if (Array.isArray(data.announcements)) setAnnouncements(data.announcements);
        if (Array.isArray(data.learningVideos) && data.learningVideos.length > 0) {
          setLearningVideos(data.learningVideos);
        }
        if (Array.isArray(data.leaderboard)) setLeaderboard(data.leaderboard);
        if (Array.isArray(data.tournaments)) setTournaments(data.tournaments);
        if (Array.isArray(data.publicRooms)) setPublicRooms(data.publicRooms);
        if (Array.isArray(data.recentMatches)) {
          setRecentMatches((prev) => {
            const map = new Map<string, MatchRecord>();
            for (const m of [...data.recentMatches, ...prev]) map.set(m.matchId, m);
            return Array.from(map.values()).slice(0, 50);
          });
        }
      })
      .catch(() => {});

    fetchUiConfigFirestore().then((cfg) => {
      if (cfg) setUiConfig((prev) => ({ ...prev, ...cfg }));
    });
    fetchActiveAnnouncementsFirestore().then((anns) => {
      if (anns.length > 0) setAnnouncements(anns);
    });
    fetchLearningVideosFirestore().then((vids) => {
      if (vids.length > 0) {
        setLearningVideos((prev) => {
          const map = new Map<string, LearningVideo>();
          for (const v of [...prev, ...vids]) map.set(v.videoId, v);
          return Array.from(map.values());
        });
      }
    });
    fetchLeaderboardUsers().then((users) => {
      if (users.length > 0) {
        setLeaderboard((prev) => {
          const map = new Map<string, UserProfile>();
          for (const u of [...prev, ...users]) map.set(u.uid, u);
          return Array.from(map.values()).sort((a, b) => b.rating - a.rating);
        });
      }
    });
  }, [isOnline]);

  // Firebase Auth listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const profile = await ensureUserProfile(
            fbUser.uid,
            fbUser.displayName || fbUser.email?.split('@')[0] || 'Player',
            fbUser.email || ''
          );
          if (profile.isBanned) {
            setBannedNotice(profile.banReason || 'Your account has been suspended.');
          }
          const res = await fetch('/api/users/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(profile),
          });
          if (res.status === 403) {
            const errData = await res.json();
            setBannedNotice(errData.banReason || 'Your account has been banned by an administrator.');
          } else if (res.ok) {
            const synced = await res.json();
            setUser({ ...profile, ...synced.user, isGuest: false });
          } else {
            setUser({ ...profile, isGuest: false });
          }

          const fsMatches = await fetchUserMatches(fbUser.uid);
          if (fsMatches.length > 0) {
            setRecentMatches((prev) => {
              const map = new Map<string, MatchRecord>();
              for (const m of [...fsMatches, ...prev]) map.set(m.matchId, m);
              return Array.from(map.values());
            });
          }
        } catch (err) {
          console.error('Profile sync error:', err);
        }
      } else {
        setUser(createGuestUser());
      }
    });
    return () => unsub();
  }, []);

  // Firestore Friend Requests real-time listener
  useEffect(() => {
    if (!user.uid || user.isGuest || !isOnline) return;
    return subscribeFriendRequests(user.uid, (reqs) => {
      setFriendRequests(reqs);
    });
  }, [user.uid, user.isGuest, isOnline]);

  // Automatic Offline Match Sync when internet reconnects
  useEffect(() => {
    if (!isOnline || user.isGuest) return;
    const unsynced = getOfflineMatches().filter((m) => !m.synced);
    if (unsynced.length === 0) return;

    fetch('/api/matches/offline-sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid: user.uid, matches: unsynced }),
    })
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data.syncedIds)) {
          markOfflineMatchesSynced(data.syncedIds);
        }
        if (data.user) {
          setUser((prev) => ({ ...prev, ...data.user }));
        }
      })
      .catch(() => {});
  }, [isOnline, user.uid, user.isGuest]);

  const sendWs = useCallback((type: string, payload: unknown) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type, payload }));
    }
  }, []);

  // WebSocket Real-Time Connection with Auto-Reconnect
  useEffect(() => {
    if (!isOnline) {
      setWsConnected(false);
      return;
    }

    let closedByCleanup = false;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;

    const connect = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => {
        setWsConnected(true);
        const u = userRef.current;
        ws.send(
          JSON.stringify({
            type: 'auth:identify',
            payload: {
              uid: u.uid,
              playerId: u.playerId,
              username: u.username,
              rating: u.rating,
              country: u.country,
              avatar: u.avatar,
              isGuest: u.isGuest,
            },
          })
        );
      };

      ws.onmessage = (ev) => {
        let msg: { type: string; payload: any };
        try {
          msg = JSON.parse(ev.data);
        } catch {
          return;
        }

        switch (msg.type) {
          case 'ui:config_updated':
            setUiConfig((prev) => ({ ...prev, ...msg.payload }));
            break;
          case 'announcements:updated':
            setAnnouncements(msg.payload || []);
            break;
          case 'learning:updated':
            if (Array.isArray(msg.payload)) setLearningVideos(msg.payload);
            break;
          case 'presence:update':
            setOnlinePlayers(msg.payload || []);
            break;
          case 'rooms:list':
            setPublicRooms(msg.payload || []);
            break;
          case 'tournaments:updated':
            setTournaments(msg.payload || []);
            break;
          case 'matchmaking:queued':
            setMatchmakingQueued(true);
            break;
          case 'matchmaking:cancelled':
            setMatchmakingQueued(false);
            break;
          case 'matchmaking:found':
            setMatchmakingQueued(false);
            setLocalMatchSetup(null);
            setActiveRoom(msg.payload);
            soundFX.playCheck();
            break;
          case 'room:joined':
          case 'room:reconnected':
            setRoomClosedMsg(null);
            setLocalMatchSetup(null);
            setActiveRoom(msg.payload);
            break;
          case 'room:updated':
            setActiveRoom(msg.payload);
            soundFX.playMove();
            break;
          case 'room:closed':
          case 'room:kicked':
            setActiveRoom(null);
            setRoomClosedMsg(msg.payload?.reason || 'Room closed.');
            break;
          case 'game:ended': {
            setActiveRoom(msg.payload.room);
            soundFX.playGameEnd();
            const mr = msg.payload.matchRecord as MatchRecord | undefined;
            if (mr) {
              setRecentMatches((prev) => [mr, ...prev.filter((x) => x.matchId !== mr.matchId)]);
              setMatchesToday((c) => c + 1);
              if (!userRef.current.isGuest) {
                saveMatchRecordToFirestore(mr).catch(() => {});
              }
            }
            break;
          }
          case 'friend:invited': {
            const inv = msg.payload;
            setNotifications((prev) => [
              {
                id: `inv_${Date.now()}`,
                title: `Match Invitation from ${inv.fromUsername}`,
                body: `Time control ${inv.timeControl?.label || '5+0'} · Room ${inv.roomId}`,
                type: 'invite',
                timestamp: new Date().toISOString(),
                read: false,
                roomId: inv.roomId,
              },
              ...prev,
            ]);
            setWsToast(`${inv.fromUsername} invited you to Room ${inv.roomId}`);
            setTimeout(() => setWsToast(null), 5000);
            break;
          }
          case 'auth:banned':
            setBannedNotice(msg.payload?.reason || 'Account suspended by administrator.');
            break;
          case 'error:notice':
            setWsToast(msg.payload?.message || 'Action could not be completed.');
            setTimeout(() => setWsToast(null), 4000);
            break;
        }
      };

      ws.onclose = () => {
        setWsConnected(false);
        if (!closedByCleanup) {
          reconnectTimer = setTimeout(connect, 2500);
        }
      };
    };

    connect();
    return () => {
      closedByCleanup = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      wsRef.current?.close();
    };
  }, [isOnline, user.uid]);

  const updateLocalAndRemoteUser = useCallback(
    async (updates: Partial<UserProfile>) => {
      const next = { ...userRef.current, ...updates, updatedAt: new Date().toISOString() };
      setUser(next);
      if (next.isGuest) {
        localStorage.setItem('ca_guest_profile', JSON.stringify(next));
      } else if (isOnline) {
        updateUserProfileFields(next.uid, next).catch(() => {});
        fetch('/api/users/sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(next),
        }).catch(() => {});
      }
    },
    [isOnline]
  );

  const handleRecordLocalMatch = async (
    match: MatchRecord,
    playerResult: 'w' | 'b' | 'draw',
    isOfflineMode: boolean
  ) => {
    setMatchesToday((c) => c + 1);
    if (isOfflineMode) {
      saveOfflineMatch(match);
    }
    setRecentMatches((prev) => [match, ...prev]);

    const current = userRef.current;
    const isWin = playerResult === 'w';
    const isLoss = playerResult === 'b';
    const nextWins = current.wins + (isWin ? 1 : 0);
    const nextLosses = current.losses + (isLoss ? 1 : 0);
    const nextDraws = current.draws + (playerResult === 'draw' ? 1 : 0);
    const nextStreak = isWin ? current.winStreak + 1 : isLoss ? 0 : current.winStreak;
    const nextXp = current.xp + (isWin ? 45 : 20);
    const nextPoints = current.points + (isWin ? 30 : 10);
    const achievements = new Set(current.achievements);
    if (isWin) achievements.add('first_victory');
    if (nextStreak >= 3) achievements.add('streak_3');
    if (isWin && match.durationSeconds <= 90) achievements.add('speed_demon');

    await updateLocalAndRemoteUser({
      wins: nextWins,
      losses: nextLosses,
      draws: nextDraws,
      winStreak: nextStreak,
      bestWinStreak: Math.max(current.bestWinStreak, nextStreak),
      xp: nextXp,
      level: Math.max(1, Math.floor(nextXp / 250) + 1),
      points: nextPoints,
      totalMoves: current.totalMoves + Math.ceil(match.moveCount / 2),
      totalMatchDurationSeconds: current.totalMatchDurationSeconds + match.durationSeconds,
      longestMatchSeconds: Math.max(current.longestMatchSeconds, match.durationSeconds),
      fastestWinSeconds:
        isWin && (current.fastestWinSeconds === 0 || match.durationSeconds < current.fastestWinSeconds)
          ? match.durationSeconds
          : current.fastestWinSeconds,
      achievements: Array.from(achievements),
    });

    if (!isOfflineMode && !current.isGuest) {
      saveMatchRecordToFirestore(match).catch(() => {});
    }
  };

  const handleClaimDailyReward = () => {
    const today = new Date().toISOString().slice(0, 10);
    if (user.lastDailyClaim === today) return;
    const nextXp = user.xp + 60;
    updateLocalAndRemoteUser({
      dailyLoginStreak: user.dailyLoginStreak + 1,
      lastDailyClaim: today,
      points: user.points + 50,
      xp: nextXp,
      level: Math.max(1, Math.floor(nextXp / 250) + 1),
    });
    setNotifications((prev) => [
      {
        id: `rew_${Date.now()}`,
        title: 'Daily Login Reward Claimed',
        body: '+50 Points and +60 XP added to your account.',
        type: 'reward',
        timestamp: new Date().toISOString(),
        read: false,
      },
      ...prev,
    ]);
  };

  const handleFollowPlayer = (targetUid: string, follow: boolean) => {
    const set = new Set(user.following || []);
    if (follow) set.add(targetUid);
    else set.delete(targetUid);
    const nextFollowing = Array.from(set);
    updateLocalAndRemoteUser({ following: nextFollowing });
    if (isOnline) {
      fetch('/api/users/follow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid: user.uid, targetUid, follow }),
      }).catch(() => {});
    }
  };

  const handleBlockPlayer = (targetUid: string, block = true) => {
    const set = new Set(user.blockedUids || []);
    if (block) set.add(targetUid);
    else set.delete(targetUid);
    const nextBlocked = Array.from(set);
    updateLocalAndRemoteUser({ blockedUids: nextBlocked });
    if (isOnline) {
      fetch('/api/users/block', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid: user.uid, targetUid, block }),
      }).catch(() => {});
    }
    setWsToast(block ? 'Player blocked.' : 'Player unblocked.');
    setTimeout(() => setWsToast(null), 2500);
  };

  const handleSubmitReport = (
    targetId: string,
    targetName: string,
    reason: string,
    details: string
  ) => {
    fetch('/api/reports', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        reporterUid: user.uid,
        reportedPlayerId: targetId,
        reportedUsername: targetName,
        reason,
        details,
      }),
    }).catch(() => {});
    if (!user.isGuest) {
      submitPlayerReportDoc(user.uid, targetId, reason, details).catch(() => {});
    }
    setWsToast('Report submitted to moderation team.');
    setTimeout(() => setWsToast(null), 3500);
  };

  const friendsUids = useMemo(
    () =>
      friendRequests
        .filter((r) => r.status === 'accepted')
        .map((r) => (r.fromUid === user.uid ? r.toUid : r.fromUid)),
    [friendRequests, user.uid]
  );

  // Visual Editor handlers
  const handleLaunchVisualEditor = (draft: AppUiConfig, adminToken: string) => {
    setVisualToken(adminToken);
    setVisualHistory([draft]);
    setVisualHistoryIdx(0);
    setVisualEditMode(true);
    setActiveTab('dashboard');
  };

  const handleVisualDraftChange = (next: AppUiConfig) => {
    const sliced = visualHistory.slice(0, visualHistoryIdx + 1);
    sliced.push(next);
    setVisualHistory(sliced);
    setVisualHistoryIdx(sliced.length - 1);
  };

  const handleSaveVisualDraft = async () => {
    const res = await fetch('/api/admin/ui-draft', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${visualToken}` },
      body: JSON.stringify(activeVisualConfig),
    });
    if (res.ok) {
      setVisualSaveStatus('Draft saved!');
      setTimeout(() => setVisualSaveStatus(''), 2000);
    }
  };

  const handlePublishVisualLive = async () => {
    const res = await fetch('/api/admin/ui-config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${visualToken}` },
      body: JSON.stringify(activeVisualConfig),
    });
    if (res.ok) {
      const data = await res.json();
      setUiConfig(data.uiConfig);
      setVisualEditMode(false);
      setActiveTab('admin');
    }
  };

  // Banned Screen
  if (bannedNotice || user.isBanned) {
    return (
      <div className="min-h-screen bg-[#0A0A0C] text-[#F5F5F0] flex items-center justify-center p-6">
        <div className="max-w-md w-full rounded-xl bg-[#141418] border border-red-500/40 p-8 text-center space-y-4">
          <Ban className="w-12 h-12 text-red-500 mx-auto" />
          <h1 className="font-display text-3xl font-bold text-[#F5F5F0]">Account Suspended</h1>
          <p className="text-sm text-[#9898A3]">
            {bannedNotice || user.banReason || 'Access to Chess Arena has been restricted by an administrator.'}
          </p>
          {!user.isGuest && (
            <button
              onClick={() => signOut(auth)}
              className="px-4 py-2 rounded-lg bg-white/10 text-xs text-[#F5F5F0]"
            >
              Sign Out
            </button>
          )}
        </div>
      </div>
    );
  }

  // DEDICATED DISTRACTION-FREE CHESS GAMEPLAY PAGE (Completely separate from dashboard/nav/footer!)
  if (activeRoom || localMatchSetup) {
    return (
      <GameMatchPage
        user={user}
        boardTheme={boardTheme}
        pieceStyle={pieceStyle}
        isOnline={isOnline}
        activeRoom={activeRoom}
        localMatchSetup={localMatchSetup}
        onExitMatch={() => {
          if (activeRoom) {
            sendWs('room:leave', {});
            setActiveRoom(null);
          }
          setLocalMatchSetup(null);
        }}
        onStartRoom={() => sendWs('room:start', {})}
        onCloseRoom={() => sendWs('room:close', {})}
        onKickParticipant={(targetUid) => sendWs('room:kick', { targetUid })}
        onSwitchRole={(role) => sendWs('room:switch_role', { role })}
        onToggleSpectatorChat={() => sendWs('room:toggle_spectator_chat', {})}
        onSendRoomMove={(roomId, from, to, promotion) =>
          sendWs('game:move', { roomId, from, to, promotion })
        }
        onResignRoom={(roomId) => sendWs('game:resign', { roomId })}
        onOfferDrawRoom={(roomId) => sendWs('game:draw_offer', { roomId })}
        onRespondDrawRoom={(roomId, accept) => sendWs('game:draw_response', { roomId, accept })}
        onSendRoomChat={(roomId, text, emoji, channel) =>
          sendWs('room:chat', { roomId, text, emoji, channel })
        }
        onBlockPlayer={(targetUid) => handleBlockPlayer(targetUid, true)}
        onSubmitReport={handleSubmitReport}
        onRecordLocalMatch={handleRecordLocalMatch}
      />
    );
  }

  const unreadNotificationsCount = notifications.filter((n) => !n.read).length;

  return (
    <div
      className="min-h-dvh md:min-h-screen flex flex-col"
      style={{
        backgroundColor: activeVisualConfig.canvasColor,
        color: '#F5F5F0',
      }}
    >
      {/* Top Navigation Bar */}
      <header className="relative md:sticky md:top-0 z-40 border-b border-white/10 bg-[#0A0A0C]/90 backdrop-blur-md pt-safe">
        <div className="max-w-[1440px] mx-auto px-3 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-2 sm:gap-8">
          <button
            onClick={() => {
              if (visualEditMode) {
                setSelectedVisualTarget('siteTitle');
              } else {
                setActiveTab('dashboard');
              }
            }}
            className="font-display text-xl sm:text-2xl font-bold tracking-tight whitespace-nowrap truncate min-w-0"
            style={{ color: activeVisualConfig.accentColor }}
          >
            {activeVisualConfig.siteTitle}
          </button>

          <nav
            onClick={() => {
              if (visualEditMode) setSelectedVisualTarget('navigation');
            }}
            className="hidden md:flex items-center gap-6 text-sm font-medium text-[#9898A3]"
          >
            <button
              onClick={() => !visualEditMode && setActiveTab('dashboard')}
              className={`hover:text-[#F5F5F0] transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'dashboard' ? 'text-[#F5F5F0] underline underline-offset-8 decoration-[#D4AF37]' : ''
              }`}
            >
              {activeVisualConfig.navLabels?.dashboard || 'Dashboard'}
            </button>
            <button
              onClick={() => !visualEditMode && setActiveTab('play')}
              className={`hover:text-[#F5F5F0] transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'play' ? 'text-[#F5F5F0] underline underline-offset-8 decoration-[#D4AF37]' : ''
              }`}
            >
              {activeVisualConfig.navLabels?.play || 'Play Arena'}
            </button>
            {activeVisualConfig.showPlayersDirectory !== false && (
              <button
                onClick={() => !visualEditMode && setActiveTab('players')}
                className={`hover:text-[#F5F5F0] transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === 'players' ? 'text-[#F5F5F0] underline underline-offset-8 decoration-[#D4AF37]' : ''
                }`}
              >
                {activeVisualConfig.navLabels?.players || 'Players'}
              </button>
            )}
            {activeVisualConfig.showTraining && (
              <button
                onClick={() => !visualEditMode && setActiveTab('training')}
                className={`hover:text-[#F5F5F0] transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === 'training' ? 'text-[#F5F5F0] underline underline-offset-8 decoration-[#D4AF37]' : ''
                }`}
              >
                {activeVisualConfig.navLabels?.training || 'Learning'}
              </button>
            )}
            {activeVisualConfig.showTournaments && (
              <button
                onClick={() => !visualEditMode && setActiveTab('tournaments')}
                className={`hover:text-[#F5F5F0] transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === 'tournaments' ? 'text-[#F5F5F0] underline underline-offset-8 decoration-[#D4AF37]' : ''
                }`}
              >
                {activeVisualConfig.navLabels?.tournaments || 'Tournaments'}
              </button>
            )}
            {activeVisualConfig.showLeaderboards && (
              <button
                onClick={() => !visualEditMode && setActiveTab('leaderboards')}
                className={`hover:text-[#F5F5F0] transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === 'leaderboards' ? 'text-[#F5F5F0] underline underline-offset-8 decoration-[#D4AF37]' : ''
                }`}
              >
                {activeVisualConfig.navLabels?.leaderboards || 'Rankings'}
              </button>
            )}
          </nav>

          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <PWAInstallButton />
            <button
              onClick={() => setActiveTab('dashboard')}
              className="md:hidden relative p-2 rounded-lg bg-white/5 border border-white/10 text-[#9898A3] hover:text-[#F5F5F0] min-w-[40px] min-h-[40px] flex items-center justify-center"
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute -top-1 -right-1 px-1.5 min-w-[16px] h-4 rounded-full bg-[#D4AF37] text-[#0A0A0C] text-[10px] font-bold flex items-center justify-center">
                  {unreadNotificationsCount}
                </span>
              )}
            </button>
            {user.isGuest ? (
              <button
                onClick={() => setAuthModalOpen(true)}
                className="px-3 sm:px-4 py-2 rounded-lg text-xs font-semibold text-[#0A0A0C] transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
                style={{ backgroundColor: activeVisualConfig.accentColor }}
              >
                Sign In
              </button>
            ) : (
              <button
                onClick={() => setActiveTab('profile')}
                className="flex items-center gap-2 px-2.5 sm:px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:border-[#D4AF37] text-xs font-medium text-[#F5F5F0] whitespace-nowrap shrink-0 min-h-[40px]"
              >
                <UserIcon className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span className="max-w-[90px] sm:max-w-none truncate">{user.username}</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Live Toast Notice */}
      {wsToast && (
        <div className="fixed top-16 sm:top-20 right-3 sm:right-4 left-3 sm:left-auto z-50 sm:max-w-sm rounded-xl bg-[#1C1C24] border border-[#D4AF37]/50 px-4 py-3 text-xs text-[#F5F5F0] shadow-2xl flex items-center justify-between gap-3">
          <span className="min-w-0 break-words">{wsToast}</span>
          {notifications[0]?.roomId && (
            <button
              onClick={() => {
                sendWs('room:join', {
                  roomId: notifications[0].roomId,
                  password: '',
                  role: 'player',
                });
                setWsToast(null);
              }}
              className="px-3 py-1.5 rounded bg-[#D4AF37] text-[#0A0A0C] font-semibold shrink-0 min-h-[36px]"
            >
              Join
            </button>
          )}
        </div>
      )}

      {/* Main Content Container */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-3 sm:px-6 py-4 sm:py-8 pb-24 md:pb-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            user={user}
            uiConfig={activeVisualConfig}
            visualEditMode={visualEditMode}
            onSelectVisualTarget={setSelectedVisualTarget}
            onlinePlayers={onlinePlayers}
            friendsUids={friendsUids}
            recentMatches={recentMatches}
            leaderboardPreview={leaderboard}
            announcements={announcements}
            notifications={notifications}
            puzzlesSolvedToday={puzzlesToday}
            matchesToday={matchesToday}
            onClaimDailyReward={handleClaimDailyReward}
            onNavigate={(tab, sub) => {
              if (sub) setPlaySubMode(sub);
              setActiveTab(tab);
            }}
            onChallengeFriend={(targetUid) => {
              sendWs('friend:invite', {
                targetUid,
                timeControl: {
                  id: '5+0',
                  label: '5+0',
                  category: 'blitz',
                  initialSeconds: 300,
                  incrementSeconds: 0,
                },
              });
            }}
            onReplayMatch={(m) => {
              setReplayMatch(m);
              setActiveTab('training');
            }}
            onMarkNotificationsRead={() =>
              setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
            }
          />
        )}

        {activeTab === 'play' && (
          <PlayArenaView
            initialSubMode={playSubMode}
            user={user}
            boardTheme={boardTheme}
            pieceStyle={pieceStyle}
            onChangeBoardTheme={setBoardTheme}
            onChangePieceStyle={setPieceStyle}
            isOnline={isOnline}
            wsConnected={wsConnected}
            roomClosedMessage={roomClosedMsg}
            matchmakingQueued={matchmakingQueued}
            publicRooms={publicRooms}
            onlinePlayers={onlinePlayers}
            friendRequests={friendRequests}
            onStartLocalAiMatch={(setup) => setLocalMatchSetup(setup)}
            onJoinMatchmaking={(tc) => sendWs('matchmaking:join', { timeControl: tc })}
            onCancelMatchmaking={() => sendWs('matchmaking:leave', {})}
            onCreateRoom={(payload) => sendWs('room:create', payload)}
            onJoinRoom={(roomId, password, role) =>
              sendWs('room:join', { roomId, password, role })
            }
            onClearClosedRoom={() => setRoomClosedMsg(null)}
            onSendFriendRequest={(toUid, toUsername) => {
              if (user.isGuest) {
                setAuthModalOpen(true);
                return;
              }
              sendFriendRequestDoc(user.uid, user.username, toUid, toUsername).catch(() => {});
            }}
            onRespondFriendRequest={(requestId, status) => {
              respondFriendRequestDoc(requestId, status).catch(() => {});
            }}
            onInviteFriend={(targetUid, tc) =>
              sendWs('friend:invite', { targetUid, timeControl: tc })
            }
            onSubmitReport={handleSubmitReport}
            onReturnDashboard={() => setActiveTab('dashboard')}
          />
        )}

        {activeTab === 'players' && (
          <PlayersDirectoryView
            currentUser={user}
            onlinePlayers={onlinePlayers}
            leaderboardPlayers={leaderboard}
            recentMatches={recentMatches}
            friendRequests={friendRequests}
            onSendFriendRequest={(toUid, toUsername) => {
              if (user.isGuest) {
                setAuthModalOpen(true);
                return;
              }
              sendFriendRequestDoc(user.uid, user.username, toUid, toUsername).catch(() => {});
            }}
            onFollowPlayer={handleFollowPlayer}
            onChallengePlayer={(targetUid, tc) =>
              sendWs('friend:invite', { targetUid, timeControl: tc })
            }
            onBlockPlayer={handleBlockPlayer}
            onSubmitReport={handleSubmitReport}
            onReplayMatch={(m) => {
              setReplayMatch(m);
              setActiveTab('training');
            }}
          />
        )}

        {activeTab === 'training' && (
          <TrainingCenterView
            user={user}
            boardTheme={boardTheme}
            pieceStyle={pieceStyle}
            isOnline={isOnline}
            dailyTip={activeVisualConfig.dailyTip}
            learningVideos={learningVideos}
            replayMatch={replayMatch}
            onPuzzleSolved={(_pz: PuzzleItem) => {
              setPuzzlesToday((c) => c + 1);
              const nextSolved = user.puzzlesSolved + 1;
              const nextXp = user.xp + 30;
              const ach = new Set(user.achievements);
              if (nextSolved >= 10) ach.add('tactician_10');
              updateLocalAndRemoteUser({
                puzzlesSolved: nextSolved,
                puzzleRating: Math.min(3500, (user.puzzleRating || 1200) + 12),
                xp: nextXp,
                level: Math.max(1, Math.floor(nextXp / 250) + 1),
                points: user.points + 20,
                achievements: Array.from(ach),
              });
            }}
            onOpeningCompleted={() => {
              const ach = new Set(user.achievements);
              ach.add('grand_scholar');
              updateLocalAndRemoteUser({
                xp: user.xp + 40,
                points: user.points + 25,
                achievements: Array.from(ach),
              });
            }}
            onToggleVideoComplete={(videoId) => {
              const set = new Set(user.completedVideos || []);
              if (set.has(videoId)) set.delete(videoId);
              else set.add(videoId);
              updateLocalAndRemoteUser({ completedVideos: Array.from(set) });
            }}
            onToggleVideoFavorite={(videoId) => {
              const set = new Set(user.favoriteVideos || []);
              if (set.has(videoId)) set.delete(videoId);
              else set.add(videoId);
              updateLocalAndRemoteUser({ favoriteVideos: Array.from(set) });
            }}
          />
        )}

        {activeTab === 'tournaments' && (
          <TournamentsView
            user={user}
            tournaments={tournaments}
            onCreateTournament={(payload) => {
              sendWs('tournament:create', payload);
              const ach = new Set(user.achievements);
              ach.add('arena_competitor');
              updateLocalAndRemoteUser({ achievements: Array.from(ach) });
            }}
            onJoinTournament={(tournamentId) => sendWs('tournament:join', { tournamentId })}
            onStartTournament={(tournamentId) => sendWs('tournament:start', { tournamentId })}
            onLaunchTournamentMatch={(tournamentId, matchId) =>
              sendWs('tournament:launch_match', { tournamentId, matchId })
            }
          />
        )}

        {activeTab === 'leaderboards' && (
          <LeaderboardView user={user} players={leaderboard} friendsUids={friendsUids} />
        )}

        {activeTab === 'profile' && (
          <ProfileSettingsView
            user={user}
            matches={recentMatches}
            friendRequests={friendRequests}
            onlinePlayers={onlinePlayers}
            learningVideos={learningVideos}
            preferences={preferences}
            onUpdatePreferences={setPreferences}
            onUpdateProfile={updateLocalAndRemoteUser}
            onReplayMatch={(m) => {
              setReplayMatch(m);
              setActiveTab('training');
            }}
            onOpenLearning={() => setActiveTab('training')}
            onOpenAdminPortal={() => setActiveTab('admin')}
            onLogout={() => {
              signOut(auth);
              setActiveTab('dashboard');
            }}
          />
        )}

        {activeTab === 'admin' && (
          <AdminPanelView
            onUiConfigApplied={(cfg) => setUiConfig(cfg)}
            onLaunchVisualEditor={handleLaunchVisualEditor}
            onLearningVideosUpdated={(vids) => setLearningVideos(vids)}
          />
        )}
      </main>

      {/* Clean Footer — hidden extra bottom space accounted for on mobile */}
      <footer className="border-t border-white/10 py-5 px-4 sm:px-6 mt-4 md:mt-8 pb-24 md:pb-5">
        <div className="max-w-[1440px] mx-auto flex flex-wrap items-center justify-between gap-4 text-xs text-[#9898A3]">
          <p>{activeVisualConfig.siteTitle} · Worldwide Competitive Chess Platform</p>
          <div className="flex flex-wrap items-center gap-4 sm:gap-5">
            <button onClick={() => setActiveTab('players')} className="hover:text-[#F5F5F0] py-1">
              Players Directory
            </button>
            <button onClick={() => setActiveTab('training')} className="hover:text-[#F5F5F0] py-1">
              Learning Center
            </button>
            <button onClick={() => setActiveTab('profile')} className="hover:text-[#F5F5F0] py-1">
              Profile & Match Archive
            </button>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Navigation Bar (md:hidden) */}
      <nav
        aria-label="Mobile navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0A0A0C]/95 backdrop-blur-md border-t border-white/10 pb-safe"
      >
        <div className="grid grid-cols-5 h-[56px] [@media(max-height:480px)]:h-12 items-center">
          <button
            onClick={() => {
              setMobileMoreOpen(false);
              setActiveTab('dashboard');
            }}
            className={`flex flex-col items-center justify-center h-full gap-0.5 ${
              activeTab === 'dashboard' && !mobileMoreOpen ? 'text-[#D4AF37]' : 'text-[#9898A3]'
            }`}
          >
            <LayoutDashboard className="w-5 h-5" />
            <span className="text-[10px] font-medium tracking-tight">Home</span>
          </button>

          <button
            onClick={() => {
              setMobileMoreOpen(false);
              setActiveTab('play');
            }}
            className={`flex flex-col items-center justify-center h-full gap-0.5 ${
              activeTab === 'play' && !mobileMoreOpen ? 'text-[#D4AF37]' : 'text-[#9898A3]'
            }`}
          >
            <Swords className="w-5 h-5" />
            <span className="text-[10px] font-medium tracking-tight">Play</span>
          </button>

          <button
            onClick={() => {
              setMobileMoreOpen(false);
              setActiveTab('players');
            }}
            className={`flex flex-col items-center justify-center h-full gap-0.5 ${
              activeTab === 'players' && !mobileMoreOpen ? 'text-[#D4AF37]' : 'text-[#9898A3]'
            }`}
          >
            <Users className="w-5 h-5" />
            <span className="text-[10px] font-medium tracking-tight">Players</span>
          </button>

          <button
            onClick={() => {
              setMobileMoreOpen(false);
              setActiveTab('training');
            }}
            className={`flex flex-col items-center justify-center h-full gap-0.5 ${
              activeTab === 'training' && !mobileMoreOpen ? 'text-[#D4AF37]' : 'text-[#9898A3]'
            }`}
          >
            <BookOpen className="w-5 h-5" />
            <span className="text-[10px] font-medium tracking-tight">Learn</span>
          </button>

          <button
            onClick={() => setMobileMoreOpen((o) => !o)}
            className={`flex flex-col items-center justify-center h-full gap-0.5 relative ${
              mobileMoreOpen ||
              activeTab === 'tournaments' ||
              activeTab === 'leaderboards' ||
              activeTab === 'profile' ||
              activeTab === 'admin'
                ? 'text-[#D4AF37]'
                : 'text-[#9898A3]'
            }`}
          >
            <Menu className="w-5 h-5" />
            <span className="text-[10px] font-medium tracking-tight">More</span>
          </button>
        </div>
      </nav>

      {/* Mobile More Navigation Sheet */}
      {mobileMoreOpen && (
        <div
          className="md:hidden fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-end"
          onClick={() => setMobileMoreOpen(false)}
        >
          <div
            className="w-full rounded-t-2xl bg-[#141418] border-t border-white/15 p-4 pb-safe space-y-3 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1 rounded-full bg-white/20 mx-auto" />
            <div className="flex items-center justify-between px-1">
              <p className="font-display text-lg font-bold text-[#F5F5F0]">
                Arena Menu
              </p>
              <button
                onClick={() => setMobileMoreOpen(false)}
                className="p-2 rounded-lg bg-white/5 text-[#9898A3] min-w-[40px] min-h-[40px] flex items-center justify-center"
                aria-label="Close menu"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {activeVisualConfig.showTournaments && (
                <button
                  onClick={() => {
                    setActiveTab('tournaments');
                    setMobileMoreOpen(false);
                  }}
                  className="flex items-center gap-2.5 p-3.5 rounded-xl bg-[#0A0A0C] border border-white/10 text-left text-xs font-semibold text-[#F5F5F0] min-h-[48px]"
                >
                  <Trophy className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>{activeVisualConfig.navLabels?.tournaments || 'Tournaments'}</span>
                </button>
              )}
              {activeVisualConfig.showLeaderboards && (
                <button
                  onClick={() => {
                    setActiveTab('leaderboards');
                    setMobileMoreOpen(false);
                  }}
                  className="flex items-center gap-2.5 p-3.5 rounded-xl bg-[#0A0A0C] border border-white/10 text-left text-xs font-semibold text-[#F5F5F0] min-h-[48px]"
                >
                  <Award className="w-4 h-4 text-[#D4AF37] shrink-0" />
                  <span>{activeVisualConfig.navLabels?.leaderboards || 'Rankings'}</span>
                </button>
              )}
              <button
                onClick={() => {
                  setActiveTab('profile');
                  setMobileMoreOpen(false);
                }}
                className="flex items-center gap-2.5 p-3.5 rounded-xl bg-[#0A0A0C] border border-white/10 text-left text-xs font-semibold text-[#F5F5F0] min-h-[48px] col-span-2"
              >
                <UserIcon className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>Profile, Friends Messages & Settings</span>
              </button>
              {user.isGuest && (
                <button
                  onClick={() => {
                    setMobileMoreOpen(false);
                    setAuthModalOpen(true);
                  }}
                  className="flex items-center justify-center gap-2 p-3.5 rounded-xl bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold min-h-[48px] col-span-2"
                >
                  Sign In / Create Account
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Super Admin Interactive Click-to-Edit Visual Editor Overlay */}
      {visualEditMode && (
        <VisualEditorOverlay
          draftConfig={activeVisualConfig}
          selectedTarget={selectedVisualTarget}
          onSelectTarget={setSelectedVisualTarget}
          canUndo={visualHistoryIdx > 0}
          canRedo={visualHistoryIdx < visualHistory.length - 1}
          onUndo={() => setVisualHistoryIdx((i) => Math.max(0, i - 1))}
          onRedo={() => setVisualHistoryIdx((i) => Math.min(visualHistory.length - 1, i + 1))}
          onChangeDraft={handleVisualDraftChange}
          onSaveDraft={handleSaveVisualDraft}
          onPublishLive={handlePublishVisualLive}
          onCancel={() => {
            setVisualEditMode(false);
            setActiveTab('admin');
          }}
          savingStatus={visualSaveStatus}
        />
      )}

      <AuthModal
        isOpen={authModalOpen}
        allowGuest={activeVisualConfig.allowGuestPlay}
        onClose={() => setAuthModalOpen(false)}
        onContinueGuest={() => setAuthModalOpen(false)}
      />

      <OfflineIndicator />
    </div>
  );
}
