import React, { useEffect, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Ban,
  BookOpen,
  CheckCircle2,
  Database,
  History,
  LayoutDashboard,
  Lock,
  Megaphone,
  MousePointerClick,
  Palette,
  RefreshCw,
  Settings,
  Shield,
  ShieldCheck,
  Trash2,
  Trophy,
  Users,
} from 'lucide-react';
import { auth } from '../firebase';
import { BOARD_THEMES, PIECE_STYLES } from '../data/themes';
import { VIDEO_CATEGORIES } from '../data/trainingData';
import {
  AdminAuditLog,
  AdminRole,
  Announcement,
  AppUiConfig,
  BoardThemeId,
  LearningVideo,
  ModeratorAccount,
  PieceStyleId,
  PlayerReport,
  PrivateRoomState,
  Tournament,
  UiVersionSnapshot,
  UserProfile,
  VideoCategory,
} from '../types/chess';

interface AdminPanelViewProps {
  currentUserEmail?: string;
  onUiConfigApplied: (cfg: AppUiConfig) => void;
  onLaunchVisualEditor: (draft: AppUiConfig, adminToken: string) => void;
  onLearningVideosUpdated: (videos: LearningVideo[]) => void;
}

interface OverviewPayload {
  role: AdminRole;
  username: string;
  permissions: string[];
  users: UserProfile[];
  activeRooms: PrivateRoomState[];
  tournaments: Tournament[];
  reports: PlayerReport[];
  announcements: Announcement[];
  learningVideos: LearningVideo[];
  suspiciousAlerts: { id: string; uid: string; username: string; reason: string; timestamp: string }[];
  uiConfig: AppUiConfig;
  uiDraftConfig: AppUiConfig | null;
  uiVersions: UiVersionSnapshot[];
  moderators: ModeratorAccount[];
  auditLogs: AdminAuditLog[];
  onlineCount: number;
  totalMatches: number;
}

export const AdminPanelView: React.FC<AdminPanelViewProps> = ({
  onUiConfigApplied,
  onLaunchVisualEditor,
  onLearningVideosUpdated,
}) => {
  const [token, setToken] = useState<string>(() => sessionStorage.getItem('ca_admin_token') || '');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [loading, setLoading] = useState(false);

  const [overview, setOverview] = useState<OverviewPayload | null>(null);
  const [section, setSection] = useState<
    | 'dashboard'
    | 'users'
    | 'visual_editor'
    | 'database'
    | 'game_settings'
    | 'chat'
    | 'learning'
    | 'tournaments'
    | 'rankings'
    | 'security'
    | 'logs'
  >('dashboard');

  const [uiDraft, setUiDraft] = useState<AppUiConfig | null>(null);
  const [uiSavedMsg, setUiSavedMsg] = useState('');

  // User Edit state
  const [editingUid, setEditingUid] = useState<string | null>(null);
  const [editUserForm, setEditUserForm] = useState<{
    username: string;
    rating: number;
    xp: number;
    points: number;
    country: string;
  }>({ username: '', rating: 1200, xp: 0, points: 0, country: 'Global' });

  // Ban / Announcement / Video / Moderator forms
  const [banUidInput, setBanUidInput] = useState('');
  const [banReasonInput, setBanReasonInput] = useState('Violation of fair-play rules');
  const [annTitle, setAnnTitle] = useState('');
  const [annBody, setAnnBody] = useState('');

  const [vidTitle, setVidTitle] = useState('');
  const [vidYoutubeId, setVidYoutubeId] = useState('');
  const [vidPlaylistId, setVidPlaylistId] = useState('');
  const [vidAuthor, setVidAuthor] = useState('');
  const [vidCategory, setVidCategory] = useState<VideoCategory>('Beginner Chess Lessons');
  const [vidDesc, setVidDesc] = useState('');
  const [vidIsPlaylist, setVidIsPlaylist] = useState(false);

  const [modUser, setModUser] = useState('');
  const [modPass, setModPass] = useState('');
  const [modPerms, setModPerms] = useState<string[]>(['users', 'chat', 'learning', 'tournaments']);
  const [modError, setModError] = useState('');

  const [dbActionMsg, setDbActionMsg] = useState('');
  const [logFilter, setLogFilter] = useState('');

  const fetchOverview = async (adminToken: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/overview', {
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      if (res.status === 401) {
        sessionStorage.removeItem('ca_admin_token');
        setToken('');
        setOverview(null);
        return;
      }
      const data = (await res.json()) as OverviewPayload;
      setOverview(data);
      setUiDraft(data.uiDraftConfig || data.uiConfig);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (token) {
      fetchOverview(token);
    }
  }, [token]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setLoading(true);
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim(), password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'Authentication rejected.');
        return;
      }
      sessionStorage.setItem('ca_admin_token', data.token);
      setToken(data.token);
      setPassword('');
    } catch {
      setAuthError('Unable to reach authentication server.');
    } finally {
      setLoading(false);
    }
  };

  const handleFirebaseOwnerSso = async () => {
    setAuthError('');
    if (!auth.currentUser) {
      setAuthError('Sign in to your owner Firebase account first to verify identity.');
      return;
    }
    setLoading(true);
    try {
      const idToken = await auth.currentUser.getIdToken();
      const res = await fetch('/api/admin/firebase-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || 'Account is not authorized for Owner Admin access.');
        return;
      }
      sessionStorage.setItem('ca_admin_token', data.token);
      setToken(data.token);
    } catch {
      setAuthError('Owner verification failed.');
    } finally {
      setLoading(false);
    }
  };

  const isSuperAdmin = overview?.role === 'super_admin';

  const handleSaveUiLive = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uiDraft) return;
    const res = await fetch('/api/admin/ui-config', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(uiDraft),
    });
    if (res.ok) {
      const data = await res.json();
      onUiConfigApplied(data.uiConfig);
      setUiSavedMsg('Published live to all connected players!');
      setTimeout(() => setUiSavedMsg(''), 2500);
      fetchOverview(token);
    }
  };

  const handleSaveUiDraft = async () => {
    if (!uiDraft) return;
    const res = await fetch('/api/admin/ui-draft', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(uiDraft),
    });
    if (res.ok) {
      setUiSavedMsg('Draft saved without affecting live players.');
      setTimeout(() => setUiSavedMsg(''), 2500);
      fetchOverview(token);
    }
  };

  const handleRestoreVersion = async (versionId: string) => {
    const res = await fetch('/api/admin/ui-restore', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ versionId }),
    });
    if (res.ok) {
      const data = await res.json();
      onUiConfigApplied(data.uiConfig);
      setUiDraft(data.uiConfig);
      setUiSavedMsg('Previous UI version restored live!');
      fetchOverview(token);
    }
  };

  const handleBanPlayer = async (uid: string, reason: string) => {
    await fetch('/api/admin/ban', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ uid, reason }),
    });
    fetchOverview(token);
  };

  const handleUnbanPlayer = async (uid: string) => {
    await fetch('/api/admin/unban', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ uid }),
    });
    fetchOverview(token);
  };

  const handleUpdateUser = async (uid: string) => {
    await fetch('/api/admin/user-update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ uid, ...editUserForm }),
    });
    setEditingUid(null);
    fetchOverview(token);
  };

  const handleDeleteUser = async (uid: string) => {
    await fetch(`/api/admin/users/${uid}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    fetchOverview(token);
  };

  const handleAdjustRating = async (uid: string, rating: number) => {
    await fetch('/api/admin/adjust-rating', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ uid, rating }),
    });
    fetchOverview(token);
  };

  const handleResetSeasonRankings = async () => {
    await fetch('/api/admin/rankings/reset', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    fetchOverview(token);
  };

  const handleCloseRoom = async (roomId: string) => {
    await fetch('/api/admin/room-close', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ roomId }),
    });
    fetchOverview(token);
  };

  const handleDeleteChat = async (roomId: string, messageId: string) => {
    await fetch('/api/admin/chat-delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ roomId, messageId }),
    });
    fetchOverview(token);
  };

  const handleReportStatus = async (reportId: string, status: PlayerReport['status']) => {
    await fetch('/api/admin/reports/status', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ reportId, status }),
    });
    fetchOverview(token);
  };

  const handleCreateAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!annTitle.trim() || !annBody.trim()) return;
    await fetch('/api/admin/announcements', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ title: annTitle, body: annBody, active: true }),
    });
    setAnnTitle('');
    setAnnBody('');
    fetchOverview(token);
  };

  const handleDeleteAnnouncement = async (id: string) => {
    await fetch(`/api/admin/announcements/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    fetchOverview(token);
  };

  const handleAddLearningVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/admin/learning-videos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({
        title: vidTitle,
        youtubeId: vidIsPlaylist ? undefined : vidYoutubeId,
        playlistId: vidIsPlaylist ? vidPlaylistId : undefined,
        author: vidAuthor || 'Chess Arena Academy',
        category: vidCategory,
        description: vidDesc,
        isPlaylist: vidIsPlaylist,
      }),
    });
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.learningVideos)) {
        onLearningVideosUpdated(data.learningVideos);
      }
      setVidTitle('');
      setVidYoutubeId('');
      setVidPlaylistId('');
      setVidDesc('');
      fetchOverview(token);
    }
  };

  const handleDeleteLearningVideo = async (videoId: string) => {
    const res = await fetch(`/api/admin/learning-videos/${videoId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.learningVideos)) {
        onLearningVideosUpdated(data.learningVideos);
      }
      fetchOverview(token);
    }
  };

  const handleDeleteTournament = async (id: string) => {
    await fetch(`/api/admin/tournaments/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    fetchOverview(token);
  };

  const handleCreateModerator = async (e: React.FormEvent) => {
    e.preventDefault();
    setModError('');
    const res = await fetch('/api/admin/moderators', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ username: modUser, password: modPass, permissions: modPerms }),
    });
    const data = await res.json();
    if (!res.ok) {
      setModError(data.error || 'Could not create moderator.');
      return;
    }
    setModUser('');
    setModPass('');
    fetchOverview(token);
  };

  const handleDeleteModerator = async (id: string) => {
    await fetch(`/api/admin/moderators/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    fetchOverview(token);
  };

  const handleExportDatabase = async () => {
    const res = await fetch('/api/admin/db-export', {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.ok) {
      const data = await res.json();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `chess-arena-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setDbActionMsg('Full database JSON backup exported.');
    }
  };

  const handleCleanupReports = async () => {
    const res = await fetch('/api/admin/db-cleanup', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.ok) {
      const data = await res.json();
      setDbActionMsg(`Database cleanup completed: removed ${data.removedReports} resolved reports.`);
      fetchOverview(token);
    }
  };

  // LOGIN GATE
  if (!token) {
    return (
      <div className="max-w-md mx-auto my-6 sm:my-10 rounded-2xl bg-[#141418] border border-white/10 p-5 sm:p-7 space-y-5 shadow-2xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-[#D4AF37]/15 border border-[#D4AF37]/30 shrink-0">
            <Lock className="w-5 h-5 text-[#D4AF37]" />
          </div>
          <div className="min-w-0">
            <h2 className="font-display text-xl sm:text-2xl font-bold text-[#F5F5F0]">
              Protected Staff & Admin Portal
            </h2>
            <p className="text-xs text-[#9898A3]">
              Server-enforced RBAC authentication required.
            </p>
          </div>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs text-[#9898A3] mb-1">Staff / Admin Username</label>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-sm text-[#F5F5F0]"
            />
          </div>
          <div>
            <label className="block text-xs text-[#9898A3] mb-1">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-sm text-[#F5F5F0]"
            />
          </div>
          {authError && (
            <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg p-2.5">
              {authError}
            </p>
          )}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-sm font-semibold hover:bg-[#E5C158] min-h-[44px]"
          >
            {loading ? 'Verifying...' : 'Sign In to Admin Console'}
          </button>
        </form>

        <div className="pt-3 border-t border-white/10 space-y-2">
          <button
            type="button"
            disabled={loading}
            onClick={handleFirebaseOwnerSso}
            className="w-full py-2.5 rounded-lg bg-white/5 border border-white/15 text-xs text-[#F5F5F0] hover:border-[#D4AF37] min-h-[44px]"
          >
            Verify with Signed-In Owner Google Account
          </button>
        </div>
      </div>
    );
  }

  const navItems: { id: typeof section; label: string; icon: React.ElementType; superOnly?: boolean }[] = [
    { id: 'dashboard', label: '1. Dashboard', icon: LayoutDashboard },
    { id: 'users', label: '2. Users', icon: Users },
    { id: 'visual_editor', label: '3. Visual Editor', icon: Palette, superOnly: true },
    { id: 'database', label: '4. Database', icon: Database, superOnly: true },
    { id: 'game_settings', label: '5. Game Settings', icon: Settings, superOnly: true },
    { id: 'chat', label: '6. Chat & Rooms', icon: Megaphone },
    { id: 'learning', label: '7. Learning Content', icon: BookOpen },
    { id: 'tournaments', label: '8. Tournaments', icon: Trophy },
    { id: 'rankings', label: '9. Rankings', icon: AlertTriangle },
    { id: 'security', label: '10. Security & Roles', icon: Shield, superOnly: true },
    { id: 'logs', label: '11. Activity Logs', icon: Activity },
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-5">
        <div className="flex items-center gap-3 min-w-0">
          <ShieldCheck className="w-6 h-6 text-[#D4AF37] shrink-0" />
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display text-xl sm:text-2xl font-bold text-[#F5F5F0]">
                Chess Arena Admin Console
              </h2>
              <span className="px-2 py-0.5 rounded bg-[#D4AF37]/20 text-[#D4AF37] font-mono text-[10px] font-semibold uppercase">
                {overview?.role === 'super_admin' ? 'Super Admin' : 'Moderator'}
              </span>
            </div>
            <p className="text-xs text-[#9898A3] font-mono tabular-nums truncate">
              Staff: {overview?.username || '—'} · {overview?.onlineCount ?? 0} Online ·{' '}
              {overview?.users.length ?? 0} Accounts · {overview?.activeRooms.length ?? 0} Rooms
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {isSuperAdmin && uiDraft && (
            <button
              onClick={() => onLaunchVisualEditor(uiDraft, token)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold hover:bg-[#E5C158] min-h-[40px]"
            >
              <MousePointerClick className="w-3.5 h-3.5" />
              Live Click-to-Edit Mode
            </button>
          )}
          <button
            onClick={() => fetchOverview(token)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] min-h-[40px]"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh
          </button>
          <button
            onClick={() => {
              sessionStorage.removeItem('ca_admin_token');
              setToken('');
              setOverview(null);
            }}
            className="px-3 py-2 rounded-lg bg-red-500/15 border border-red-500/30 text-xs text-red-300 min-h-[40px]"
          >
            Lock Console
          </button>
        </div>
      </div>

      {/* 11-Section Sidebar/Tabs */}
      <div className="flex overflow-x-auto sm:flex-wrap gap-1.5 p-1.5 rounded-xl bg-[#141418] border border-white/10 no-scrollbar">
        {navItems
          .filter((item) => !item.superOnly || isSuperAdmin)
          .map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setSection(item.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 min-h-[40px] ${
                  section === item.id
                    ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                    : 'text-[#9898A3] hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {item.label}
              </button>
            );
          })}
      </div>

      {/* 1. ADMIN DASHBOARD */}
      {section === 'dashboard' && overview && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
            <div className="p-4 rounded-xl bg-[#141418] border border-white/10">
              <p className="text-[#9898A3]">Connected Sockets</p>
              <p className="font-mono text-2xl font-bold text-[#D4AF37] mt-1">{overview.onlineCount}</p>
            </div>
            <div className="p-4 rounded-xl bg-[#141418] border border-white/10">
              <p className="text-[#9898A3]">Registered Players</p>
              <p className="font-mono text-2xl font-bold text-[#F5F5F0] mt-1">{overview.users.length}</p>
            </div>
            <div className="p-4 rounded-xl bg-[#141418] border border-white/10">
              <p className="text-[#9898A3]">Archived Matches</p>
              <p className="font-mono text-2xl font-bold text-[#F5F5F0] mt-1">{overview.totalMatches}</p>
            </div>
            <div className="p-4 rounded-xl bg-[#141418] border border-white/10">
              <p className="text-[#9898A3]">Open Reports</p>
              <p className="font-mono text-2xl font-bold text-red-400 mt-1">
                {overview.reports.filter((r) => r.status === 'open').length}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-xl bg-[#141418] border border-white/10 p-5 space-y-3">
              <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
                Open Player Reports ({overview.reports.length})
              </h3>
              {overview.reports.length === 0 ? (
                <p className="text-xs text-[#9898A3]">No open player reports.</p>
              ) : (
                <div className="space-y-2.5 max-h-80 overflow-y-auto">
                  {overview.reports.map((r) => (
                    <div key={r.reportId} className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-[#F5F5F0]">
                          {r.reportedUsername || r.reportedPlayerId}
                        </span>
                        <span className="text-[#D4AF37] uppercase">{r.status}</span>
                      </div>
                      <p className="text-[#9898A3]">
                        {r.reason} — {r.details}
                      </p>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleBanPlayer(r.reportedPlayerId, r.reason)}
                          className="px-2.5 py-1 rounded bg-red-600 text-white font-semibold"
                        >
                          Ban
                        </button>
                        <button
                          onClick={() => handleReportStatus(r.reportId, 'resolved')}
                          className="px-2.5 py-1 rounded bg-emerald-600 text-white"
                        >
                          Resolve
                        </button>
                        <button
                          onClick={() => handleReportStatus(r.reportId, 'dismissed')}
                          className="px-2.5 py-1 rounded bg-white/10 text-[#9898A3]"
                        >
                          Dismiss
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="rounded-xl bg-[#141418] border border-white/10 p-5 space-y-3">
              <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
                Anti-Cheat & Fair Play Alerts
              </h3>
              {overview.suspiciousAlerts.length === 0 ? (
                <p className="text-xs text-[#9898A3]">No anomalous activity detected.</p>
              ) : (
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {overview.suspiciousAlerts.map((al) => (
                    <div
                      key={al.id}
                      className="p-3 rounded-lg bg-[#0A0A0C] border border-amber-500/20 text-xs flex items-center justify-between"
                    >
                      <div>
                        <p className="font-semibold text-amber-300">{al.username}</p>
                        <p className="text-[#9898A3]">{al.reason}</p>
                      </div>
                      <button
                        onClick={() => handleBanPlayer(al.uid, al.reason)}
                        className="px-2.5 py-1 rounded bg-red-600 text-white font-semibold"
                      >
                        Ban
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 2. USER MANAGEMENT */}
      {section === 'users' && overview && (
        <div className="space-y-6">
          <div className="rounded-xl bg-[#141418] border border-white/10 p-5 flex flex-wrap items-end gap-3">
            <div className="flex-1 min-w-[180px]">
              <label className="block text-xs text-[#9898A3] mb-1">Ban Player by UID</label>
              <input
                type="text"
                value={banUidInput}
                onChange={(e) => setBanUidInput(e.target.value)}
                placeholder="Enter player UID..."
                className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              />
            </div>
            <div className="flex-1 min-w-[200px]">
              <label className="block text-xs text-[#9898A3] mb-1">Ban Reason</label>
              <input
                type="text"
                value={banReasonInput}
                onChange={(e) => setBanReasonInput(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              />
            </div>
            <button
              onClick={() => {
                if (banUidInput.trim()) {
                  handleBanPlayer(banUidInput.trim(), banReasonInput);
                  setBanUidInput('');
                }
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-red-600 text-white text-xs font-semibold"
            >
              <Ban className="w-3.5 h-3.5" />
              Ban Player
            </button>
          </div>

          <div className="rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-5">
            {/* Mobile Card List */}
            <div className="md:hidden space-y-2.5 text-xs">
              {overview.users.map((u) => (
                <div key={u.uid} className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10 space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-semibold text-[#F5F5F0] truncate">
                        {u.username} <span className="text-[#9898A3]">({u.country})</span>
                      </p>
                      <p className="font-mono text-[11px] text-[#9898A3] tabular-nums">
                        {u.playerId} · <span className="text-[#D4AF37]">{u.rating} Elo</span> · {u.xp} XP
                      </p>
                    </div>
                    {u.isBanned ? (
                      <span className="text-red-400 font-semibold shrink-0">Banned</span>
                    ) : (
                      <span className="text-emerald-400 shrink-0">Active</span>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => {
                        setEditingUid(editingUid === u.uid ? null : u.uid);
                        setEditUserForm({
                          username: u.username,
                          rating: u.rating,
                          xp: u.xp,
                          points: u.points,
                          country: u.country,
                        });
                      }}
                      className="px-3 py-1.5 rounded bg-white/5 text-[#F5F5F0] min-h-[38px]"
                    >
                      Edit
                    </button>
                    {u.isBanned ? (
                      <button
                        onClick={() => handleUnbanPlayer(u.uid)}
                        className="px-3 py-1.5 rounded bg-emerald-600 text-white font-semibold min-h-[38px]"
                      >
                        Unban
                      </button>
                    ) : (
                      <button
                        onClick={() => handleBanPlayer(u.uid, 'Banned by staff')}
                        className="px-3 py-1.5 rounded bg-red-600 text-white font-semibold min-h-[38px]"
                      >
                        Ban
                      </button>
                    )}
                    {isSuperAdmin && (
                      <button
                        onClick={() => handleDeleteUser(u.uid)}
                        className="px-3 py-1.5 rounded bg-red-900/50 text-red-200 min-h-[38px]"
                      >
                        Delete
                      </button>
                    )}
                  </div>
                  {editingUid === u.uid && (
                    <div className="pt-2 border-t border-white/10 grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={editUserForm.username}
                        onChange={(e) => setEditUserForm({ ...editUserForm, username: e.target.value })}
                        className="col-span-2 px-2.5 py-2 rounded bg-[#141418] border border-white/10 text-xs"
                        placeholder="Username"
                      />
                      <input
                        type="number"
                        value={editUserForm.rating}
                        onChange={(e) => setEditUserForm({ ...editUserForm, rating: Number(e.target.value) })}
                        className="px-2.5 py-2 rounded bg-[#141418] border border-white/10 text-xs"
                        placeholder="Elo"
                      />
                      <input
                        type="number"
                        value={editUserForm.xp}
                        onChange={(e) => setEditUserForm({ ...editUserForm, xp: Number(e.target.value) })}
                        className="px-2.5 py-2 rounded bg-[#141418] border border-white/10 text-xs"
                        placeholder="XP"
                      />
                      <input
                        type="number"
                        value={editUserForm.points}
                        onChange={(e) => setEditUserForm({ ...editUserForm, points: Number(e.target.value) })}
                        className="px-2.5 py-2 rounded bg-[#141418] border border-white/10 text-xs"
                        placeholder="Points"
                      />
                      <button
                        onClick={() => handleUpdateUser(u.uid)}
                        className="px-3 py-2 rounded bg-[#D4AF37] text-[#0A0A0C] font-semibold min-h-[38px]"
                      >
                        Save
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-white/10 text-[#9898A3]">
                    <th className="py-2.5 px-2">Player</th>
                    <th className="py-2.5 px-2">ID</th>
                    <th className="py-2.5 px-2">Elo</th>
                    <th className="py-2.5 px-2">XP / Pts</th>
                    <th className="py-2.5 px-2">Status</th>
                    <th className="py-2.5 px-2 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {overview.users.map((u) => (
                    <React.Fragment key={u.uid}>
                      <tr>
                        <td className="py-3 px-2 font-medium text-[#F5F5F0]">
                          {u.username} <span className="text-[#9898A3]">({u.country})</span>
                        </td>
                        <td className="py-3 px-2 font-mono text-[#9898A3]">{u.playerId}</td>
                        <td className="py-3 px-2 font-mono text-[#D4AF37] tabular-nums">{u.rating}</td>
                        <td className="py-3 px-2 font-mono text-[#9898A3] tabular-nums">
                          {u.xp} XP · {u.points} pts
                        </td>
                        <td className="py-3 px-2">
                          {u.isBanned ? (
                            <span className="text-red-400 font-semibold">Banned</span>
                          ) : (
                            <span className="text-emerald-400">Active</span>
                          )}
                        </td>
                        <td className="py-3 px-2 text-right space-x-2">
                          <button
                            onClick={() => {
                              setEditingUid(editingUid === u.uid ? null : u.uid);
                              setEditUserForm({
                                username: u.username,
                                rating: u.rating,
                                xp: u.xp,
                                points: u.points,
                                country: u.country,
                              });
                            }}
                            className="px-2 py-1 rounded bg-white/5 text-[#F5F5F0]"
                          >
                            Edit
                          </button>
                          {u.isBanned ? (
                            <button
                              onClick={() => handleUnbanPlayer(u.uid)}
                              className="px-2.5 py-1 rounded bg-emerald-600 text-white font-semibold"
                            >
                              Unban
                            </button>
                          ) : (
                            <button
                              onClick={() => handleBanPlayer(u.uid, 'Banned by staff')}
                              className="px-2.5 py-1 rounded bg-red-600 text-white font-semibold"
                            >
                              Ban
                            </button>
                          )}
                          {isSuperAdmin && (
                            <button
                              onClick={() => handleDeleteUser(u.uid)}
                              className="px-2 py-1 rounded bg-red-900/50 text-red-200"
                            >
                              Delete
                            </button>
                          )}
                        </td>
                      </tr>
                      {editingUid === u.uid && (
                        <tr>
                          <td colSpan={6} className="p-3 bg-[#0A0A0C]">
                            <div className="flex flex-wrap items-end gap-2">
                              <input
                                type="text"
                                value={editUserForm.username}
                                onChange={(e) =>
                                  setEditUserForm({ ...editUserForm, username: e.target.value })
                                }
                                className="px-2.5 py-1.5 rounded bg-[#141418] border border-white/10 text-xs"
                                placeholder="Username"
                              />
                              <input
                                type="number"
                                value={editUserForm.rating}
                                onChange={(e) =>
                                  setEditUserForm({ ...editUserForm, rating: Number(e.target.value) })
                                }
                                className="w-24 px-2.5 py-1.5 rounded bg-[#141418] border border-white/10 text-xs"
                                placeholder="Elo"
                              />
                              <input
                                type="number"
                                value={editUserForm.xp}
                                onChange={(e) =>
                                  setEditUserForm({ ...editUserForm, xp: Number(e.target.value) })
                                }
                                className="w-24 px-2.5 py-1.5 rounded bg-[#141418] border border-white/10 text-xs"
                                placeholder="XP"
                              />
                              <input
                                type="number"
                                value={editUserForm.points}
                                onChange={(e) =>
                                  setEditUserForm({ ...editUserForm, points: Number(e.target.value) })
                                }
                                className="w-24 px-2.5 py-1.5 rounded bg-[#141418] border border-white/10 text-xs"
                                placeholder="Points"
                              />
                              <button
                                onClick={() => handleUpdateUser(u.uid)}
                                className="px-3 py-1.5 rounded bg-[#D4AF37] text-[#0A0A0C] font-semibold"
                              >
                                Save Changes
                              </button>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 3. VISUAL EDITOR & VERSION HISTORY (SUPER ADMIN) */}
      {section === 'visual_editor' && isSuperAdmin && uiDraft && overview && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleSaveUiLive}
            className="lg:col-span-7 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4"
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
                Visual Editor & Live Branding
              </h3>
              <button
                type="button"
                onClick={() => onLaunchVisualEditor(uiDraft, token)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
              >
                <MousePointerClick className="w-3.5 h-3.5" />
                Click-to-Edit on Live Dashboard
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-[#9898A3] mb-1">Platform Title</label>
                <input
                  type="text"
                  value={uiDraft.siteTitle}
                  onChange={(e) => setUiDraft({ ...uiDraft, siteTitle: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                />
              </div>
              <div>
                <label className="block text-[#9898A3] mb-1">Banner Announcement</label>
                <input
                  type="text"
                  value={uiDraft.bannerText}
                  onChange={(e) => setUiDraft({ ...uiDraft, bannerText: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                />
              </div>
              <div>
                <label className="block text-[#9898A3] mb-1">Hero Headline</label>
                <input
                  type="text"
                  value={uiDraft.heroHeadline}
                  onChange={(e) => setUiDraft({ ...uiDraft, heroHeadline: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                />
              </div>
              <div>
                <label className="block text-[#9898A3] mb-1">Hero Subtitle</label>
                <input
                  type="text"
                  value={uiDraft.heroSubtitle}
                  onChange={(e) => setUiDraft({ ...uiDraft, heroSubtitle: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block text-[#9898A3] mb-1">Accent</label>
                <input
                  type="color"
                  value={uiDraft.accentColor}
                  onChange={(e) => setUiDraft({ ...uiDraft, accentColor: e.target.value })}
                  className="w-full h-9 rounded bg-transparent cursor-pointer"
                />
              </div>
              <div>
                <label className="block text-[#9898A3] mb-1">Canvas</label>
                <input
                  type="color"
                  value={uiDraft.canvasColor}
                  onChange={(e) => setUiDraft({ ...uiDraft, canvasColor: e.target.value })}
                  className="w-full h-9 rounded bg-transparent cursor-pointer"
                />
              </div>
              <div>
                <label className="block text-[#9898A3] mb-1">Surface</label>
                <input
                  type="color"
                  value={uiDraft.surfaceColor}
                  onChange={(e) => setUiDraft({ ...uiDraft, surfaceColor: e.target.value })}
                  className="w-full h-9 rounded bg-transparent cursor-pointer"
                />
              </div>
            </div>

            {uiSavedMsg && (
              <p className="text-xs text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" /> {uiSavedMsg}
              </p>
            )}

            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={handleSaveUiDraft}
                className="px-4 py-2 rounded-lg bg-white/10 text-xs text-[#F5F5F0]"
              >
                Save Draft
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
              >
                Publish Live
              </button>
            </div>
          </form>

          {/* Version History & Rollback */}
          <div className="lg:col-span-5 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
            <h3 className="font-display text-xl font-bold text-[#F5F5F0] flex items-center gap-2">
              <History className="w-4 h-4 text-[#D4AF37]" /> Version History & Rollback
            </h3>
            {overview.uiVersions.length === 0 ? (
              <p className="text-xs text-[#9898A3]">
                Snapshots are saved automatically every time you publish live UI updates.
              </p>
            ) : (
              <div className="space-y-2.5 max-h-80 overflow-y-auto">
                {overview.uiVersions.map((ver) => (
                  <div
                    key={ver.versionId}
                    className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs flex items-center justify-between gap-2"
                  >
                    <div>
                      <p className="font-semibold text-[#F5F5F0]">{ver.label}</p>
                      <p className="text-[11px] text-[#9898A3]">
                        Saved by {ver.savedBy} · {new Date(ver.createdAt).toLocaleString()}
                      </p>
                    </div>
                    <button
                      onClick={() => handleRestoreVersion(ver.versionId)}
                      className="px-2.5 py-1 rounded bg-[#D4AF37]/20 text-[#D4AF37] font-semibold"
                    >
                      Restore
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 4. DATABASE MANAGEMENT (SUPER ADMIN) */}
      {section === 'database' && isSuperAdmin && overview && (
        <div className="rounded-xl bg-[#141418] border border-white/10 p-6 space-y-5">
          <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">
            Database Inspection, Backup & Cleanup
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
            <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
              <p className="text-[#9898A3]">Users</p>
              <p className="font-mono text-xl font-bold text-[#F5F5F0]">{overview.users.length}</p>
            </div>
            <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
              <p className="text-[#9898A3]">Matches</p>
              <p className="font-mono text-xl font-bold text-[#F5F5F0]">{overview.totalMatches}</p>
            </div>
            <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
              <p className="text-[#9898A3]">Tournaments</p>
              <p className="font-mono text-xl font-bold text-[#F5F5F0]">{overview.tournaments.length}</p>
            </div>
            <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
              <p className="text-[#9898A3]">Learning Videos</p>
              <p className="font-mono text-xl font-bold text-[#F5F5F0]">{overview.learningVideos.length}</p>
            </div>
            <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
              <p className="text-[#9898A3]">Audit Entries</p>
              <p className="font-mono text-xl font-bold text-[#F5F5F0]">{overview.auditLogs.length}</p>
            </div>
          </div>

          {dbActionMsg && <p className="text-xs text-emerald-400">{dbActionMsg}</p>}

          <div className="flex flex-wrap gap-3">
            <button
              onClick={handleExportDatabase}
              className="px-4 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
            >
              Export Full JSON Backup
            </button>
            <button
              onClick={handleCleanupReports}
              className="px-4 py-2 rounded-lg bg-white/5 border border-white/15 text-xs text-[#F5F5F0]"
            >
              Purge Resolved Reports
            </button>
          </div>
        </div>
      )}

      {/* 5. GAME SETTINGS */}
      {section === 'game_settings' && isSuperAdmin && uiDraft && (
        <form
          onSubmit={handleSaveUiLive}
          className="rounded-xl bg-[#141418] border border-white/10 p-6 space-y-5"
        >
          <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">
            Global Matchmaking, Board & Feature Toggles
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-[#9898A3] mb-1">Default Board Theme</label>
              <select
                value={uiDraft.defaultBoardTheme}
                onChange={(e) =>
                  setUiDraft({ ...uiDraft, defaultBoardTheme: e.target.value as BoardThemeId })
                }
                className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
              >
                {Object.values(BOARD_THEMES).map((bt) => (
                  <option key={bt.id} value={bt.id}>
                    {bt.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[#9898A3] mb-1">Default Piece Style</label>
              <select
                value={uiDraft.defaultPieceStyle}
                onChange={(e) =>
                  setUiDraft({ ...uiDraft, defaultPieceStyle: e.target.value as PieceStyleId })
                }
                className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
              >
                {PIECE_STYLES.map((ps) => (
                  <option key={ps.id} value={ps.id}>
                    {ps.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex flex-wrap gap-6 text-xs text-[#F5F5F0]">
            {[
              { key: 'allowGuestPlay', label: 'Allow Guest Practice Mode' },
              { key: 'showPlayersDirectory', label: 'Show Global Players Directory Tab' },
              { key: 'showTraining', label: 'Show Learning Center Tab' },
              { key: 'showTournaments', label: 'Show Tournaments Tab' },
              { key: 'showLeaderboards', label: 'Show Rankings Tab' },
              { key: 'maintenanceMode', label: 'Maintenance Mode' },
            ].map((tg) => (
              <label key={tg.key} className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={uiDraft[tg.key as keyof AppUiConfig] !== false && Boolean(uiDraft[tg.key as keyof AppUiConfig])}
                  onChange={(e) => setUiDraft({ ...uiDraft, [tg.key]: e.target.checked })}
                  className="accent-[#D4AF37]"
                />
                {tg.label}
              </label>
            ))}
          </div>

          <button
            type="submit"
            className="px-5 py-2.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
          >
            Save Global Settings
          </button>
        </form>
      )}

      {/* 6. CHAT MODERATION & ANNOUNCEMENTS */}
      {section === 'chat' && overview && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-xl bg-[#141418] border border-white/10 p-5 space-y-4">
            <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
              Live Room Chats & Moderation
            </h3>
            {overview.activeRooms.length === 0 ? (
              <p className="text-xs text-[#9898A3]">No active rooms right now.</p>
            ) : (
              <div className="space-y-3">
                {overview.activeRooms.map((rm) => (
                  <div key={rm.roomId} className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-[#F5F5F0]">
                        {rm.roomName} ({rm.roomId})
                      </span>
                      <button
                        onClick={() => handleCloseRoom(rm.roomId)}
                        className="px-2.5 py-1 rounded bg-red-600 text-white font-semibold"
                      >
                        Force Close
                      </button>
                    </div>
                    <div className="space-y-1 max-h-36 overflow-y-auto">
                      {rm.chat.map((c) => (
                        <div key={c.id} className="flex items-center justify-between text-[11px] text-[#9898A3]">
                          <span>
                            <strong className="text-[#F5F5F0]">[{c.channel || 'room'}] {c.senderName}:</strong>{' '}
                            {c.text}
                          </span>
                          <button
                            onClick={() => handleDeleteChat(rm.roomId, c.id)}
                            className="text-red-400 hover:text-red-300"
                          >
                            Delete
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="rounded-xl bg-[#141418] border border-white/10 p-5 space-y-4">
            <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
              Platform Announcements
            </h3>
            <form onSubmit={handleCreateAnnouncement} className="space-y-2">
              <input
                type="text"
                required
                value={annTitle}
                onChange={(e) => setAnnTitle(e.target.value)}
                placeholder="Announcement title"
                className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              />
              <textarea
                rows={2}
                required
                value={annBody}
                onChange={(e) => setAnnBody(e.target.value)}
                placeholder="Announcement message..."
                className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
              >
                Publish Announcement
              </button>
            </form>
            <div className="divide-y divide-white/5">
              {overview.announcements.map((a) => (
                <div key={a.announcementId} className="py-2.5 flex items-start justify-between gap-3 text-xs">
                  <div>
                    <p className="font-semibold text-[#F5F5F0]">{a.title}</p>
                    <p className="text-[#9898A3] mt-0.5">{a.body}</p>
                  </div>
                  <button
                    onClick={() => handleDeleteAnnouncement(a.announcementId)}
                    className="p-1.5 text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 7. LEARNING CONTENT MANAGEMENT */}
      {section === 'learning' && overview && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleAddLearningVideo}
            className="lg:col-span-5 rounded-xl bg-[#141418] border border-white/10 p-5 space-y-3 text-xs"
          >
            <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
              Add Learning Video or Playlist
            </h3>
            <label className="flex items-center gap-2 cursor-pointer text-[#F5F5F0]">
              <input
                type="checkbox"
                checked={vidIsPlaylist}
                onChange={(e) => setVidIsPlaylist(e.target.checked)}
                className="accent-[#D4AF37]"
              />
              Add YouTube Playlist (otherwise single Video)
            </label>
            <input
              type="text"
              required
              value={vidTitle}
              onChange={(e) => setVidTitle(e.target.value)}
              placeholder="Lesson Title"
              className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
            />
            {vidIsPlaylist ? (
              <input
                type="text"
                required
                value={vidPlaylistId}
                onChange={(e) => setVidPlaylistId(e.target.value)}
                placeholder="YouTube Playlist ID (PL...)"
                className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
              />
            ) : (
              <input
                type="text"
                required
                value={vidYoutubeId}
                onChange={(e) => setVidYoutubeId(e.target.value)}
                placeholder="YouTube Video ID (e.g. OCSbzArwB10)"
                className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
              />
            )}
            <input
              type="text"
              value={vidAuthor}
              onChange={(e) => setVidAuthor(e.target.value)}
              placeholder="Channel / Instructor Name"
              className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
            />
            <select
              value={vidCategory}
              onChange={(e) => setVidCategory(e.target.value as VideoCategory)}
              className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
            >
              {VIDEO_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
            <textarea
              rows={2}
              value={vidDesc}
              onChange={(e) => setVidDesc(e.target.value)}
              placeholder="Short lesson description..."
              className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
            />
            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] font-semibold"
            >
              Publish to Learning Center
            </button>
          </form>

          <div className="lg:col-span-7 rounded-xl bg-[#141418] border border-white/10 p-5 space-y-3">
            <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
              Active Video Library ({overview.learningVideos.length})
            </h3>
            <div className="divide-y divide-white/5 max-h-[460px] overflow-y-auto">
              {overview.learningVideos.map((v) => (
                <div key={v.videoId} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                  <div className="min-w-0">
                    <p className="font-semibold text-[#F5F5F0] truncate">{v.title}</p>
                    <p className="text-[#9898A3]">
                      {v.category} · {v.author} · {v.isPlaylist ? `List: ${v.playlistId}` : `ID: ${v.youtubeId}`}
                    </p>
                  </div>
                  <button
                    onClick={() => handleDeleteLearningVideo(v.videoId)}
                    className="px-2.5 py-1 rounded bg-red-500/15 text-red-300 shrink-0"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 8. TOURNAMENT MANAGEMENT */}
      {section === 'tournaments' && overview && (
        <div className="rounded-xl bg-[#141418] border border-white/10 p-5 space-y-4">
          <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
            Active & Archived Tournaments ({overview.tournaments.length})
          </h3>
          {overview.tournaments.length === 0 ? (
            <p className="text-xs text-[#9898A3]">No tournaments currently created.</p>
          ) : (
            <div className="divide-y divide-white/5 text-xs">
              {overview.tournaments.map((t) => (
                <div key={t.tournamentId} className="py-3 flex items-center justify-between gap-3">
                  <div>
                    <p className="font-semibold text-[#F5F5F0]">{t.title}</p>
                    <p className="text-[#9898A3]">
                      {t.format} · {t.status} · {t.participants.length}/{t.maxPlayers} players · Created by {t.creatorName}
                    </p>
                  </div>
                  <button
                    onClick={() => handleDeleteTournament(t.tournamentId)}
                    className="px-3 py-1.5 rounded bg-red-600 text-white font-semibold"
                  >
                    Cancel / Delete
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 9. RANKING MANAGEMENT */}
      {section === 'rankings' && overview && (
        <div className="rounded-xl bg-[#141418] border border-white/10 p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
              Elo Ranking Adjustments & Season Controls
            </h3>
            {isSuperAdmin && (
              <button
                onClick={handleResetSeasonRankings}
                className="px-3.5 py-2 rounded-lg bg-red-600 text-white text-xs font-semibold"
              >
                Reset All Player Ratings to 1200 (New Season)
              </button>
            )}
          </div>

          <div className="divide-y divide-white/5 text-xs">
            {[...overview.users]
              .sort((a, b) => b.rating - a.rating)
              .slice(0, 30)
              .map((u, idx) => (
                <div key={u.uid} className="py-2.5 flex items-center justify-between gap-3">
                  <div>
                    <span className="font-mono text-[#D4AF37] mr-2">#{idx + 1}</span>
                    <span className="font-semibold text-[#F5F5F0]">{u.username}</span>
                    <span className="text-[#9898A3] ml-2">({u.rating} Elo)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleAdjustRating(u.uid, u.rating + 25)}
                      className="px-2.5 py-1 rounded bg-white/5 text-[#F5F5F0]"
                    >
                      +25 Elo
                    </button>
                    <button
                      onClick={() => handleAdjustRating(u.uid, Math.max(400, u.rating - 25))}
                      className="px-2.5 py-1 rounded bg-white/5 text-[#F5F5F0]"
                    >
                      -25 Elo
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* 10. SECURITY SETTINGS & MODERATORS (SUPER ADMIN) */}
      {section === 'security' && isSuperAdmin && overview && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleCreateModerator}
            className="lg:col-span-5 rounded-xl bg-[#141418] border border-white/10 p-5 space-y-3 text-xs"
          >
            <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
              Create Moderator Role Account
            </h3>
            <p className="text-[#9898A3]">
              Moderators can review reports, manage users/chat/learning/tournaments, but cannot access Super Admin Visual Editor, Database, or Security controls.
            </p>
            <input
              type="text"
              required
              minLength={3}
              value={modUser}
              onChange={(e) => setModUser(e.target.value)}
              placeholder="Moderator Username"
              className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
            />
            <input
              type="password"
              required
              minLength={6}
              value={modPass}
              onChange={(e) => setModPass(e.target.value)}
              placeholder="Password (min 6 chars)"
              className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
            />
            <div className="flex flex-wrap gap-3 py-1">
              {['users', 'chat', 'learning', 'tournaments', 'rankings'].map((perm) => (
                <label key={perm} className="flex items-center gap-1.5 text-[#D4D4CE]">
                  <input
                    type="checkbox"
                    checked={modPerms.includes(perm)}
                    onChange={(e) => {
                      if (e.target.checked) setModPerms([...modPerms, perm]);
                      else setModPerms(modPerms.filter((p) => p !== perm));
                    }}
                    className="accent-[#D4AF37]"
                  />
                  {perm}
                </label>
              ))}
            </div>
            {modError && <p className="text-red-400">{modError}</p>}
            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] font-semibold"
            >
              Add Moderator Account
            </button>
          </form>

          <div className="lg:col-span-7 rounded-xl bg-[#141418] border border-white/10 p-5 space-y-3">
            <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
              Active Moderator Accounts ({overview.moderators.length})
            </h3>
            {overview.moderators.length === 0 ? (
              <p className="text-xs text-[#9898A3]">No delegated moderators added yet.</p>
            ) : (
              <div className="divide-y divide-white/5 text-xs">
                {overview.moderators.map((m) => (
                  <div key={m.id} className="py-2.5 flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-[#F5F5F0]">{m.username}</p>
                      <p className="text-[#9898A3]">
                        Permissions: {m.permissions.join(', ')} · Added by {m.createdBy}
                      </p>
                    </div>
                    <button
                      onClick={() => handleDeleteModerator(m.id)}
                      className="px-2.5 py-1 rounded bg-red-600 text-white font-semibold"
                    >
                      Revoke
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 11. ACTIVITY LOGS */}
      {section === 'logs' && overview && (
        <div className="rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
              Immutable Staff Audit Trail ({overview.auditLogs.length})
            </h3>
            <input
              type="text"
              value={logFilter}
              onChange={(e) => setLogFilter(e.target.value)}
              placeholder="Filter logs by actor or action..."
              className="w-full sm:w-auto px-3 py-2 sm:py-1.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
            />
          </div>

          {/* Mobile Card List */}
          <div className="md:hidden space-y-2 max-h-[420px] overflow-y-auto text-xs">
            {overview.auditLogs
              .filter(
                (l) =>
                  !logFilter.trim() ||
                  l.actor.toLowerCase().includes(logFilter.toLowerCase()) ||
                  l.action.toLowerCase().includes(logFilter.toLowerCase())
              )
              .map((l) => (
                <div key={l.logId} className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-[#F5F5F0] truncate">
                      {l.actor} <span className="font-mono text-[#D4AF37]">({l.actorRole})</span>
                    </span>
                    <span className="font-mono text-[10px] text-[#9898A3] shrink-0">
                      {new Date(l.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-[#F5F5F0]">{l.action}</p>
                  <p className="text-[#9898A3] break-words">
                    {l.target} {l.details ? `· ${l.details}` : ''}
                  </p>
                </div>
              ))}
          </div>

          {/* Desktop Table */}
          <div className="hidden md:block overflow-x-auto max-h-[420px]">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-white/10 text-[#9898A3]">
                  <th className="py-2 px-2">Time</th>
                  <th className="py-2 px-2">Actor</th>
                  <th className="py-2 px-2">Role</th>
                  <th className="py-2 px-2">Action</th>
                  <th className="py-2 px-2">Target / Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {overview.auditLogs
                  .filter(
                    (l) =>
                      !logFilter.trim() ||
                      l.actor.toLowerCase().includes(logFilter.toLowerCase()) ||
                      l.action.toLowerCase().includes(logFilter.toLowerCase())
                  )
                  .map((l) => (
                    <tr key={l.logId}>
                      <td className="py-2 px-2 font-mono text-[11px] text-[#9898A3]">
                        {new Date(l.createdAt).toLocaleString()}
                      </td>
                      <td className="py-2 px-2 font-semibold text-[#F5F5F0]">{l.actor}</td>
                      <td className="py-2 px-2 font-mono text-[#D4AF37]">{l.actorRole}</td>
                      <td className="py-2 px-2 text-[#F5F5F0]">{l.action}</td>
                      <td className="py-2 px-2 text-[#9898A3]">
                        {l.target} {l.details ? `· ${l.details}` : ''}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
