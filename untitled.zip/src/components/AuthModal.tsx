import React, { useEffect, useState } from 'react';
import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
} from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import { X, Mail, Lock, User as UserIcon, ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  allowGuest: boolean;
  onClose: () => void;
  onContinueGuest: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  allowGuest,
  onClose,
  onContinueGuest,
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'reset'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [usernameStatus, setUsernameStatus] = useState<'idle' | 'checking' | 'available' | 'taken'>('idle');
  const [usernameReason, setUsernameReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  useEffect(() => {
    if (mode !== 'register') {
      setUsernameStatus('idle');
      setUsernameReason('');
      return;
    }
    const clean = username.trim();
    if (clean.length < 2) {
      setUsernameStatus('idle');
      setUsernameReason('');
      return;
    }
    setUsernameStatus('checking');
    const timer = setTimeout(() => {
      fetch(`/api/users/check-username?username=${encodeURIComponent(clean)}`)
        .then((r) => r.json())
        .then((data) => {
          if (data.available) {
            setUsernameStatus('available');
            setUsernameReason('');
          } else {
            setUsernameStatus('taken');
            setUsernameReason(data.reason || 'Username already taken.');
          }
        })
        .catch(() => {
          setUsernameStatus('idle');
        });
    }, 300);
    return () => clearTimeout(timer);
  }, [username, mode]);

  if (!isOpen) return null;

  const handleGoogleSignIn = async () => {
    setError('');
    setNotice('');
    setLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Google Sign-In failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setNotice('');

    if (mode === 'register') {
      const clean = username.trim();
      if (clean.length < 2) {
        setError('Please choose a unique username (minimum 2 characters).');
        return;
      }
      if (usernameStatus === 'taken') {
        setError(usernameReason || 'That username is already taken.');
        return;
      }
    }

    setLoading(true);
    try {
      if (mode === 'login') {
        await signInWithEmailAndPassword(auth, email.trim(), password);
        onClose();
      } else if (mode === 'register') {
        const checkRes = await fetch(
          `/api/users/check-username?username=${encodeURIComponent(username.trim())}`
        );
        const checkData = await checkRes.json();
        if (!checkData.available) {
          setError(checkData.reason || 'Username already taken.');
          setLoading(false);
          return;
        }
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        if (username.trim()) {
          await updateProfile(cred.user, { displayName: username.trim().slice(0, 32) });
        }
        await sendEmailVerification(cred.user).catch(() => {});
        setNotice('Account created. Verification email sent if enabled.');
        onClose();
      } else {
        await sendPasswordResetEmail(auth, email.trim());
        setNotice('Password recovery link sent to your email address.');
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Authentication failed.';
      if (msg.includes('operation-not-allowed')) {
        setError(
          'Email/Password login is not enabled in Firebase Console yet. Please use Google Sign-In or enable Email/Password under Firebase Console > Authentication > Sign-in method.'
        );
      } else {
        setError(msg);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-md max-h-[90dvh] overflow-y-auto rounded-xl bg-[#141418] border border-white/10 p-5 sm:p-6 space-y-5 shadow-2xl">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl font-bold text-[#F5F5F0]">
              {mode === 'login' ? 'Enter Chess Arena' : mode === 'register' ? 'Create Player Account' : 'Recover Password'}
            </h2>
            <p className="text-xs text-[#9898A3] mt-1">
              Sync your unique username, Elo rating, and tournament standings globally.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-[#9898A3] hover:text-white hover:bg-white/5 transition-colors min-w-[40px] min-h-[40px] flex items-center justify-center shrink-0"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Google Sign-In */}
        <button
          onClick={handleGoogleSignIn}
          disabled={loading}
          className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-lg bg-[#F5F5F0] text-[#0A0A0C] font-semibold text-sm hover:bg-white transition-colors disabled:opacity-50 min-h-[44px]"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="currentColor"
              d="M21.35 11.1h-9.17v2.73h6.51c-.33 3.81-3.5 5.44-6.5 5.44C8.36 19.27 5 16.25 5 12c0-4.1 3.2-7.27 7.2-7.27 3.09 0 4.9 1.97 4.9 1.97L19 4.72S16.56 2 12.1 2C6.42 2 2.03 6.8 2.03 12c0 5.05 4.13 10 10.22 10 5.35 0 9.25-3.67 9.25-9.09 0-1.15-.15-1.81-.15-1.81z"
            />
          </svg>
          Continue with Google
        </button>

        <div className="flex items-center gap-3 text-xs text-[#9898A3]">
          <div className="flex-1 h-px bg-white/10" />
          <span>or with email</span>
          <div className="flex-1 h-px bg-white/10" />
        </div>

        <form onSubmit={handleEmailSubmit} className="space-y-3">
          {mode === 'register' && (
            <div className="space-y-1">
              <div className="relative">
                <UserIcon className="w-4 h-4 text-[#9898A3] absolute left-3 top-3" />
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Unique player username"
                  maxLength={32}
                  className="w-full pl-9 pr-9 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-sm text-[#F5F5F0] focus:outline-none focus:border-[#D4AF37]"
                />
                {usernameStatus === 'available' && (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 absolute right-3 top-3" />
                )}
                {usernameStatus === 'taken' && (
                  <AlertCircle className="w-4 h-4 text-red-400 absolute right-3 top-3" />
                )}
              </div>
              {usernameStatus === 'available' && (
                <p className="text-[11px] text-emerald-400">Username is unique and available.</p>
              )}
              {usernameStatus === 'taken' && (
                <p className="text-[11px] text-red-400">{usernameReason}</p>
              )}
            </div>
          )}

          <div className="relative">
            <Mail className="w-4 h-4 text-[#9898A3] absolute left-3 top-3" />
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email address"
              className="w-full pl-9 pr-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-sm text-[#F5F5F0] focus:outline-none focus:border-[#D4AF37]"
            />
          </div>

          {mode !== 'reset' && (
            <div className="relative">
              <Lock className="w-4 h-4 text-[#9898A3] absolute left-3 top-3" />
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password (min 6 characters)"
                className="w-full pl-9 pr-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-sm text-[#F5F5F0] focus:outline-none focus:border-[#D4AF37]"
              />
            </div>
          )}

          {error && <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg p-2.5">{error}</p>}
          {notice && <p className="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-2.5">{notice}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-[#D4AF37] text-[#0A0A0C] font-semibold text-sm hover:bg-[#E5C158] transition-colors disabled:opacity-50 min-h-[44px]"
          >
            <span>{mode === 'login' ? 'Sign In' : mode === 'register' ? 'Create Account' : 'Send Reset Link'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="flex items-center justify-between text-xs text-[#9898A3] pt-1">
          {mode === 'login' ? (
            <>
              <button onClick={() => setMode('register')} className="hover:text-[#D4AF37] transition-colors py-2">
                Create new account
              </button>
              <button onClick={() => setMode('reset')} className="hover:text-[#D4AF37] transition-colors py-2">
                Forgot password?
              </button>
            </>
          ) : (
            <button onClick={() => setMode('login')} className="hover:text-[#D4AF37] transition-colors py-2">
              Back to Sign In
            </button>
          )}
        </div>

        {allowGuest && (
          <div className="pt-2 border-t border-white/10">
            <button
              onClick={() => {
                onContinueGuest();
                onClose();
              }}
              className="w-full py-2.5 text-xs text-[#9898A3] hover:text-[#F5F5F0] transition-colors min-h-[44px]"
            >
              Continue as Guest for Practice vs AI
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
