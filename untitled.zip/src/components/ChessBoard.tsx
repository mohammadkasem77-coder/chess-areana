import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Chess, PieceSymbol, Square } from 'chess.js';
import { BOARD_THEMES } from '../data/themes';
import { BoardThemeId, PieceStyleId } from '../types/chess';
import { PieceSvg } from './PieceSvg';

interface ChessBoardProps {
  fen: string;
  orientation?: 'w' | 'b';
  boardTheme?: BoardThemeId;
  pieceStyle?: PieceStyleId;
  interactive?: boolean;
  allowedColor?: 'w' | 'b' | 'both';
  lastMove?: { from: string; to: string };
  hintMove?: { from: string; to: string } | null;
  maxWidthClass?: string;
  onMove: (from: string, to: string, promotion?: string) => void;
}

const FILES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
const RANKS = ['8', '7', '6', '5', '4', '3', '2', '1'];

interface DragState {
  from: string;
  pieceType: PieceSymbol;
  pieceColor: 'w' | 'b';
  startX: number;
  startY: number;
  x: number;
  y: number;
  active: boolean;
  hoverSq: string | null;
}

const ChessBoardInner: React.FC<ChessBoardProps> = ({
  fen,
  orientation = 'w',
  boardTheme = 'classic_wood',
  pieceStyle = 'staunton',
  interactive = true,
  allowedColor = 'both',
  lastMove,
  hintMove,
  maxWidthClass = 'max-w-[560px]',
  onMove,
}) => {
  const [selectedSquare, setSelectedSquare] = useState<string | null>(null);
  const [dragState, setDragState] = useState<DragState | null>(null);
  const [pendingPromotion, setPendingPromotion] = useState<{
    from: string;
    to: string;
    color: 'w' | 'b';
  } | null>(null);

  const boardGridRef = useRef<HTMLDivElement | null>(null);
  const suppressNextClickRef = useRef(false);
  const newlySelectedSquareRef = useRef<string | null>(null);

  const theme = BOARD_THEMES[boardTheme] || BOARD_THEMES.classic_wood;

  const chess = useMemo(() => {
    try {
      return new Chess(fen);
    } catch {
      return new Chess();
    }
  }, [fen]);

  const legalTargets = useMemo(() => {
    if (!selectedSquare) return new Map<string, boolean>();
    const moves = chess.moves({ square: selectedSquare as Square, verbose: true });
    const map = new Map<string, boolean>();
    for (const m of moves) {
      map.set(m.to, !!m.captured);
    }
    return map;
  }, [chess, selectedSquare]);

  const boardMatrix = useMemo(() => chess.board(), [chess]);
  const inCheck = chess.inCheck();
  const turn = chess.turn();

  const displayRanks = useMemo(
    () => (orientation === 'w' ? RANKS : [...RANKS].reverse()),
    [orientation]
  );
  const displayFiles = useMemo(
    () => (orientation === 'w' ? FILES : [...FILES].reverse()),
    [orientation]
  );

  const canMovePiece = useCallback(
    (pieceColor: 'w' | 'b') => {
      if (!interactive) return false;
      if (chess.isGameOver()) return false;
      if (pieceColor !== turn) return false;
      if (allowedColor !== 'both' && pieceColor !== allowedColor) return false;
      return true;
    },
    [interactive, chess, turn, allowedColor]
  );

  const attemptMove = useCallback(
    (from: string, to: string) => {
      const moves = chess.moves({ square: from as Square, verbose: true });
      const matching = moves.filter((m) => m.to === to);
      if (matching.length === 0) return false;

      const needsPromotion = matching.some((m) => m.promotion);
      if (needsPromotion) {
        setPendingPromotion({ from, to, color: chess.turn() });
        setSelectedSquare(null);
        return true;
      }

      onMove(from, to);
      setSelectedSquare(null);
      return true;
    },
    [chess, onMove]
  );

  const getSquareAtPoint = useCallback(
    (clientX: number, clientY: number): string | null => {
      const el = boardGridRef.current;
      if (!el) return null;
      const rect = el.getBoundingClientRect();
      if (
        clientX < rect.left ||
        clientX > rect.right ||
        clientY < rect.top ||
        clientY > rect.bottom
      ) {
        return null;
      }
      const col = Math.min(7, Math.max(0, Math.floor(((clientX - rect.left) / rect.width) * 8)));
      const row = Math.min(7, Math.max(0, Math.floor(((clientY - rect.top) / rect.height) * 8)));
      const file = displayFiles[col];
      const rank = displayRanks[row];
      return file && rank ? `${file}${rank}` : null;
    },
    [displayFiles, displayRanks]
  );

  const handleSquareTap = useCallback(
    (sq: string) => {
      if (!interactive || chess.isGameOver()) return;

      if (selectedSquare) {
        if (selectedSquare === sq) {
          setSelectedSquare(null);
          return;
        }
        if (attemptMove(selectedSquare, sq)) {
          return;
        }
      }

      const piece = chess.get(sq as Square);
      if (piece && canMovePiece(piece.color)) {
        setSelectedSquare(sq);
      } else {
        setSelectedSquare(null);
      }
    },
    [interactive, chess, selectedSquare, attemptMove, canMovePiece]
  );

  // Unified Pointer Drag-and-Drop (supports both touchscreens & desktop mouse seamlessly)
  const handleSquarePointerDown = (e: React.PointerEvent<HTMLDivElement>, sq: string) => {
    if (!interactive || chess.isGameOver()) return;
    if (e.button !== 0 && e.pointerType === 'mouse') return;

    const piece = chess.get(sq as Square);
    if (!piece || !canMovePiece(piece.color)) {
      newlySelectedSquareRef.current = null;
      return;
    }

    if (selectedSquare !== sq) {
      newlySelectedSquareRef.current = sq;
      setSelectedSquare(sq);
    } else {
      newlySelectedSquareRef.current = null;
    }

    setDragState({
      from: sq,
      pieceType: piece.type,
      pieceColor: piece.color,
      startX: e.clientX,
      startY: e.clientY,
      x: e.clientX,
      y: e.clientY,
      active: false,
      hoverSq: sq,
    });
  };

  useEffect(() => {
    if (!dragState) return;

    const handleMove = (e: PointerEvent) => {
      const dx = e.clientX - dragState.startX;
      const dy = e.clientY - dragState.startY;
      const distSq = dx * dx + dy * dy;
      const isNowActive = dragState.active || distSq > 36;
      const hoverSq = getSquareAtPoint(e.clientX, e.clientY);

      setDragState((prev) =>
        prev
          ? {
              ...prev,
              x: e.clientX,
              y: e.clientY,
              active: isNowActive,
              hoverSq,
            }
          : null
      );
    };

    const handleUp = (e: PointerEvent) => {
      const dropSq = getSquareAtPoint(e.clientX, e.clientY);
      if (dragState.active) {
        suppressNextClickRef.current = true;
        newlySelectedSquareRef.current = null;
        setTimeout(() => {
          suppressNextClickRef.current = false;
        }, 60);

        if (dropSq && dropSq !== dragState.from) {
          attemptMove(dragState.from, dropSq);
        }
      }
      setDragState(null);
    };

    window.addEventListener('pointermove', handleMove, { passive: true });
    window.addEventListener('pointerup', handleUp);
    window.addEventListener('pointercancel', handleUp);
    return () => {
      window.removeEventListener('pointermove', handleMove);
      window.removeEventListener('pointerup', handleUp);
      window.removeEventListener('pointercancel', handleUp);
    };
  }, [dragState, getSquareAtPoint, attemptMove]);

  return (
    <div className={`relative w-full ${maxWidthClass} mx-auto chessboard-surface`}>
      <div
        className="relative aspect-square w-full rounded-lg overflow-hidden shadow-2xl border-[4px] sm:border-[6px]"
        style={{
          borderColor: theme.frameBorder,
        }}
      >
        <div
          ref={boardGridRef}
          className="grid grid-cols-8 grid-rows-8 w-full h-full chessboard-surface"
        >
          {displayRanks.map((rank, rIdx) =>
            displayFiles.map((file, fIdx) => {
              const sq = `${file}${rank}`;
              const boardRow = 8 - Number(rank);
              const boardCol = FILES.indexOf(file);
              const piece = boardMatrix[boardRow]?.[boardCol] || null;

              const isLight = (boardRow + boardCol) % 2 === 0;
              const isSelected = selectedSquare === sq;
              const isDragHover = dragState?.active && dragState.hoverSq === sq;
              const isBeingDraggedOrigin = dragState?.active && dragState.from === sq;
              const isLast = lastMove && (lastMove.from === sq || lastMove.to === sq);
              const isHint = hintMove && (hintMove.from === sq || hintMove.to === sq);
              const isLegalTarget = legalTargets.has(sq);
              const isCaptureTarget = legalTargets.get(sq) === true;
              const isCheckedKing = inCheck && piece?.type === 'k' && piece.color === turn;

              let bg = isLight ? theme.lightSquare : theme.darkSquare;
              if (isSelected) bg = theme.highlightSelected;
              else if (isLast) bg = theme.highlightLast;

              return (
                <div
                  key={sq}
                  data-square={sq}
                  onPointerDown={(e) => handleSquarePointerDown(e, sq)}
                  onClick={() => {
                    if (suppressNextClickRef.current) return;
                    if (newlySelectedSquareRef.current === sq) {
                      newlySelectedSquareRef.current = null;
                      return;
                    }
                    newlySelectedSquareRef.current = null;
                    handleSquareTap(sq);
                  }}
                  className="relative flex items-center justify-center cursor-pointer transition-colors duration-100 active:brightness-110"
                  style={{
                    backgroundColor: bg,
                    boxShadow: isCheckedKing
                      ? 'inset 0 0 18px 4px rgba(220, 38, 38, 0.85)'
                      : isDragHover
                        ? 'inset 0 0 0 3px rgba(212, 175, 55, 0.9)'
                        : isHint
                          ? 'inset 0 0 0 3px #10B981'
                          : undefined,
                  }}
                >
                  {/* Rank label on left column */}
                  {fIdx === 0 && (
                    <span
                      className="absolute top-0.5 left-0.5 sm:left-1 text-[9px] sm:text-[10px] font-mono font-semibold leading-none pointer-events-none"
                      style={{ color: isLight ? theme.coordLight : theme.coordDark }}
                    >
                      {rank}
                    </span>
                  )}

                  {/* File label on bottom row */}
                  {rIdx === 7 && (
                    <span
                      className="absolute bottom-0.5 right-0.5 sm:right-1 text-[9px] sm:text-[10px] font-mono font-semibold leading-none pointer-events-none"
                      style={{ color: isLight ? theme.coordLight : theme.coordDark }}
                    >
                      {file}
                    </span>
                  )}

                  {/* Piece */}
                  {piece && (
                    <div
                      className={`w-[86%] h-[86%] flex items-center justify-center transition-transform duration-100 pointer-events-none ${
                        isBeingDraggedOrigin ? 'opacity-20' : 'opacity-100'
                      } ${isSelected && !isBeingDraggedOrigin ? 'scale-105' : ''}`}
                    >
                      <PieceSvg type={piece.type} color={piece.color} styleId={pieceStyle} />
                    </div>
                  )}

                  {/* Legal move dot / capture ring */}
                  {isLegalTarget && !isCaptureTarget && (
                    <span className="w-[30%] h-[30%] rounded-full bg-black/30 pointer-events-none" />
                  )}
                  {isLegalTarget && isCaptureTarget && (
                    <span className="absolute inset-[6%] rounded-full border-[3px] sm:border-[4px] border-black/35 pointer-events-none" />
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Pawn Promotion Picker */}
        {pendingPromotion && (
          <div className="absolute inset-0 z-30 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3">
            <div className="bg-[#141418] border border-[#D4AF37]/40 rounded-xl p-3 sm:p-4 space-y-2.5 shadow-2xl max-w-full">
              <p className="text-xs font-medium text-[#9898A3] text-center">
                Choose Promotion Piece
              </p>
              <div className="flex items-center justify-center gap-2 sm:gap-3">
                {(['q', 'r', 'b', 'n'] as const).map((promo) => (
                  <button
                    key={promo}
                    onClick={() => {
                      onMove(pendingPromotion.from, pendingPromotion.to, promo);
                      setPendingPromotion(null);
                    }}
                    className="w-12 h-12 sm:w-14 sm:h-14 rounded-lg bg-[#1E1E26] hover:bg-[#2A2A35] active:scale-95 border border-white/10 hover:border-[#D4AF37] p-1.5 sm:p-2 transition-all"
                    aria-label={`Promote to ${promo}`}
                  >
                    <PieceSvg type={promo} color={pendingPromotion.color} styleId={pieceStyle} />
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Floating Touch/Pointer Drag Ghost */}
      {dragState?.active && (
        <div
          className="fixed z-50 pointer-events-none w-14 h-14 sm:w-16 sm:h-16 -translate-x-1/2 -translate-y-1/2 scale-110 drop-shadow-2xl"
          style={{
            left: dragState.x,
            top: dragState.y,
          }}
        >
          <PieceSvg
            type={dragState.pieceType}
            color={dragState.pieceColor}
            styleId={pieceStyle}
          />
        </div>
      )}
    </div>
  );
};

export const ChessBoard = React.memo(ChessBoardInner);
