import React from 'react';
import {
  Award,
  Bell,
  Bot,
  Crown,
  Gift,
  Globe,
  KeyRound,
  Lightbulb,
  Play,
  Swords,
  Trophy,
  Users,
  Zap,
} from 'lucide-react';
import { DAILY_MISSIONS } from '../data/achievements';
import { DAILY_CHESS_TIPS } from '../data/trainingData';
import { HERO_BANNER_IMAGE, getCountryFlag, getRankTitle } from '../data/themes';
import {
  Announcement,
  AppUiConfig,
  MatchRecord,
  NotificationItem,
  UserProfile,
} from '../types/chess';
import { VisualEditTarget } from './VisualEditorOverlay';

interface DashboardViewProps {
  user: UserProfile;
  uiConfig: AppUiConfig;
  visualEditMode?: boolean;
  onSelectVisualTarget?: (target: VisualEditTarget) => void;
  onlinePlayers: {
    uid: string;
    playerId: string;
    username: string;
    rating: number;
    country: string;
    avatar: string;
    inGame: boolean;
  }[];
  friendsUids: string[];
  recentMatches: MatchRecord[];
  leaderboardPreview: UserProfile[];
  announcements: Announcement[];
  notifications: NotificationItem[];
  puzzlesSolvedToday: number;
  matchesToday: number;
  onClaimDailyReward: () => void;
  onNavigate: (tab: string, subMode?: string) => void;
  onChallengeFriend: (uid: string) => void;
  onReplayMatch: (match: MatchRecord) => void;
  onMarkNotificationsRead: () => void;
}

const DEFAULT_SECTION_ORDER = ['banner', 'hero', 'dailyTip', 'metrics', 'mainGrid'];

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  uiConfig,
  visualEditMode = false,
  onSelectVisualTarget,
  onlinePlayers,
  friendsUids,
  recentMatches,
  leaderboardPreview,
  announcements,
  notifications,
  puzzlesSolvedToday,
  matchesToday,
  onClaimDailyReward,
  onNavigate,
  onChallengeFriend,
  onReplayMatch,
  onMarkNotificationsRead,
}) => {
  const rank = getRankTitle(user.rating);
  const totalMatches = user.wins + user.losses + user.draws;
  const winRate = totalMatches > 0 ? Math.round((user.wins / totalMatches) * 100) : 0;
  const xpInLevel = user.xp % 250;
  const todayStr = new Date().toISOString().slice(0, 10);
  const dailyClaimed = user.lastDailyClaim === todayStr;

  const onlineFriends = onlinePlayers.filter(
    (p) => p.uid !== user.uid && friendsUids.includes(p.uid)
  );

  const editHighlight = (target: VisualEditTarget) =>
    visualEditMode
      ? 'ring-2 ring-dashed ring-[#D4AF37]/80 cursor-pointer hover:ring-white transition-all relative'
      : '';

  const handleEditClick = (e: React.MouseEvent, target: VisualEditTarget) => {
    if (!visualEditMode || !onSelectVisualTarget) return;
    e.stopPropagation();
    e.preventDefault();
    onSelectVisualTarget(target);
  };

  const dailyTipText =
    uiConfig.dailyTip || DAILY_CHESS_TIPS[new Date().getDate() % DAILY_CHESS_TIPS.length];

  const sectionOrder = uiConfig.sectionOrder?.length
    ? uiConfig.sectionOrder
    : DEFAULT_SECTION_ORDER;

  const renderSection = (key: string) => {
    if (key === 'banner') {
      if (!uiConfig.bannerText && announcements.length === 0 && !visualEditMode) return null;
      return (
        <div
          key="banner"
          onClick={(e) => handleEditClick(e, 'bannerText')}
          className={`rounded-xl bg-[#141418] border border-[#D4AF37]/30 px-5 py-3.5 flex flex-wrap items-center justify-between gap-4 ${editHighlight('bannerText')}`}
        >
          <div className="flex items-center gap-3 min-w-0">
            <Crown className="w-4 h-4 text-[#D4AF37] shrink-0" />
            <div className="text-sm text-[#F5F5F0] truncate">
              <span className="font-semibold text-[#D4AF37] mr-2">
                {announcements[0]?.title || 'Arena Update'}:
              </span>
              <span className="text-[#D4D4CE]">
                {uiConfig.bannerText || announcements[0]?.body || 'Click to configure banner announcement'}
              </span>
            </div>
          </div>
          <button
            onClick={() => !visualEditMode && onNavigate('tournaments')}
            className="text-xs font-semibold text-[#D4AF37] hover:underline whitespace-nowrap shrink-0"
          >
            View Events
          </button>
        </div>
      );
    }

    if (key === 'hero') {
      return (
        <div key="hero" className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          <div
            className={`lg:col-span-7 rounded-xl bg-[#141418] border border-white/10 p-6 md:p-8 flex flex-col justify-between gap-6 ${editHighlight('heroHeadline')}`}
          >
            <div className="space-y-3 sm:space-y-4">
              <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-[#9898A3]">
                <span>Worldwide Competitive Chess</span>
                <span aria-hidden="true">·</span>
                <span>Real-Time Clocks</span>
                <span aria-hidden="true">·</span>
                <span>Offline AI Ready</span>
              </div>
              <h1
                onClick={(e) => handleEditClick(e, 'heroHeadline')}
                className="font-display text-2xl sm:text-4xl lg:text-5xl font-bold text-[#F5F5F0] leading-tight text-balance"
              >
                {uiConfig.heroHeadline}
              </h1>
              <p
                onClick={(e) => handleEditClick(e, 'heroSubtitle')}
                className="text-sm sm:text-base text-[#9898A3] max-w-2xl leading-relaxed"
              >
                {uiConfig.heroSubtitle}
              </p>
            </div>

            <div
              onClick={(e) => handleEditClick(e, 'buttons')}
              className="grid grid-cols-1 xs:grid-cols-2 sm:flex sm:flex-wrap items-center gap-2.5 sm:gap-3 pt-2"
            >
              <button
                onClick={() => !visualEditMode && onNavigate('play', 'matchmaking')}
                className="flex items-center justify-center sm:justify-start gap-2 px-4 sm:px-5 py-2.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs sm:text-sm font-semibold hover:bg-[#E5C158] transition-colors whitespace-nowrap shrink-0 min-h-[44px]"
                style={{ backgroundColor: uiConfig.accentColor }}
              >
                <Globe className="w-4 h-4 shrink-0" />
                <span className="truncate">{uiConfig.buttonLabels?.playWorldwide || 'Play Worldwide'}</span>
              </button>
              <button
                onClick={() => !visualEditMode && onNavigate('play', 'ai')}
                className="flex items-center justify-center sm:justify-start gap-2 px-4 py-2.5 rounded-lg bg-white/5 border border-white/10 text-[#F5F5F0] text-xs sm:text-sm font-medium hover:bg-white/10 transition-colors whitespace-nowrap shrink-0 min-h-[44px]"
              >
                <Bot className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span className="truncate">{uiConfig.buttonLabels?.playComputer || 'Play vs Computer'}</span>
              </button>
              <button
                onClick={() => !visualEditMode && onNavigate('play', 'private')}
                className="flex items-center justify-center sm:justify-start gap-2 px-4 py-2.5 rounded-lg bg-white/5 border border-white/10 text-[#F5F5F0] text-xs sm:text-sm font-medium hover:bg-white/10 transition-colors whitespace-nowrap shrink-0 min-h-[44px]"
              >
                <KeyRound className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span className="truncate">{uiConfig.buttonLabels?.privateRoom || 'Private Room'}</span>
              </button>
              <button
                onClick={() => !visualEditMode && onNavigate('training')}
                className="flex items-center justify-center sm:justify-start gap-2 px-4 py-2.5 rounded-lg bg-white/5 border border-white/10 text-[#F5F5F0] text-xs sm:text-sm font-medium hover:bg-white/10 transition-colors whitespace-nowrap shrink-0 min-h-[44px]"
              >
                <Zap className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span className="truncate">{uiConfig.buttonLabels?.dailyPuzzle || 'Daily Puzzle'}</span>
              </button>
            </div>
          </div>

          <div
            onClick={(e) => handleEditClick(e, 'heroImageUrl')}
            className={`lg:col-span-5 rounded-xl overflow-hidden border border-white/10 relative min-h-[210px] sm:min-h-[240px] bg-[#141418] ${editHighlight('heroImageUrl')}`}
          >
            <img
              src={uiConfig.heroImageUrl || HERO_BANNER_IMAGE}
              alt="Handcrafted obsidian and gold chess pieces on dark marble board"
              referrerPolicy="no-referrer"
              loading="lazy"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0C] via-[#0A0A0C]/35 to-transparent" />
            <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between gap-4">
              <div>
                <p className="text-xs text-[#D4AF37] font-medium">Current Standing</p>
                <p className="font-display text-2xl font-bold text-[#F5F5F0]">{rank.title}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-[#9898A3]">Arena Elo</p>
                <p className="font-mono text-2xl font-bold text-[#D4AF37] tabular-nums">
                  {user.rating}
                </p>
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (key === 'dailyTip') {
      return (
        <div
          key="dailyTip"
          onClick={(e) => handleEditClick(e, 'dailyTip')}
          className={`rounded-xl bg-[#141418] border border-white/10 px-5 py-3.5 flex flex-wrap items-center justify-between gap-4 ${editHighlight('dailyTip')}`}
        >
          <div className="flex items-center gap-3 min-w-0">
            <Lightbulb className="w-4 h-4 text-[#D4AF37] shrink-0" />
            <p className="text-xs sm:text-sm text-[#D4D4CE]">
              <strong className="text-[#D4AF37] mr-2">Daily Chess Tip:</strong>
              {dailyTipText}
            </p>
          </div>
          <button
            onClick={() => !visualEditMode && onNavigate('training')}
            className="text-xs font-semibold text-[#D4AF37] hover:underline whitespace-nowrap shrink-0"
          >
            Open Learning Center
          </button>
        </div>
      );
    }

    if (key === 'metrics') {
      return (
        <div key="metrics" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="rounded-xl bg-[#141418] border border-white/10 p-5 flex items-center gap-4">
            <img
              src={user.avatar}
              alt={user.username}
              referrerPolicy="no-referrer"
              loading="lazy"
              className="w-12 h-12 sm:w-14 sm:h-14 rounded-lg object-cover border border-[#D4AF37]/40 shrink-0"
            />
            <div className="min-w-0">
              <p className="text-base font-semibold text-[#F5F5F0] truncate">
                {user.username} {getCountryFlag(user.country)}
              </p>
              <p className="font-mono text-xs text-[#9898A3] truncate">{user.playerId}</p>
              <p className="text-xs text-[#D4AF37] mt-0.5">
                Level {user.level} · {user.country}
              </p>
            </div>
          </div>

          <div className="rounded-xl bg-[#141418] border border-white/10 p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-[#9898A3]">
              <span>Matches Played</span>
              <Swords className="w-4 h-4 text-[#D4AF37]" />
            </div>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="font-mono text-2xl font-bold text-[#F5F5F0] tabular-nums">
                {totalMatches}
              </span>
              <span className="font-mono text-xs text-[#9898A3] tabular-nums">
                {user.wins}W · {user.losses}L · {user.draws}D ({winRate}%)
              </span>
            </div>
          </div>

          <div className="rounded-xl bg-[#141418] border border-white/10 p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-[#9898A3]">
              <span>Points & Experience</span>
              <Award className="w-4 h-4 text-[#D4AF37]" />
            </div>
            <div className="mt-2 space-y-2">
              <div className="flex items-baseline justify-between">
                <span className="font-mono text-2xl font-bold text-[#F5F5F0] tabular-nums">
                  {user.points} pts
                </span>
                <span className="font-mono text-xs text-[#D4AF37] tabular-nums">
                  {xpInLevel}/250 XP
                </span>
              </div>
              <div className="h-1.5 w-full rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-[#D4AF37] transition-all duration-300"
                  style={{ width: `${Math.min(100, (xpInLevel / 250) * 100)}%` }}
                />
              </div>
            </div>
          </div>

          <div className="rounded-xl bg-[#141418] border border-white/10 p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-[#9898A3]">
              <span>Daily Reward</span>
              <Gift className="w-4 h-4 text-[#D4AF37]" />
            </div>
            <div className="mt-2 flex items-center justify-between gap-2">
              <div>
                <p className="font-mono text-lg font-bold text-[#F5F5F0] tabular-nums">
                  {user.dailyLoginStreak}d Streak
                </p>
                <p className="text-xs text-[#9898A3]">+50 pts · +60 XP</p>
              </div>
              <button
                onClick={() => !visualEditMode && onClaimDailyReward()}
                disabled={dailyClaimed}
                className="px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 bg-[#D4AF37] text-[#0A0A0C] hover:bg-[#E5C158] disabled:bg-white/10 disabled:text-[#9898A3]"
              >
                {dailyClaimed ? 'Claimed' : 'Claim'}
              </button>
            </div>
          </div>
        </div>
      );
    }

    if (key === 'mainGrid') {
      return (
        <div key="mainGrid" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Recent Matches & Daily Challenges */}
          <div className="lg:col-span-7 space-y-6">
            {/* Daily Challenges */}
            <div className="rounded-xl bg-[#141418] border border-white/10 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-xl font-semibold text-[#F5F5F0]">
                  Daily Challenges
                </h2>
                <button
                  onClick={() => onNavigate('training')}
                  className="text-xs text-[#D4AF37] hover:underline"
                >
                  Open Learning
                </button>
              </div>

              <div className="divide-y divide-white/5">
                {DAILY_MISSIONS.map((m) => {
                  const progress =
                    m.id === 'daily_play_1'
                      ? Math.min(m.target, matchesToday)
                      : m.id === 'daily_puzzle_2'
                        ? Math.min(m.target, puzzlesSolvedToday)
                        : Math.min(m.target, user.wins);
                  const pct = Math.min(100, Math.round((progress / m.target) * 100));
                  return (
                    <div key={m.id} className="py-3 first:pt-0 last:pb-0 space-y-2">
                      <div className="flex items-center justify-between gap-4">
                        <span className="text-sm text-[#F5F5F0]">{m.title}</span>
                        <span className="font-mono text-xs text-[#D4AF37] tabular-nums whitespace-nowrap">
                          {progress}/{m.target} · +{m.pointsReward} pts
                        </span>
                      </div>
                      <div className="h-1.5 w-full rounded-full bg-white/10 overflow-hidden">
                        <div
                          className="h-full bg-[#D4AF37] transition-all duration-300"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Recent Match History */}
            <div className="rounded-xl bg-[#141418] border border-white/10 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-xl font-semibold text-[#F5F5F0]">
                  Recent Match History
                </h2>
                <button
                  onClick={() => onNavigate('profile')}
                  className="text-xs text-[#D4AF37] hover:underline"
                >
                  All Matches
                </button>
              </div>

              {recentMatches.length === 0 ? (
                <div className="py-8 text-center space-y-3">
                  <p className="text-sm text-[#9898A3]">
                    No recorded matches yet. Start a ranked game or practice vs Computer.
                  </p>
                  <button
                    onClick={() => onNavigate('play', 'ai')}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
                  >
                    <Play className="w-3.5 h-3.5" />
                    Play First Match
                  </button>
                </div>
              ) : (
                <div className="divide-y divide-white/5">
                  {recentMatches.slice(0, 6).map((m) => (
                    <div
                      key={m.matchId}
                      className="py-3 first:pt-0 last:pb-0 flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-[#F5F5F0] truncate">
                          {m.whiteName} vs {m.blackName}
                        </p>
                        <p className="text-xs text-[#9898A3] mt-0.5 truncate">
                          {m.mode.toUpperCase()} · {m.timeControl} · {m.resultReason}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
                        <span className="font-mono text-xs text-[#D4AF37] tabular-nums">
                          {m.winner === 'draw'
                            ? '1/2-1/2'
                            : m.winner === 'white'
                              ? '1-0'
                              : '0-1'}
                        </span>
                        <button
                          onClick={() => onReplayMatch(m)}
                          className="px-3 py-1.5 rounded-md border border-white/10 text-xs text-[#F5F5F0] hover:border-[#D4AF37] transition-colors min-h-[36px]"
                        >
                          Analyze
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Online Friends, Notifications, Leaderboard Preview */}
          <div className="lg:col-span-5 space-y-6">
            {/* Online Friends */}
            <div className="rounded-xl bg-[#141418] border border-white/10 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-[#D4AF37]" />
                  <h2 className="font-display text-xl font-semibold text-[#F5F5F0]">
                    Online Friends
                  </h2>
                </div>
                <button
                  onClick={() => onNavigate('players')}
                  className="text-xs text-[#D4AF37] hover:underline"
                >
                  Search Players
                </button>
              </div>

              {onlineFriends.length === 0 ? (
                <p className="text-xs text-[#9898A3] py-3">
                  {onlinePlayers.length > 1
                    ? `${onlinePlayers.length} players online globally. Search and add friends in Players Directory.`
                    : 'Invite friends or connect with global players in the Players Directory.'}
                </p>
              ) : (
                <div className="space-y-2.5">
                  {onlineFriends.map((f) => (
                    <div
                      key={f.uid}
                      className="flex items-center justify-between gap-3 py-2 border-b border-white/5 last:border-0"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={f.avatar}
                          alt={f.username}
                          referrerPolicy="no-referrer"
                          className="w-8 h-8 rounded-md object-cover"
                        />
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-[#F5F5F0] truncate">
                            {f.username} {getCountryFlag(f.country)}
                          </p>
                          <p className="text-xs text-[#9898A3] font-mono tabular-nums">
                            {f.rating} · {f.inGame ? 'In Match' : 'Available'}
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => onChallengeFriend(f.uid)}
                        className="px-3 py-1.5 rounded-md bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold hover:bg-[#E5C158] transition-colors shrink-0"
                      >
                        Challenge
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Global Leaderboard Preview */}
            <div className="rounded-xl bg-[#141418] border border-white/10 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-[#D4AF37]" />
                  <h2 className="font-display text-xl font-semibold text-[#F5F5F0]">
                    Global Leaderboard
                  </h2>
                </div>
                <button
                  onClick={() => onNavigate('leaderboards')}
                  className="text-xs text-[#D4AF37] hover:underline"
                >
                  Full Rankings
                </button>
              </div>

              {leaderboardPreview.length === 0 ? (
                <p className="text-xs text-[#9898A3] py-2">
                  Rankings update automatically after completed rated games.
                </p>
              ) : (
                <div className="divide-y divide-white/5">
                  {leaderboardPreview.slice(0, 5).map((p, idx) => (
                    <div
                      key={p.uid}
                      className="py-2.5 first:pt-0 last:pb-0 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="font-mono text-xs text-[#D4AF37] w-5 tabular-nums">
                          #{idx + 1}
                        </span>
                        <span className="text-sm text-[#F5F5F0] truncate">
                          {p.username} {getCountryFlag(p.country)}
                        </span>
                        <span className="text-xs text-[#9898A3] truncate">{p.country}</span>
                      </div>
                      <span className="font-mono text-sm font-semibold text-[#F5F5F0] tabular-nums">
                        {p.rating}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Notifications */}
            <div className="rounded-xl bg-[#141418] border border-white/10 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-[#D4AF37]" />
                  <h2 className="font-display text-xl font-semibold text-[#F5F5F0]">
                    Notifications
                  </h2>
                </div>
                {notifications.some((n) => !n.read) && (
                  <button
                    onClick={onMarkNotificationsRead}
                    className="text-xs text-[#9898A3] hover:text-[#F5F5F0]"
                  >
                    Mark read
                  </button>
                )}
              </div>

              {notifications.length === 0 ? (
                <p className="text-xs text-[#9898A3]">No new notifications.</p>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {notifications.slice(0, 6).map((n) => (
                    <div
                      key={n.id}
                      className={`p-2.5 rounded-lg border text-xs ${
                        n.read
                          ? 'bg-[#0A0A0C]/50 border-white/5 text-[#9898A3]'
                          : 'bg-[#1C1C24] border-[#D4AF37]/30 text-[#F5F5F0]'
                      }`}
                    >
                      <p className="font-semibold">{n.title}</p>
                      <p className="mt-0.5 text-[#9898A3]">{n.body}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      );
    }

    return null;
  };

  return <div className="space-y-6 sm:space-y-8">{sectionOrder.map((k) => renderSection(k))}</div>;
};
