import React from 'react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message || 'An unexpected error occurred.' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#0A0A0C] text-[#F5F5F0] flex items-center justify-center p-6">
          <div className="max-w-md w-full rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
            <h2 className="font-display text-2xl font-bold text-[#D4AF37]">Application Recovery</h2>
            <p className="text-sm text-[#9898A3] leading-relaxed break-words">
              {this.state.message}
            </p>
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-sm font-semibold hover:bg-[#E5C158] transition-colors"
            >
              Reload Arena
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
