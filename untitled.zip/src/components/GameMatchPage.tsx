import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Chess, Square } from 'chess.js';
import {
  AlertTriangle,
  Bot,
  Check,
  Copy,
  Eye,
  Flag,
  Handshake,
  History,
  Lightbulb,
  LogOut,
  MessageSquare,
  RotateCcw,
  Send,
  ShieldAlert,
  ShieldBan,
  Sparkles,
  Users,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { getCountryFlag } from '../data/themes';
import { analyzeGameMoves, findBestMove } from '../engine/chessAI';
import { saveRoomChatToFirestore } from '../services/firestoreService';
import {
  BoardThemeId,
  ChatMessage,
  LocalMatchSetup,
  MatchRecord,
  MoveAnalysisItem,
  PieceStyleId,
  PrivateRoomState,
  UserProfile,
} from '../types/chess';
import { soundFX } from '../utils/soundFX';
import { ChessBoard } from './ChessBoard';

interface GameMatchPageProps {
  user: UserProfile;
  boardTheme: BoardThemeId;
  pieceStyle: PieceStyleId;
  isOnline: boolean;
  activeRoom: PrivateRoomState | null;
  localMatchSetup: LocalMatchSetup | null;
  onExitMatch: () => void;
  // Online room actions
  onStartRoom: () => void;
  onCloseRoom: () => void;
  onKickParticipant: (uid: string) => void;
  onSwitchRole: (role: 'player' | 'spectator') => void;
  onToggleSpectatorChat: () => void;
  onSendRoomMove: (roomId: string, from: string, to: string, promotion?: string) => void;
  onResignRoom: (roomId: string) => void;
  onOfferDrawRoom: (roomId: string) => void;
  onRespondDrawRoom: (roomId: string, accept: boolean) => void;
  onSendRoomChat: (
    roomId: string,
    text: string,
    emoji?: string,
    channel?: 'room' | 'spectator'
  ) => void;
  onBlockPlayer: (targetUid: string) => void;
  onSubmitReport: (targetId: string, targetName: string, reason: string, details: string) => void;
  // Local AI / Offline actions
  onRecordLocalMatch: (match: MatchRecord, playerWon: 'w' | 'b' | 'draw', isOffline: boolean) => void;
}

function formatClock(ms: number): string {
  const totalSec = Math.max(0, Math.ceil(ms / 1000));
  const mins = Math.floor(totalSec / 60);
  const secs = totalSec % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function formatMsgTime(iso: string): string {
  try {
    return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}

export const GameMatchPage: React.FC<GameMatchPageProps> = ({
  user,
  boardTheme,
  pieceStyle,
  isOnline,
  activeRoom,
  localMatchSetup,
  onExitMatch,
  onStartRoom,
  onCloseRoom,
  onKickParticipant,
  onSwitchRole,
  onToggleSpectatorChat,
  onSendRoomMove,
  onResignRoom,
  onOfferDrawRoom,
  onRespondDrawRoom,
  onSendRoomChat,
  onBlockPlayer,
  onSubmitReport,
  onRecordLocalMatch,
}) => {
  const [muted, setMuted] = useState(soundFX.muted);
  const [exitConfirmOpen, setExitConfirmOpen] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  // Mobile Drawer & Landscape Detection
  const [mobileDrawer, setMobileDrawer] = useState<
    null | 'moves' | 'chat' | 'players' | 'analysis'
  >(null);
  const [isCompactLandscape, setIsCompactLandscape] = useState(() =>
    typeof window !== 'undefined'
      ? window.matchMedia('(max-height: 540px) and (orientation: landscape)').matches
      : false
  );

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia('(max-height: 540px) and (orientation: landscape)');
    const onChange = () => setIsCompactLandscape(mq.matches);
    onChange();
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  // Dual-channel Chat State
  const [chatChannel, setChatChannel] = useState<'room' | 'spectator'>('room');
  const [chatText, setChatText] = useState('');
  const [unreadRoom, setUnreadRoom] = useState(0);
  const [unreadSpec, setUnreadSpec] = useState(0);
  const [lastSpamNotice, setLastSpamNotice] = useState<string | null>(null);
  const lastChatCountRef = useRef<number>(0);
  const chatScrollRef = useRef<HTMLDivElement | null>(null);
  const mobileChatScrollRef = useRef<HTMLDivElement | null>(null);
  const recentSendTimesRef = useRef<number[]>([]);

  // Report modal inside gameplay
  const [reportTarget, setReportTarget] = useState<{ uid: string; username: string } | null>(null);
  const [reportReason, setReportReason] = useState('Abusive chat or conduct');
  const [reportDetails, setReportDetails] = useState('');

  // Local AI / Offline Chess state
  const [aiChess, setAiChess] = useState(() => new Chess());
  const [aiWhiteMs, setAiWhiteMs] = useState(
    (localMatchSetup?.timeControl.initialSeconds || 300) * 1000
  );
  const [aiBlackMs, setAiBlackMs] = useState(
    (localMatchSetup?.timeControl.initialSeconds || 300) * 1000
  );
  const [aiLastMove, setAiLastMove] = useState<{ from: string; to: string } | undefined>(undefined);
  const [aiHint, setAiHint] = useState<{ from: string; to: string; san: string } | null>(null);
  const [aiResultText, setAiResultText] = useState<string | null>(null);
  const [aiWinnerSide, setAiWinnerSide] = useState<'w' | 'b' | 'draw' | null>(null);
  const [aiThinking, setAiThinking] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<MoveAnalysisItem[] | null>(null);
  const [geminiCoachText, setGeminiCoachText] = useState<string | null>(null);
  const [geminiLoading, setGeminiLoading] = useState(false);
  const aiStartRef = useRef<number>(Date.now());

  const [nowTick, setNowTick] = useState(Date.now());

  const triggerAiTurn = (currentChess: Chess) => {
    if (!localMatchSetup || currentChess.isGameOver()) return;
    setAiThinking(true);
    setTimeout(() => {
      const copy = new Chess();
      copy.loadPgn(currentChess.pgn());
      const { move } = findBestMove(
        copy.fen(),
        localMatchSetup.difficulty,
        localMatchSetup.personality
      );
      if (move) {
        const res = copy.move(move);
        if (res) {
          if (res.captured) soundFX.playCapture();
          else soundFX.playMove();
          if (copy.inCheck()) soundFX.playCheck();

          if (copy.turn() === 'w') {
            setAiBlackMs((ms) => ms + localMatchSetup.timeControl.incrementSeconds * 1000);
          } else {
            setAiWhiteMs((ms) => ms + localMatchSetup.timeControl.incrementSeconds * 1000);
          }
          setAiLastMove({ from: res.from, to: res.to });
          setAiChess(copy);
          setAiHint(null);

          if (copy.isCheckmate()) {
            concludeAiGame(
              copy,
              `Checkmate — ${res.color === 'w' ? 'White' : 'Black'} wins`,
              res.color
            );
          } else if (copy.isStalemate()) {
            concludeAiGame(copy, 'Draw by stalemate', 'draw');
          } else if (copy.isThreefoldRepetition()) {
            concludeAiGame(copy, 'Draw by threefold repetition', 'draw');
          } else if (copy.isInsufficientMaterial()) {
            concludeAiGame(copy, 'Draw by insufficient material', 'draw');
          } else if (copy.isDraw()) {
            concludeAiGame(copy, 'Draw by 50-move rule', 'draw');
          }
        }
      }
      setAiThinking(false);
    }, 360);
  };

  // Initialize Local AI game cleanly on mount/setup change
  const restartAiGame = () => {
    if (!localMatchSetup) return;
    const fresh = new Chess();
    setAiChess(fresh);
    setAiWhiteMs(localMatchSetup.timeControl.initialSeconds * 1000);
    setAiBlackMs(localMatchSetup.timeControl.initialSeconds * 1000);
    setAiLastMove(undefined);
    setAiHint(null);
    setAiResultText(null);
    setAiWinnerSide(null);
    setAiAnalysis(null);
    setGeminiCoachText(null);
    aiStartRef.current = Date.now();
    if (localMatchSetup.playerSide === 'b') {
      triggerAiTurn(fresh);
    }
  };

  useEffect(() => {
    if (localMatchSetup && !activeRoom) {
      restartAiGame();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [localMatchSetup]);

  // Online clock tick
  useEffect(() => {
    if (!activeRoom || activeRoom.status !== 'playing') return;
    const t = setInterval(() => setNowTick(Date.now()), 250);
    return () => clearInterval(t);
  }, [activeRoom]);

  // Unread tracker & Firestore chat backup
  useEffect(() => {
    if (!activeRoom) return;
    const msgs = activeRoom.chat || [];
    if (msgs.length > lastChatCountRef.current) {
      const added = msgs.slice(lastChatCountRef.current);
      for (const m of added) {
        const ch = m.channel === 'spectator' ? 'spectator' : 'room';
        if (ch === 'room' && chatChannel !== 'room' && m.senderId !== user.uid) {
          setUnreadRoom((c) => c + 1);
        }
        if (ch === 'spectator' && chatChannel !== 'spectator' && m.senderId !== user.uid) {
          setUnreadSpec((c) => c + 1);
        }
        if (m.senderId === user.uid && !user.isGuest && isOnline) {
          saveRoomChatToFirestore(activeRoom.roomId, m).catch(() => {});
        }
      }
      lastChatCountRef.current = msgs.length;
      setTimeout(() => {
        if (chatScrollRef.current) {
          chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
        }
        if (mobileChatScrollRef.current) {
          mobileChatScrollRef.current.scrollTop = mobileChatScrollRef.current.scrollHeight;
        }
      }, 40);
    }
  }, [activeRoom?.chat, activeRoom, chatChannel, user.uid, user.isGuest, isOnline]);

  // Local AI Clocks
  useEffect(() => {
    if (activeRoom || !localMatchSetup || aiResultText) return;
    const timer = setInterval(() => {
      const turn = aiChess.turn();
      if (turn === 'w') {
        setAiWhiteMs((prev) => {
          if (prev <= 250) {
            concludeAiGame(aiChess, 'Black wins on time', 'b');
            return 0;
          }
          return prev - 250;
        });
      } else {
        setAiBlackMs((prev) => {
          if (prev <= 250) {
            concludeAiGame(aiChess, 'White wins on time', 'w');
            return 0;
          }
          return prev - 250;
        });
      }
    }, 250);
    return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeRoom, localMatchSetup, aiResultText, aiChess]);

  const concludeAiGame = (finishedChess: Chess, reason: string, winner: 'w' | 'b' | 'draw') => {
    if (!localMatchSetup || aiResultText) return;
    setAiResultText(reason);
    setAiWinnerSide(winner);
    soundFX.playGameEnd();

    const duration = Math.max(1, Math.floor((Date.now() - aiStartRef.current) / 1000));
    const match: MatchRecord = {
      matchId: `ai_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      whiteId: localMatchSetup.playerSide === 'w' ? user.uid : `ai_${localMatchSetup.difficulty}`,
      whiteName:
        localMatchSetup.playerSide === 'w'
          ? user.username
          : `Engine (${localMatchSetup.difficulty})`,
      whiteRating: localMatchSetup.playerSide === 'w' ? user.rating : 1400,
      blackId: localMatchSetup.playerSide === 'b' ? user.uid : `ai_${localMatchSetup.difficulty}`,
      blackName:
        localMatchSetup.playerSide === 'b'
          ? user.username
          : `Engine (${localMatchSetup.difficulty})`,
      blackRating: localMatchSetup.playerSide === 'b' ? user.rating : 1400,
      pgn: finishedChess.pgn(),
      fen: finishedChess.fen(),
      winner: winner === 'w' ? 'white' : winner === 'b' ? 'black' : 'draw',
      resultReason: reason,
      timeControl: localMatchSetup.timeControl.label,
      mode: isOnline ? 'ai' : 'offline',
      durationSeconds: duration,
      moveCount: finishedChess.history().length,
      ratingDeltaWhite: 0,
      ratingDeltaBlack: 0,
      createdAt: new Date().toISOString(),
    };

    const playerResult: 'w' | 'b' | 'draw' =
      winner === 'draw' ? 'draw' : winner === localMatchSetup.playerSide ? 'w' : 'b';
    onRecordLocalMatch(match, playerResult, !isOnline);
    setAiAnalysis(analyzeGameMoves(finishedChess.pgn()));
  };

  const handlePlayerAiMove = (from: string, to: string, promotion?: string) => {
    if (!localMatchSetup || aiResultText || aiThinking) return;
    if (aiChess.turn() !== localMatchSetup.playerSide) return;

    const copy = new Chess();
    copy.loadPgn(aiChess.pgn());
    try {
      const res = copy.move({
        from: from as Square,
        to: to as Square,
        promotion: (promotion as 'q' | 'r' | 'b' | 'n') || undefined,
      });
      if (!res) return;

      if (res.captured) soundFX.playCapture();
      else soundFX.playMove();
      if (copy.inCheck()) soundFX.playCheck();

      if (localMatchSetup.playerSide === 'w') {
        setAiWhiteMs((ms) => ms + localMatchSetup.timeControl.incrementSeconds * 1000);
      } else {
        setAiBlackMs((ms) => ms + localMatchSetup.timeControl.incrementSeconds * 1000);
      }

      setAiLastMove({ from: res.from, to: res.to });
      setAiChess(copy);
      setAiHint(null);

      if (copy.isCheckmate()) {
        concludeAiGame(
          copy,
          `Checkmate — ${res.color === 'w' ? 'White' : 'Black'} wins`,
          res.color
        );
      } else if (copy.isStalemate()) {
        concludeAiGame(copy, 'Draw by stalemate', 'draw');
      } else if (copy.isThreefoldRepetition()) {
        concludeAiGame(copy, 'Draw by threefold repetition', 'draw');
      } else if (copy.isInsufficientMaterial()) {
        concludeAiGame(copy, 'Draw by insufficient material', 'draw');
      } else if (copy.isDraw()) {
        concludeAiGame(copy, 'Draw by 50-move rule', 'draw');
      } else {
        triggerAiTurn(copy);
      }
    } catch {
      // illegal move
    }
  };

  const handleUndoMove = () => {
    if (!localMatchSetup?.practiceUndoEnabled || aiResultText || aiThinking) return;
    const copy = new Chess();
    copy.loadPgn(aiChess.pgn());
    copy.undo();
    if (copy.turn() !== localMatchSetup.playerSide) copy.undo();
    setAiChess(copy);
    setAiLastMove(undefined);
    setAiHint(null);
  };

  const handleRequestHint = () => {
    if (aiResultText || aiChess.isGameOver()) return;
    const { move } = findBestMove(aiChess.fen(), 'hard', 'balanced');
    if (move) {
      setAiHint({ from: move.from, to: move.to, san: move.san });
    }
  };

  const handleRequestGeminiCoach = async () => {
    if (!aiAnalysis || !aiChess.pgn() || !localMatchSetup) return;
    setGeminiLoading(true);
    try {
      const mistakes = aiAnalysis
        .filter((m) => m.classification === 'Mistake' || m.classification === 'Blunder')
        .map(
          (m) =>
            `Move ${Math.ceil(m.ply / 2)} (${m.moveSan}): ${m.classification}, best was ${m.bestMoveSan}`
        )
        .join('\n');
      const res = await fetch('/api/ai/analyze-match', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pgn: aiChess.pgn(),
          playerColor: localMatchSetup.playerSide,
          mistakesSummary: mistakes || 'Solid play with minimal centipawn loss.',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Analysis failed');
      setGeminiCoachText(data.analysis);
    } catch (err) {
      setGeminiCoachText(err instanceof Error ? err.message : 'Unable to fetch AI coaching.');
    } finally {
      setGeminiLoading(false);
    }
  };

  // Determine whether game is actively in progress (for Exit Confirmation guard)
  const isMatchActive = activeRoom
    ? activeRoom.status === 'playing' &&
      activeRoom.participants.some((p) => p.uid === user.uid && p.role === 'player')
    : !aiResultText && aiChess.history().length > 0;

  const handleSafeExitClick = () => {
    if (isMatchActive) {
      setExitConfirmOpen(true);
    } else {
      onExitMatch();
    }
  };

  // --- Derived Online / Offline View Model ---
  const isOnlineMatch = !!activeRoom;
  const myParticipant = activeRoom?.participants.find((p) => p.uid === user.uid);
  const isOwner = activeRoom ? activeRoom.ownerId === user.uid : false;

  const boardChess = useMemo(() => {
    if (!activeRoom) return aiChess;
    const c = new Chess();
    try {
      if (activeRoom.pgn) c.loadPgn(activeRoom.pgn);
      else c.load(activeRoom.fen);
    } catch {
      // fallback
    }
    return c;
  }, [activeRoom, aiChess]);

  const orientation: 'w' | 'b' = activeRoom
    ? myParticipant?.color === 'b'
      ? 'b'
      : 'w'
    : localMatchSetup?.playerSide || 'w';

  const whitePlayerInfo = activeRoom
    ? activeRoom.participants.find((p) => p.role === 'player' && p.color === 'w')
    : localMatchSetup?.playerSide === 'w'
      ? {
          uid: user.uid,
          username: user.username,
          rating: user.rating,
          country: user.country,
          avatar: user.avatar,
          connected: true,
        }
      : {
          uid: 'ai',
          username: `Arena Engine (${localMatchSetup?.difficulty.toUpperCase()})`,
          rating: 1400,
          country: 'Global',
          avatar: '/src/assets/images/avatar_queen_gold_1794980498804.jpg',
          connected: true,
        };

  const blackPlayerInfo = activeRoom
    ? activeRoom.participants.find((p) => p.role === 'player' && p.color === 'b')
    : localMatchSetup?.playerSide === 'b'
      ? {
          uid: user.uid,
          username: user.username,
          rating: user.rating,
          country: user.country,
          avatar: user.avatar,
          connected: true,
        }
      : {
          uid: 'ai',
          username: `Arena Engine (${localMatchSetup?.difficulty.toUpperCase()})`,
          rating: 1400,
          country: 'Global',
          avatar: '/src/assets/images/avatar_queen_gold_1794980498804.jpg',
          connected: true,
        };

  let liveWhiteMs = aiWhiteMs;
  let liveBlackMs = aiBlackMs;
  if (activeRoom) {
    liveWhiteMs = activeRoom.whiteTimeMs;
    liveBlackMs = activeRoom.blackTimeMs;
    if (activeRoom.status === 'playing' && activeRoom.lastMoveAt) {
      const delta = Math.max(0, nowTick - activeRoom.lastMoveAt);
      if (activeRoom.turn === 'w') liveWhiteMs = Math.max(0, liveWhiteMs - delta);
      else liveBlackMs = Math.max(0, liveBlackMs - delta);
    }
  }

  const topPlayer = orientation === 'w' ? blackPlayerInfo : whitePlayerInfo;
  const bottomPlayer = orientation === 'w' ? whitePlayerInfo : blackPlayerInfo;
  const topTimeMs = orientation === 'w' ? liveBlackMs : liveWhiteMs;
  const bottomTimeMs = orientation === 'w' ? liveWhiteMs : liveBlackMs;
  const topColor = orientation === 'w' ? 'b' : 'w';
  const bottomColor = orientation;

  const historyMoves = boardChess.history();
  const movePairs: { num: number; w: string; b?: string }[] = [];
  for (let i = 0; i < historyMoves.length; i += 2) {
    movePairs.push({ num: i / 2 + 1, w: historyMoves[i], b: historyMoves[i + 1] });
  }

  const blockedSet = new Set(user.blockedUids || []);
  const filteredChat: ChatMessage[] = useMemo(() => {
    if (!activeRoom) return [];
    return activeRoom.chat.filter((c) => {
      if (blockedSet.has(c.senderId)) return false;
      const ch = c.channel === 'spectator' ? 'spectator' : 'room';
      return ch === chatChannel;
    });
  }, [activeRoom, chatChannel, user.blockedUids]);

  const canSendInChannel =
    !activeRoom ||
    myParticipant?.role === 'player' ||
    (chatChannel === 'spectator' && activeRoom.allowSpectatorChat);

  const handleChatSend = (text: string, emoji?: string) => {
    if (!activeRoom) return;
    const now = Date.now();
    recentSendTimesRef.current = recentSendTimesRef.current.filter((t) => now - t < 6000);
    if (recentSendTimesRef.current.length >= 4) {
      setLastSpamNotice('Please wait a moment before sending more messages.');
      setTimeout(() => setLastSpamNotice(null), 2500);
      return;
    }
    recentSendTimesRef.current.push(now);
    const effectiveChannel =
      myParticipant?.role === 'spectator' ? 'spectator' : chatChannel;
    onSendRoomChat(activeRoom.roomId, text, emoji, effectiveChannel);
  };

  const inCheck = boardChess.inCheck();
  const isCheckmate = boardChess.isCheckmate();
  const spectators = activeRoom?.participants.filter((p) => p.role === 'spectator') || [];
  const totalUnreadChat = unreadRoom + unreadSpec;

  const renderPlayerCard = (
    player: typeof topPlayer,
    colorSide: 'w' | 'b',
    timeMs: number,
    isSelfCard: boolean
  ) => {
    const isTurnActive =
      (activeRoom ? activeRoom.status === 'playing' : !aiResultText) &&
      boardChess.turn() === colorSide;

    return (
      <div className="rounded-xl bg-[#141418] border border-white/10 px-3 py-2 sm:px-4 sm:py-3 flex items-center justify-between gap-2.5 sm:gap-4">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
          {player ? (
            <>
              <div className="relative shrink-0">
                <img
                  src={player.avatar}
                  alt={player.username}
                  className={`w-8 h-8 sm:w-10 sm:h-10 rounded-lg object-cover border ${
                    isSelfCard ? 'border-[#D4AF37]/40' : 'border-white/15'
                  }`}
                />
                <span
                  className={`w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full absolute -bottom-0.5 -right-0.5 border-2 border-[#141418] ${
                    player.connected ? 'bg-emerald-400' : 'bg-amber-400'
                  }`}
                />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-xs sm:text-sm font-semibold text-[#F5F5F0] truncate flex items-center gap-1.5">
                  <span className="shrink-0">{getCountryFlag(player.country)}</span>
                  <span className="truncate">{player.username}</span>
                  <span className="hidden xs:inline-block text-[10px] font-mono px-1.5 py-0.5 rounded bg-white/5 text-[#9898A3] shrink-0">
                    {colorSide === 'w' ? 'WHITE' : 'BLACK'}
                  </span>
                </p>
                <p className="text-[11px] sm:text-xs text-[#9898A3] font-mono tabular-nums truncate">
                  Elo {player.rating} · {player.country}
                  {!isOnlineMatch && !isSelfCard && aiThinking ? ' · Thinking...' : ''}
                  {isSelfCard
                    ? ` · ${activeRoom ? activeRoom.timeControl.label : localMatchSetup?.timeControl.label}`
                    : ''}
                </p>
              </div>
            </>
          ) : (
            <p className="text-xs text-[#9898A3] truncate">Waiting for opponent seat...</p>
          )}
        </div>
        <div
          className={`px-2.5 sm:px-3.5 py-1 sm:py-1.5 rounded-lg font-mono text-base sm:text-lg font-bold tabular-nums border shrink-0 ${
            isTurnActive
              ? 'bg-[#D4AF37]/15 border-[#D4AF37] text-[#D4AF37]'
              : 'bg-[#0A0A0C] border-white/10 text-[#F5F5F0]'
          }`}
        >
          {formatClock(timeMs)}
        </div>
      </div>
    );
  };

  const renderMoveHistoryBody = (maxHeightClass: string) => (
    <div className={`${maxHeightClass} overflow-y-auto font-mono text-xs space-y-1`}>
      {movePairs.length === 0 ? (
        <p className="text-[#9898A3] font-sans py-2">Awaiting opening move...</p>
      ) : (
        movePairs.map((p) => (
          <div key={p.num} className="grid grid-cols-12 py-1 border-b border-white/5">
            <span className="col-span-2 text-[#9898A3] tabular-nums">{p.num}.</span>
            <span className="col-span-5 text-[#F5F5F0]">{p.w}</span>
            <span className="col-span-5 text-[#D4AF37]">{p.b || ''}</span>
          </div>
        ))
      )}
    </div>
  );

  const renderParticipantsBody = (maxHeightClass: string) =>
    activeRoom ? (
      <div className={`space-y-1.5 ${maxHeightClass} overflow-y-auto`}>
        {activeRoom.participants.map((pt) => (
          <div
            key={pt.uid}
            className="flex items-center justify-between text-xs py-1.5 border-b border-white/5 last:border-0"
          >
            <div className="flex items-center gap-2 min-w-0">
              <span>{getCountryFlag(pt.country)}</span>
              <span className="text-[#F5F5F0] font-medium truncate">{pt.username}</span>
              <span className="text-[#9898A3] shrink-0">
                {pt.role === 'player'
                  ? `(${pt.color === 'w' ? 'White' : 'Black'})`
                  : '(Spectator)'}
              </span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {pt.uid !== user.uid && (
                <button
                  onClick={() => setReportTarget({ uid: pt.uid, username: pt.username })}
                  className="p-1.5 text-[#9898A3] hover:text-amber-400"
                  title="Report Player"
                >
                  <ShieldAlert className="w-3.5 h-3.5" />
                </button>
              )}
              {isOwner && pt.uid !== user.uid && (
                <button
                  onClick={() => onKickParticipant(pt.uid)}
                  className="px-2 py-1 rounded bg-red-500/15 text-red-400 hover:text-red-300"
                >
                  Kick
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    ) : null;

  const renderChatContent = (scrollElRef: React.RefObject<HTMLDivElement | null>, feedHeightClass: string) =>
    activeRoom ? (
      <div className="space-y-3 flex flex-col">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1 p-1 rounded-lg bg-[#0A0A0C]">
            <button
              onClick={() => {
                setChatChannel('room');
                setUnreadRoom(0);
              }}
              className={`px-3 py-1.5 rounded text-xs font-medium flex items-center gap-1.5 min-h-[36px] ${
                chatChannel === 'room'
                  ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                  : 'text-[#9898A3] hover:text-[#F5F5F0]'
              }`}
            >
              <MessageSquare className="w-3 h-3" />
              Players
              {unreadRoom > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-red-500 text-white text-[10px]">
                  {unreadRoom}
                </span>
              )}
            </button>
            <button
              onClick={() => {
                setChatChannel('spectator');
                setUnreadSpec(0);
              }}
              className={`px-3 py-1.5 rounded text-xs font-medium flex items-center gap-1.5 min-h-[36px] ${
                chatChannel === 'spectator'
                  ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                  : 'text-[#9898A3] hover:text-[#F5F5F0]'
              }`}
            >
              <Eye className="w-3 h-3" />
              Spectators
              {unreadSpec > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-red-500 text-white text-[10px]">
                  {unreadSpec}
                </span>
              )}
            </button>
          </div>

          {isOwner && (
            <button
              onClick={onToggleSpectatorChat}
              className={`px-2.5 py-1.5 rounded text-[11px] border min-h-[36px] ${
                activeRoom.allowSpectatorChat
                  ? 'border-emerald-500/30 text-emerald-300 bg-emerald-500/10'
                  : 'border-red-500/30 text-red-300 bg-red-500/10'
              }`}
              title="Toggle spectator chat permissions"
            >
              Spec Chat: {activeRoom.allowSpectatorChat ? 'ON' : 'OFF'}
            </button>
          )}
        </div>

        {/* Quick Emojis */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {['👏', '🔥', '♟️', '👑', '🤝', '⚡'].map((em) => (
            <button
              key={em}
              disabled={!canSendInChannel}
              onClick={() => handleChatSend(em, em)}
              className="px-2.5 py-1.5 rounded bg-[#0A0A0C] hover:bg-white/10 text-sm disabled:opacity-40 shrink-0 min-h-[36px]"
            >
              {em}
            </button>
          ))}
        </div>

        {/* Chat Feed */}
        <div
          ref={scrollElRef}
          className={`${feedHeightClass} overflow-y-auto space-y-2.5 pr-1 text-xs`}
        >
          {filteredChat.length === 0 ? (
            <p className="text-[#9898A3] py-4 text-center">
              No messages in this channel yet.
            </p>
          ) : (
            filteredChat.map((c) => (
              <div key={c.id} className="group flex items-start gap-2 leading-relaxed">
                {c.role === 'system' ? (
                  <span className="text-[#D4AF37] text-[11px]">{c.text}</span>
                ) : (
                  <>
                    <img
                      src={
                        c.senderAvatar ||
                        '/src/assets/images/avatar_knight_obsidian_1794980498230.jpg'
                      }
                      alt={c.senderName}
                      className="w-6 h-6 rounded object-cover shrink-0 mt-0.5 border border-white/10"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-semibold text-[#F5F5F0] truncate">
                          {c.senderName}{' '}
                          <span className="text-[10px] font-normal text-[#9898A3]">
                            · {c.role} · {formatMsgTime(c.timestamp)}
                          </span>
                        </span>
                        {c.senderId !== user.uid && (
                          <div className="flex items-center gap-1.5 shrink-0 opacity-90 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={() =>
                                setReportTarget({
                                  uid: c.senderId,
                                  username: c.senderName,
                                })
                              }
                              className="p-1 text-[#9898A3] hover:text-amber-400"
                              title="Report message"
                            >
                              <ShieldAlert className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => onBlockPlayer(c.senderId)}
                              className="p-1 text-[#9898A3] hover:text-red-400"
                              title="Block player"
                            >
                              <ShieldBan className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                      <p className="text-[#D4D4CE] break-words">{c.text}</p>
                    </div>
                  </>
                )}
              </div>
            ))
          )}
        </div>

        {lastSpamNotice && <p className="text-[11px] text-amber-400">{lastSpamNotice}</p>}

        {canSendInChannel ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!chatText.trim()) return;
              handleChatSend(chatText);
              setChatText('');
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={chatText}
              onChange={(e) => setChatText(e.target.value)}
              placeholder={
                myParticipant?.role === 'spectator'
                  ? 'Send to Spectator Chat...'
                  : `Message ${chatChannel === 'spectator' ? 'Spectators' : 'Players'}...`
              }
              maxLength={300}
              className="flex-1 min-w-0 px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0] focus:outline-none focus:border-[#D4AF37] min-h-[42px]"
            />
            <button
              type="submit"
              className="px-3.5 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] hover:bg-[#E5C158] min-h-[42px] min-w-[44px] flex items-center justify-center shrink-0"
              aria-label="Send chat message"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <p className="text-[11px] text-[#9898A3] italic bg-[#0A0A0C] p-2.5 rounded-lg border border-white/5">
            {myParticipant?.role === 'spectator' && !activeRoom.allowSpectatorChat
              ? 'Spectator chat is currently disabled by the room owner.'
              : 'Spectators use the Spectators tab so gameplay stays distraction-free.'}
          </p>
        )}
      </div>
    ) : null;

  const renderLocalEngineCard = () =>
    !activeRoom ? (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-[#F5F5F0] flex items-center gap-2">
            <Bot className="w-4 h-4 text-[#D4AF37]" />
            Engine Details & Review
          </h3>
          <span className="text-[11px] text-[#9898A3]">
            {isOnline ? 'Local Multi-Ply Engine' : 'True Offline Mode'}
          </span>
        </div>
        <p className="text-xs text-[#9898A3]">
          Personality: <strong className="text-[#F5F5F0]">{localMatchSetup?.personality}</strong> ·
          Difficulty: <strong className="text-[#F5F5F0]">{localMatchSetup?.difficulty}</strong>
        </p>

        {aiAnalysis && (
          <div className="space-y-3 pt-2 border-t border-white/10">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-[#F5F5F0]">Move Accuracy Report</span>
              {isOnline && (
                <button
                  onClick={handleRequestGeminiCoach}
                  disabled={geminiLoading}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-xs text-[#D4AF37] min-h-[36px]"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  {geminiLoading ? 'Analyzing...' : 'AI Coach Review'}
                </button>
              )}
            </div>
            {geminiCoachText && (
              <div className="p-3 rounded-lg bg-[#0A0A0C] border border-[#D4AF37]/30 text-xs text-[#D4D4CE] whitespace-pre-wrap leading-relaxed max-h-48 overflow-y-auto">
                {geminiCoachText}
              </div>
            )}
            <div className="max-h-44 overflow-y-auto space-y-1 text-xs">
              {aiAnalysis.map((m) => (
                <div
                  key={m.ply}
                  className="flex items-center justify-between py-1 border-b border-white/5"
                >
                  <span className="font-mono text-[#F5F5F0]">
                    {Math.ceil(m.ply / 2)}.{m.color === 'b' ? '..' : ''} {m.moveSan}
                  </span>
                  <span
                    className={
                      m.classification === 'Blunder'
                        ? 'text-red-400'
                        : m.classification === 'Mistake'
                          ? 'text-amber-400'
                          : m.classification === 'Inaccuracy'
                            ? 'text-yellow-300'
                            : 'text-emerald-400'
                    }
                  >
                    {m.classification}
                    {m.bestMoveSan && m.bestMoveSan !== m.moveSan
                      ? ` (Best: ${m.bestMoveSan})`
                      : ''}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    ) : null;

  const renderActionControls = () => (
    <>
      {activeRoom ? (
        <div className="rounded-xl bg-[#141418] border border-white/10 px-2.5 py-2 sm:px-4 sm:py-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            {myParticipant?.role === 'player' && activeRoom.status === 'playing' && (
              <>
                <button
                  onClick={() => onOfferDrawRoom(activeRoom.roomId)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] hover:bg-white/10 min-h-[42px]"
                >
                  <Handshake className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Draw</span>
                </button>
                <button
                  onClick={() => onResignRoom(activeRoom.roomId)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300 hover:bg-red-500/20 min-h-[42px]"
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>Resign</span>
                </button>
              </>
            )}
            {activeRoom.status === 'waiting' && (
              <button
                onClick={() =>
                  onSwitchRole(myParticipant?.role === 'player' ? 'spectator' : 'player')
                }
                className="px-3 py-2 rounded-lg border border-white/10 text-xs text-[#F5F5F0] hover:border-[#D4AF37] min-h-[42px]"
              >
                {myParticipant?.role === 'player' ? 'Spectate' : 'Sit as Player'}
              </button>
            )}
            {isOwner && activeRoom.status === 'waiting' && (
              <button
                onClick={onStartRoom}
                className="px-4 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold hover:bg-[#E5C158] min-h-[42px]"
              >
                Start Match
              </button>
            )}
            {isOwner && (
              <button
                onClick={onCloseRoom}
                className="px-3 py-2 rounded-lg bg-red-500/15 border border-red-500/30 text-xs text-red-300 hover:bg-red-500/25 min-h-[42px]"
              >
                Close
              </button>
            )}
          </div>

          {/* Mobile Drawer Triggers (< lg) */}
          <div className="flex lg:hidden items-center gap-1.5 ml-auto">
            <button
              onClick={() => setMobileDrawer('moves')}
              className="flex items-center gap-1.5 px-2.5 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] min-h-[42px]"
            >
              <History className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Moves ({historyMoves.length})</span>
            </button>
            <button
              onClick={() => setMobileDrawer('chat')}
              className="relative flex items-center gap-1.5 px-2.5 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] min-h-[42px]"
            >
              <MessageSquare className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Chat</span>
              {totalUnreadChat > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-red-500 text-white text-[10px] leading-none font-bold">
                  {totalUnreadChat}
                </span>
              )}
            </button>
            <button
              onClick={() => setMobileDrawer('players')}
              className="flex items-center gap-1 px-2.5 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] min-h-[42px]"
              aria-label="Room participants"
            >
              <Users className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{activeRoom.participants.length}</span>
            </button>
          </div>

          {activeRoom.drawOfferFrom && activeRoom.drawOfferFrom !== user.uid && (
            <div className="w-full flex flex-wrap items-center justify-between gap-2 pt-1.5 border-t border-white/10">
              <span className="text-xs text-[#D4AF37]">Opponent offered a draw:</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onRespondDrawRoom(activeRoom.roomId, true)}
                  className="px-3 py-1.5 rounded bg-emerald-600 text-white text-xs font-semibold min-h-[36px]"
                >
                  Accept
                </button>
                <button
                  onClick={() => onRespondDrawRoom(activeRoom.roomId, false)}
                  className="px-3 py-1.5 rounded bg-white/10 text-xs text-[#F5F5F0] min-h-[36px]"
                >
                  Decline
                </button>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="rounded-xl bg-[#141418] border border-white/10 px-2.5 py-2 sm:px-4 sm:py-3 flex flex-wrap items-center justify-between gap-2">
          {!aiResultText ? (
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              <button
                onClick={handleRequestHint}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] hover:bg-white/10 min-h-[42px]"
              >
                <Lightbulb className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>Hint</span>
              </button>
              {localMatchSetup?.practiceUndoEnabled && (
                <button
                  onClick={handleUndoMove}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] hover:bg-white/10 min-h-[42px]"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Undo</span>
                </button>
              )}
              <button
                onClick={() =>
                  concludeAiGame(
                    aiChess,
                    `${user.username} resigned`,
                    localMatchSetup?.playerSide === 'w' ? 'b' : 'w'
                  )
                }
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300 min-h-[42px]"
              >
                <Flag className="w-3.5 h-3.5" />
                <span>Resign</span>
              </button>
            </div>
          ) : (
            <span className="text-xs font-semibold text-[#D4AF37]">Match Complete</span>
          )}

          {/* Mobile Drawer Triggers for Moves & Analysis (< lg) */}
          <div className="flex lg:hidden items-center gap-1.5 ml-auto">
            <button
              onClick={() => setMobileDrawer('moves')}
              className="flex items-center gap-1.5 px-2.5 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] min-h-[42px]"
            >
              <History className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Moves ({historyMoves.length})</span>
            </button>
            <button
              onClick={() => setMobileDrawer('analysis')}
              className="flex items-center gap-1.5 px-2.5 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] min-h-[42px]"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{aiAnalysis ? 'Review' : 'Engine'}</span>
            </button>
          </div>

          {aiHint && !aiResultText && (
            <span className="text-xs text-emerald-300 font-mono w-full sm:w-auto">
              Hint: {aiHint.san} ({aiHint.from}→{aiHint.to})
            </span>
          )}
        </div>
      )}
    </>
  );

  const renderMatchFinishedCard = () => (
    <>
      {activeRoom && activeRoom.status === 'finished' && (
        <div className="rounded-xl bg-[#141418] border border-[#D4AF37]/40 p-3 sm:p-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="font-display text-lg sm:text-xl font-bold text-[#D4AF37]">
              {activeRoom.winner === 'draw'
                ? 'Match Drawn'
                : activeRoom.winner === 'white'
                  ? 'White Wins'
                  : 'Black Wins'}
            </p>
            <p className="text-xs text-[#9898A3]">{activeRoom.resultReason}</p>
          </div>
          <div className="flex items-center gap-2">
            {isOwner && (
              <button
                onClick={onStartRoom}
                className="px-4 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold min-h-[40px]"
              >
                Rematch
              </button>
            )}
            <button
              onClick={onExitMatch}
              className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] min-h-[40px]"
            >
              Return to Lobby
            </button>
          </div>
        </div>
      )}

      {!activeRoom && aiResultText && (
        <div className="rounded-xl bg-[#141418] border border-[#D4AF37]/40 p-3 sm:p-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="font-display text-lg sm:text-xl font-bold text-[#D4AF37]">
              {aiResultText} (
              {aiWinnerSide === 'draw' ? '1/2-1/2' : aiWinnerSide === 'w' ? '1-0' : '0-1'})
            </p>
            <p className="text-xs text-[#9898A3]">
              {!isOnline
                ? 'Saved offline — syncs automatically when connected.'
                : 'Match recorded to your profile archive.'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={restartAiGame}
              className="px-4 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold min-h-[40px]"
            >
              Play Again
            </button>
            <button
              onClick={onExitMatch}
              className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] min-h-[40px]"
            >
              Exit
            </button>
          </div>
        </div>
      )}
    </>
  );

  // Height-aware square board constraint for mobile portrait & compact phone landscape
  const boardMaxWidthClass = isCompactLandscape
    ? 'max-w-[min(calc(100dvh-64px),50vw,440px)]'
    : 'max-w-[min(100%,calc(100dvh-252px),560px)] lg:max-w-[560px]';

  return (
    <div className="min-h-dvh lg:min-h-screen bg-[#0A0A0C] text-[#F5F5F0] flex flex-col pb-safe">
      {/* Focused Distraction-Free Gameplay Top Bar */}
      <header
        className={`sticky top-0 z-30 border-b border-white/10 bg-[#111115]/95 backdrop-blur-md px-2.5 sm:px-6 flex items-center justify-between gap-2 sm:gap-4 shrink-0 pt-safe ${
          isCompactLandscape ? 'h-11' : 'h-12 sm:h-14'
        }`}
      >
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <button
            onClick={handleSafeExitClick}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs font-medium text-[#F5F5F0] hover:border-[#D4AF37] shrink-0 min-h-[38px]"
          >
            <LogOut className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Exit</span>
            <span className="hidden sm:inline">Match</span>
          </button>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-display text-base sm:text-lg font-bold text-[#F5F5F0] truncate">
                {activeRoom
                  ? activeRoom.roomName
                  : `vs Engine (${localMatchSetup?.difficulty.toUpperCase()})`}
              </span>
              {activeRoom && (
                <span className="hidden xs:inline font-mono text-xs text-[#D4AF37] shrink-0">
                  {activeRoom.roomId}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Turn / Check / Checkmate Pill + Sound & Copy */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
          {isCheckmate ? (
            <span className="px-2 sm:px-3 py-1 rounded-md bg-red-600/20 border border-red-500/40 text-[11px] sm:text-xs font-semibold text-red-300">
              CHECKMATE
            </span>
          ) : inCheck ? (
            <span className="px-2 sm:px-3 py-1 rounded-md bg-amber-500/20 border border-amber-400/50 text-[11px] sm:text-xs font-semibold text-amber-300 flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              CHECK
            </span>
          ) : (
            <span className="px-2 sm:px-3 py-1 rounded-md bg-[#141418] border border-white/10 text-[11px] sm:text-xs text-[#9898A3]">
              Turn:{' '}
              <strong className="text-[#F5F5F0]">
                {boardChess.turn() === 'w' ? 'White' : 'Black'}
              </strong>
            </span>
          )}

          {activeRoom && (
            <button
              onClick={() => {
                navigator.clipboard.writeText(activeRoom.roomId);
                setCopiedCode(true);
                setTimeout(() => setCopiedCode(false), 1500);
              }}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-white/10 text-xs text-[#9898A3] hover:text-[#F5F5F0]"
            >
              {copiedCode ? (
                <Check className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
              {activeRoom.roomId}
            </button>
          )}

          <button
            onClick={() => {
              soundFX.muted = !muted;
              setMuted(!muted);
            }}
            className="p-2 rounded-lg bg-[#141418] border border-white/10 text-[#9898A3] hover:text-[#F5F5F0] min-w-[38px] min-h-[38px] flex items-center justify-center"
            title="Toggle Sound"
            aria-label="Toggle Sound"
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Centered Gameplay Layout */}
      <main
        className={`flex-1 max-w-[1380px] w-full mx-auto px-2.5 sm:px-6 flex flex-col justify-center lg:block ${
          isCompactLandscape ? 'py-1.5' : 'py-2 sm:py-6'
        }`}
      >
        {isCompactLandscape ? (
          /* Phone Landscape Split Layout: Board Left, Clocks + Actions Right */
          <div className="grid grid-cols-12 gap-3 items-center w-full">
            <div className="col-span-6 flex items-center justify-center">
              <ChessBoard
                fen={boardChess.fen()}
                orientation={orientation}
                boardTheme={boardTheme}
                pieceStyle={pieceStyle}
                maxWidthClass={boardMaxWidthClass}
                interactive={
                  activeRoom
                    ? activeRoom.status === 'playing' && myParticipant?.role === 'player'
                    : !aiResultText && !aiThinking
                }
                allowedColor={
                  activeRoom ? myParticipant?.color || 'both' : localMatchSetup?.playerSide || 'w'
                }
                lastMove={activeRoom ? activeRoom.lastMove : aiLastMove}
                hintMove={!activeRoom && aiHint ? { from: aiHint.from, to: aiHint.to } : null}
                onMove={(from, to, promotion) => {
                  if (activeRoom) {
                    onSendRoomMove(activeRoom.roomId, from, to, promotion);
                  } else {
                    handlePlayerAiMove(from, to, promotion);
                  }
                }}
              />
            </div>
            <div className="col-span-6 space-y-2">
              {renderPlayerCard(topPlayer, topColor, topTimeMs, false)}
              {renderPlayerCard(bottomPlayer, bottomColor, bottomTimeMs, true)}
              {renderActionControls()}
              {renderMatchFinishedCard()}
            </div>
          </div>
        ) : (
          /* Standard Portrait Mobile + Tablet + Desktop Grid */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-6 items-start">
            {/* Left / Primary: Player Cards + Board */}
            <div className="lg:col-span-7 space-y-2 sm:space-y-3">
              {renderPlayerCard(topPlayer, topColor, topTimeMs, false)}

              <div className="flex justify-center">
                <ChessBoard
                  fen={boardChess.fen()}
                  orientation={orientation}
                  boardTheme={boardTheme}
                  pieceStyle={pieceStyle}
                  maxWidthClass={boardMaxWidthClass}
                  interactive={
                    activeRoom
                      ? activeRoom.status === 'playing' && myParticipant?.role === 'player'
                      : !aiResultText && !aiThinking
                  }
                  allowedColor={
                    activeRoom ? myParticipant?.color || 'both' : localMatchSetup?.playerSide || 'w'
                  }
                  lastMove={activeRoom ? activeRoom.lastMove : aiLastMove}
                  hintMove={!activeRoom && aiHint ? { from: aiHint.from, to: aiHint.to } : null}
                  onMove={(from, to, promotion) => {
                    if (activeRoom) {
                      onSendRoomMove(activeRoom.roomId, from, to, promotion);
                    } else {
                      handlePlayerAiMove(from, to, promotion);
                    }
                  }}
                />
              </div>

              {renderPlayerCard(bottomPlayer, bottomColor, bottomTimeMs, true)}
              {renderActionControls()}
              {renderMatchFinishedCard()}
            </div>

            {/* Right Column: Desktop Only Sidebar (Hidden on < lg in favor of compact bottom drawer) */}
            <div className="hidden lg:block lg:col-span-5 space-y-4">
              {/* Move History */}
              <div className="rounded-xl bg-[#141418] border border-white/10 p-4 space-y-2.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-[#F5F5F0]">Move History</h3>
                  <span className="font-mono text-xs text-[#9898A3]">
                    Move {boardChess.moveNumber()}
                  </span>
                </div>
                {renderMoveHistoryBody('max-h-44')}
              </div>

              {/* Online: Participants + Real-Time Dual Chat */}
              {activeRoom && (
                <>
                  <div className="rounded-xl bg-[#141418] border border-white/10 p-4 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-semibold text-[#F5F5F0] flex items-center gap-2">
                        <Users className="w-4 h-4 text-[#D4AF37]" />
                        Participants ({activeRoom.participants.length})
                      </h3>
                      <span className="text-xs text-[#9898A3] flex items-center gap-1">
                        <Eye className="w-3.5 h-3.5" />
                        {spectators.length}/{activeRoom.maxSpectators} Spectators
                      </span>
                    </div>
                    {renderParticipantsBody('max-h-32')}
                  </div>

                  {/* Real-Time Dual-Channel Match & Spectator Chat */}
                  <div className="rounded-xl bg-[#141418] border border-white/10 p-4">
                    {renderChatContent(chatScrollRef, 'h-52')}
                  </div>
                </>
              )}

              {/* Local AI / Offline Post-Match Analysis Card */}
              {!activeRoom && (
                <div className="rounded-xl bg-[#141418] border border-white/10 p-4">
                  {renderLocalEngineCard()}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Mobile Slide-Up Collapsible Drawer (Moves / Chat / Participants / Analysis) */}
      {mobileDrawer && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-end justify-center"
          onClick={() => setMobileDrawer(null)}
        >
          <div
            className="w-full max-w-xl rounded-t-2xl bg-[#141418] border-t border-x border-white/15 p-4 pb-safe shadow-2xl max-h-[82dvh] flex flex-col space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1 rounded-full bg-white/20 mx-auto shrink-0" />

            <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-2.5 shrink-0">
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                <button
                  onClick={() => setMobileDrawer('moves')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium min-h-[36px] whitespace-nowrap ${
                    mobileDrawer === 'moves'
                      ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                      : 'bg-white/5 text-[#9898A3]'
                  }`}
                >
                  Moves ({historyMoves.length})
                </button>
                {activeRoom ? (
                  <>
                    <button
                      onClick={() => setMobileDrawer('chat')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium min-h-[36px] flex items-center gap-1 whitespace-nowrap ${
                        mobileDrawer === 'chat'
                          ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                          : 'bg-white/5 text-[#9898A3]'
                      }`}
                    >
                      Chat
                      {totalUnreadChat > 0 && (
                        <span className="px-1.5 rounded-full bg-red-500 text-white text-[10px]">
                          {totalUnreadChat}
                        </span>
                      )}
                    </button>
                    <button
                      onClick={() => setMobileDrawer('players')}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium min-h-[36px] whitespace-nowrap ${
                        mobileDrawer === 'players'
                          ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                          : 'bg-white/5 text-[#9898A3]'
                      }`}
                    >
                      Players ({activeRoom.participants.length})
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => setMobileDrawer('analysis')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium min-h-[36px] whitespace-nowrap ${
                      mobileDrawer === 'analysis'
                        ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                        : 'bg-white/5 text-[#9898A3]'
                    }`}
                  >
                    Engine & Review
                  </button>
                )}
              </div>

              <button
                onClick={() => setMobileDrawer(null)}
                className="p-2 rounded-lg bg-white/5 text-[#9898A3] hover:text-white min-w-[40px] min-h-[40px] flex items-center justify-center shrink-0"
                aria-label="Close panel"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto min-h-0">
              {mobileDrawer === 'moves' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-[#9898A3]">
                    <span>Recorded Notation</span>
                    <span className="font-mono">Move {boardChess.moveNumber()}</span>
                  </div>
                  {renderMoveHistoryBody('max-h-[50dvh]')}
                </div>
              )}

              {mobileDrawer === 'chat' &&
                renderChatContent(mobileChatScrollRef, 'h-[40dvh] max-h-64')}

              {mobileDrawer === 'players' && renderParticipantsBody('max-h-[50dvh]')}

              {mobileDrawer === 'analysis' && renderLocalEngineCard()}
            </div>
          </div>
        </div>
      )}

      {/* Active Match Exit Confirmation Modal */}
      {exitConfirmOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-xl bg-[#141418] border border-white/10 p-5 sm:p-6 space-y-4 max-h-[90dvh] overflow-y-auto">
            <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
              Leave Active Match?
            </h3>
            <p className="text-xs text-[#9898A3] leading-relaxed">
              {activeRoom
                ? 'This competitive match is currently active. Leaving now will count as a resignation/forfeit according to arena rules.'
                : 'Your match against the computer is still in progress. Exit back to Play Arena?'}
            </p>
            <div className="flex flex-wrap justify-end gap-2 pt-2">
              <button
                onClick={() => setExitConfirmOpen(false)}
                className="px-4 py-2.5 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] min-h-[44px]"
              >
                Continue Playing
              </button>
              <button
                onClick={() => {
                  setExitConfirmOpen(false);
                  onExitMatch();
                }}
                className="px-4 py-2.5 rounded-lg bg-red-600 text-white text-xs font-semibold min-h-[44px]"
              >
                Confirm Exit
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-Match Player Report Modal */}
      {reportTarget && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onSubmitReport(
                reportTarget.uid,
                reportTarget.username,
                reportReason,
                reportDetails
              );
              setReportTarget(null);
              setReportDetails('');
            }}
            className="w-full max-w-md rounded-xl bg-[#141418] border border-white/10 p-5 sm:p-6 space-y-4 max-h-[90dvh] overflow-y-auto"
          >
            <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
              Report Player: {reportTarget.username}
            </h3>
            <select
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
            >
              <option>Abusive chat or conduct</option>
              <option>Spamming room chat</option>
              <option>Suspected engine / fair-play violation</option>
              <option>Intentional stalling</option>
            </select>
            <textarea
              rows={3}
              value={reportDetails}
              onChange={(e) => setReportDetails(e.target.value)}
              placeholder="Provide details for moderators..."
              className="w-full px-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setReportTarget(null)}
                className="px-4 py-2.5 rounded-lg text-xs text-[#9898A3] min-h-[44px]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2.5 rounded-lg bg-red-600 text-white text-xs font-semibold min-h-[44px]"
              >
                Submit Report
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
