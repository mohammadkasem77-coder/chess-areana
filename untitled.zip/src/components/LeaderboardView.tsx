import React, { useMemo, useState } from 'react';
import { Award, Globe, Trophy } from 'lucide-react';
import { getRankTitle } from '../data/themes';
import { UserProfile } from '../types/chess';

interface LeaderboardViewProps {
  user: UserProfile;
  players: UserProfile[];
  friendsUids: string[];
}

type BoardFilter =
  | 'global'
  | 'country'
  | 'friends'
  | 'weekly'
  | 'monthly'
  | 'all_time'
  | 'tournament'
  | 'puzzle';

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  user,
  players,
  friendsUids,
}) => {
  const [boardFilter, setBoardFilter] = useState<BoardFilter>('global');
  const [countryFilter, setCountryFilter] = useState(user.country || 'Global');

  const rankedPlayers = useMemo(() => {
    const base = players.filter((p) => !p.isBanned);
    let filtered = base;
    if (boardFilter === 'country') {
      filtered = base.filter(
        (p) => p.country.toLowerCase() === countryFilter.toLowerCase()
      );
    } else if (boardFilter === 'friends') {
      filtered = base.filter((p) => p.uid === user.uid || friendsUids.includes(p.uid));
    }

    return [...filtered].sort((a, b) => {
      if (boardFilter === 'puzzle') return (b.puzzleRating || 1200) - (a.puzzleRating || 1200);
      if (boardFilter === 'tournament') return b.points - a.points;
      if (boardFilter === 'all_time') return b.peakRating - a.peakRating;
      return b.rating - a.rating;
    });
  }, [players, boardFilter, countryFilter, friendsUids, user.uid]);

  const totalMatches = user.wins + user.losses + user.draws;
  const winPct = totalMatches > 0 ? ((user.wins / totalMatches) * 100).toFixed(1) : '0.0';
  const avgDuration =
    totalMatches > 0 ? Math.round(user.totalMatchDurationSeconds / totalMatches) : 0;

  return (
    <div className="space-y-5 sm:space-y-6">
      {/* Personal Competitive Statistics */}
      <div className="rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-display text-xl sm:text-2xl font-bold text-[#F5F5F0] min-w-0 truncate">
            Competitive Statistics — {user.username}
          </h2>
          <span className="font-mono text-xs text-[#D4AF37]">
            {getRankTitle(user.rating).title} ({getRankTitle(user.rating).tier})
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 sm:gap-4 text-xs">
          <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/5">
            <p className="text-[#9898A3]">Win / Loss / Draw</p>
            <p className="font-mono text-sm sm:text-base font-bold text-[#F5F5F0] mt-1 tabular-nums">
              {user.wins} / {user.losses} / {user.draws}
            </p>
          </div>
          <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/5">
            <p className="text-[#9898A3]">Win Percentage</p>
            <p className="font-mono text-sm sm:text-base font-bold text-[#D4AF37] mt-1 tabular-nums">
              {winPct}%
            </p>
          </div>
          <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/5">
            <p className="text-[#9898A3]">Peak Rating</p>
            <p className="font-mono text-sm sm:text-base font-bold text-[#F5F5F0] mt-1 tabular-nums">
              {user.peakRating}
            </p>
          </div>
          <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/5">
            <p className="text-[#9898A3]">Win Streak / Best</p>
            <p className="font-mono text-sm sm:text-base font-bold text-[#F5F5F0] mt-1 tabular-nums">
              {user.winStreak} / {user.bestWinStreak}
            </p>
          </div>
          <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/5">
            <p className="text-[#9898A3]">Fastest / Longest</p>
            <p className="font-mono text-sm sm:text-base font-bold text-[#F5F5F0] mt-1 tabular-nums">
              {user.fastestWinSeconds}s / {user.longestMatchSeconds}s
            </p>
          </div>
          <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/5">
            <p className="text-[#9898A3]">Avg Duration · Moves</p>
            <p className="font-mono text-sm sm:text-base font-bold text-[#F5F5F0] mt-1 tabular-nums">
              {avgDuration}s · {user.totalMoves}
            </p>
          </div>
        </div>
      </div>

      {/* Leaderboard Filters & Table */}
      <div className="rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-6 space-y-4 sm:space-y-5">
        <div className="flex flex-col sm:flex-row sm:flex-wrap sm:items-center justify-between gap-3">
          <div className="flex overflow-x-auto sm:flex-wrap items-center gap-1 p-1 bg-[#0A0A0C] rounded-lg no-scrollbar">
            {[
              { id: 'global', label: 'Global' },
              { id: 'country', label: 'Country' },
              { id: 'friends', label: 'Friends' },
              { id: 'weekly', label: 'Weekly' },
              { id: 'monthly', label: 'Monthly' },
              { id: 'all_time', label: 'All-Time' },
              { id: 'tournament', label: 'Tournament' },
              { id: 'puzzle', label: 'Puzzle' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setBoardFilter(tab.id as BoardFilter)}
                className={`px-3 py-2 sm:py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 min-h-[38px] sm:min-h-0 ${
                  boardFilter === tab.id
                    ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                    : 'text-[#9898A3] hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {boardFilter === 'country' && (
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-[#D4AF37] shrink-0" />
              <input
                type="text"
                value={countryFilter}
                onChange={(e) => setCountryFilter(e.target.value)}
                placeholder="Country..."
                className="flex-1 sm:w-auto px-3 py-2 sm:py-1.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              />
            </div>
          )}
        </div>

        {/* Mobile Card View */}
        <div className="sm:hidden space-y-2.5">
          {rankedPlayers.length === 0 ? (
            <p className="py-6 text-center text-xs text-[#9898A3]">
              No players match this leaderboard filter yet.
            </p>
          ) : (
            rankedPlayers.map((p, idx) => {
              const r = getRankTitle(p.rating);
              const metric =
                boardFilter === 'puzzle'
                  ? p.puzzleRating || 1200
                  : boardFilter === 'tournament'
                    ? p.points
                    : boardFilter === 'all_time'
                      ? p.peakRating
                      : p.rating;
              return (
                <div
                  key={p.uid}
                  className={`p-3 rounded-lg border flex items-center justify-between gap-2.5 text-xs ${
                    p.uid === user.uid
                      ? 'bg-[#D4AF37]/10 border-[#D4AF37]/40'
                      : 'bg-[#0A0A0C] border-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="font-mono text-[#D4AF37] font-bold w-7 shrink-0 tabular-nums">
                      {idx === 0 ? '🏆1' : `#${idx + 1}`}
                    </span>
                    <img
                      src={p.avatar}
                      alt={p.username}
                      loading="lazy"
                      className="w-8 h-8 rounded object-cover shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="font-semibold text-[#F5F5F0] truncate">{p.username}</p>
                      <p className="text-[11px] text-[#9898A3] truncate">
                        {p.country} · {r.tier} · {p.wins}-{p.losses}-{p.draws}
                      </p>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-mono font-bold text-[#F5F5F0] text-sm tabular-nums">{metric}</p>
                    <p className="text-[10px] text-[#9898A3]">
                      {boardFilter === 'puzzle'
                        ? 'Puzzle'
                        : boardFilter === 'tournament'
                          ? 'Points'
                          : boardFilter === 'all_time'
                            ? 'Peak'
                            : 'Elo'}
                    </p>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Desktop Table View (Preserved) */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/10 text-[#9898A3]">
                <th className="py-3 px-2 font-medium">Rank</th>
                <th className="py-3 px-2 font-medium">Player</th>
                <th className="py-3 px-2 font-medium">Country</th>
                <th className="py-3 px-2 font-medium">Tier</th>
                <th className="py-3 px-2 font-medium text-right">W-L-D</th>
                <th className="py-3 px-2 font-medium text-right">
                  {boardFilter === 'puzzle'
                    ? 'Puzzle Elo'
                    : boardFilter === 'tournament'
                      ? 'Points'
                      : boardFilter === 'all_time'
                        ? 'Peak Elo'
                        : 'Rating'}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {rankedPlayers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-[#9898A3]">
                    No players match this leaderboard filter yet.
                  </td>
                </tr>
              ) : (
                rankedPlayers.map((p, idx) => {
                  const r = getRankTitle(p.rating);
                  const metric =
                    boardFilter === 'puzzle'
                      ? p.puzzleRating || 1200
                      : boardFilter === 'tournament'
                        ? p.points
                        : boardFilter === 'all_time'
                          ? p.peakRating
                          : p.rating;
                  return (
                    <tr
                      key={p.uid}
                      className={`hover:bg-white/[0.03] transition-colors ${
                        p.uid === user.uid ? 'bg-[#D4AF37]/10' : ''
                      }`}
                    >
                      <td className="py-3 px-2 font-mono text-[#D4AF37] tabular-nums">
                        {idx === 0 ? (
                          <span className="inline-flex items-center gap-1">
                            <Trophy className="w-3.5 h-3.5" /> 1
                          </span>
                        ) : (
                          `#${idx + 1}`
                        )}
                      </td>
                      <td className="py-3 px-2">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={p.avatar}
                            alt={p.username}
                            loading="lazy"
                            className="w-7 h-7 rounded object-cover"
                          />
                          <div>
                            <p className="font-semibold text-[#F5F5F0]">{p.username}</p>
                            <p className="font-mono text-[10px] text-[#9898A3]">{p.playerId}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-2 text-[#9898A3]">{p.country}</td>
                      <td className="py-3 px-2 text-[#D4D4CE]">
                        <span className="inline-flex items-center gap-1">
                          <Award className="w-3 h-3 text-[#D4AF37]" />
                          {r.tier}
                        </span>
                      </td>
                      <td className="py-3 px-2 text-right font-mono text-[#9898A3] tabular-nums">
                        {p.wins}-{p.losses}-{p.draws}
                      </td>
                      <td className="py-3 px-2 text-right font-mono font-bold text-[#F5F5F0] tabular-nums">
                        {metric}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
