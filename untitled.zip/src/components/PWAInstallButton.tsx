import React, { useState } from 'react';
import { Download, WifiOff } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) return null;

  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="flex items-center gap-1.5 sm:gap-2 rounded-lg border border-[#D4AF37]/40 bg-[#D4AF37]/10 px-2.5 sm:px-3 py-1.5 text-xs font-medium text-[#D4AF37] hover:bg-[#D4AF37]/20 transition-colors whitespace-nowrap shrink-0 min-h-[38px]"
      >
        <Download className="w-3.5 h-3.5" />
        <span className="hidden xs:inline">Install</span>
        <span className="xs:hidden sm:inline">App</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 sm:gap-2 rounded-lg border border-white/15 px-2.5 sm:px-3 py-1.5 text-xs font-medium text-[#F5F5F0] hover:bg-white/5 transition-colors whitespace-nowrap shrink-0 min-h-[38px]"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Install</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
            <div className="w-full max-w-sm rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
              <h3 className="font-display text-xl font-semibold text-[#F5F5F0]">Install Chess Arena</h3>
              <p className="text-sm text-[#9898A3] leading-relaxed">
                1. Tap the <strong>Share</strong> icon in your Safari toolbar.<br />
                2. Scroll down and select <strong>Add to Home Screen</strong>.
              </p>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="w-full rounded-lg bg-[#D4AF37] py-2.5 text-sm font-semibold text-[#0A0A0C] min-h-[44px]"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div className="fixed bottom-20 md:bottom-4 left-3 md:left-4 right-3 md:right-auto z-50 flex items-center gap-2 rounded-lg bg-[#1C1C22] border border-amber-500/40 px-3.5 py-2 text-xs font-medium text-amber-300 shadow-xl">
      <WifiOff className="w-3.5 h-3.5 text-amber-400 shrink-0" />
      <span className="truncate">Offline Mode — Local AI & Downloaded Puzzles Active</span>
    </div>
  );
};
