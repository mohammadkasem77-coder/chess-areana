import React from 'react';
import { PieceStyleId } from '../types/chess';

interface PieceSvgProps {
  type: 'p' | 'n' | 'b' | 'r' | 'q' | 'k';
  color: 'w' | 'b';
  styleId: PieceStyleId;
  className?: string;
}

export const PieceSvg: React.FC<PieceSvgProps> = ({ type, color, styleId, className = 'w-full h-full' }) => {
  const isWhite = color === 'w';

  let fill = isWhite ? '#F7F5EF' : '#1A1A20';
  let stroke = isWhite ? '#23232A' : '#D4AF37';
  let accent = isWhite ? '#D4AF37' : '#F0D77B';
  let strokeWidth = '1.8';

  if (styleId === 'neo') {
    fill = isWhite ? '#FFFFFF' : '#262833';
    stroke = isWhite ? '#334155' : '#94A3B8';
    accent = isWhite ? '#CBD5E1' : '#64748B';
    strokeWidth = '1.5';
  } else if (styleId === 'royal') {
    fill = isWhite ? '#F9E7B2' : '#121216';
    stroke = isWhite ? '#5C440F' : '#D4AF37';
    accent = isWhite ? '#B8891F' : '#F4D47C';
    strokeWidth = '1.9';
  } else if (styleId === 'minimal') {
    fill = isWhite ? '#F4F4F0' : '#18181B';
    stroke = isWhite ? '#18181B' : '#E4E4E7';
    accent = stroke;
    strokeWidth = '1.3';
  }

  return (
    <svg
      viewBox="0 0 45 45"
      className={`${className} select-none pointer-events-none drop-shadow-[0_2px_3px_rgba(0,0,0,0.45)]`}
    >
      {type === 'p' && (
        <g fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
          <path d="M22.5 9a4 4 0 1 0 0 8 4 4 0 0 0 0-8z" />
          <path d="M18.5 18.5c-2.5 2-3.5 5-3 7.5 1.5 1 3 1.5 7 1.5s5.5-.5 7-1.5c.5-2.5-.5-5.5-3-7.5" />
          <path d="M14 35.5c0-3 3.5-5.5 8.5-5.5s8.5 2.5 8.5 5.5H14z" />
          <rect x="11.5" y="35.5" width="22" height="3.5" rx="1.2" />
        </g>
      )}

      {type === 'r' && (
        <g fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 10h4v3h3.5v-3h6v3H29v-3h4v6.5l-2.5 2.5v11.5l2.5 2.5v2.5H12v-2.5l2.5-2.5V19L12 16.5V10z" />
          <path d="M14.5 19h16M14.5 30.5h16" stroke={accent} strokeWidth="1.3" />
          <rect x="10.5" y="35.5" width="24" height="3.5" rx="1.2" />
        </g>
      )}

      {type === 'n' && (
        <g fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
          <path d="M14.5 35.5c.5-7 3-11 6.5-13.5-1.5 0-4.5 1-6.5 2.5-.5-2-.5-4.5 1-6.5 1.5-2 3-3 4.5-4.5L19 9.5c2.5 0 5 1 6.5 2.5 3.5 1 7.5 5 8 11.5.5 4.5-.5 8.5-2 12H14.5z" />
          <circle cx="20.5" cy="15.5" r="1.1" fill={accent} stroke="none" />
          <path d="M26 15.5c2.5 2 3.5 5 3.5 8.5" stroke={accent} strokeWidth="1.2" fill="none" />
          <rect x="11" y="35.5" width="23" height="3.5" rx="1.2" />
        </g>
      )}

      {type === 'b' && (
        <g fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
          <circle cx="22.5" cy="8.5" r="2.2" />
          <path d="M15 30c0-6.5 3.5-13.5 7.5-17.5 4 4 7.5 11 7.5 17.5H15z" />
          <path d="M18.5 21.5l8 5M22.5 17v8" stroke={accent} strokeWidth="1.4" />
          <path d="M13 33.5c2.5-1.5 6-2 9.5-2s7 .5 9.5 2l1 2H12l1-2z" />
          <rect x="11" y="35.5" width="23" height="3.5" rx="1.2" />
        </g>
      )}

      {type === 'q' && (
        <g fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
          <circle cx="9" cy="14" r="2" fill={accent} />
          <circle cx="15.5" cy="10" r="2" fill={accent} />
          <circle cx="22.5" cy="8.5" r="2.2" fill={accent} />
          <circle cx="29.5" cy="10" r="2" fill={accent} />
          <circle cx="36" cy="14" r="2" fill={accent} />
          <path d="M10.5 16l4 15.5h16l4-15.5-5.5 7-4.5-10.5-4.5 10.5-4.5-10.5-4.5 10.5-5.5-7z" />
          <path d="M13.5 31.5h18l1 4H12.5l1-4z" />
          <rect x="11" y="35.5" width="23" height="3.5" rx="1.2" />
        </g>
      )}

      {type === 'k' && (
        <g fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
          <path d="M22.5 6v6.5M19.5 9h6" stroke={accent} strokeWidth="2.2" />
          <path d="M15.5 28c-3-4-4-8.5-2-11.5 2-3 6-2.5 9 1 3-3.5 7-4 9-1 2 3 1 7.5-2 11.5H15.5z" />
          <path d="M14 28h17l1 5.5H13l1-5.5z" />
          <path d="M15.5 31h14" stroke={accent} strokeWidth="1.2" />
          <rect x="11" y="35.5" width="23" height="3.5" rx="1.2" />
        </g>
      )}
    </svg>
  );
};
