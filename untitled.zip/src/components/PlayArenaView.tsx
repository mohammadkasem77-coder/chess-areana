import React, { useEffect, useMemo, useState } from 'react';
import {
  Bot,
  Clock,
  Eye,
  Globe,
  KeyRound,
  Play,
  Plus,
  Search,
  ShieldAlert,
  UserCheck,
  UserPlus,
  Users,
} from 'lucide-react';
import { BOARD_THEMES, PIECE_STYLES, TIME_CONTROLS, getCountryFlag } from '../data/themes';
import {
  AIDifficultyId,
  AIPersonalityId,
  BoardThemeId,
  FriendRequest,
  LocalMatchSetup,
  PieceStyleId,
  PrivateRoomState,
  TimeControlConfig,
  UserProfile,
} from '../types/chess';

interface PlayArenaViewProps {
  initialSubMode?: string;
  user: UserProfile;
  boardTheme: BoardThemeId;
  pieceStyle: PieceStyleId;
  onChangeBoardTheme: (t: BoardThemeId) => void;
  onChangePieceStyle: (p: PieceStyleId) => void;
  isOnline: boolean;
  wsConnected: boolean;
  roomClosedMessage: string | null;
  matchmakingQueued: boolean;
  publicRooms: PrivateRoomState[];
  onlinePlayers: {
    uid: string;
    playerId: string;
    username: string;
    rating: number;
    country: string;
    avatar: string;
    inGame: boolean;
  }[];
  friendRequests: FriendRequest[];
  onStartLocalAiMatch: (setup: LocalMatchSetup) => void;
  onJoinMatchmaking: (tc: TimeControlConfig) => void;
  onCancelMatchmaking: () => void;
  onCreateRoom: (payload: {
    roomId: string;
    roomName: string;
    password: string;
    gameMode: string;
    timeControl: TimeControlConfig;
    maxSpectators: number;
    playAs: 'w' | 'b' | 'random';
    allowSpectatorChat: boolean;
  }) => void;
  onJoinRoom: (roomId: string, password: string, role: 'player' | 'spectator') => void;
  onClearClosedRoom: () => void;
  onSendFriendRequest: (toUid: string, toUsername: string) => void;
  onRespondFriendRequest: (requestId: string, status: 'accepted' | 'declined' | 'blocked') => void;
  onInviteFriend: (targetUid: string, tc: TimeControlConfig) => void;
  onSubmitReport: (targetId: string, targetName: string, reason: string, details: string) => void;
  onReturnDashboard: () => void;
}

export const PlayArenaView: React.FC<PlayArenaViewProps> = ({
  initialSubMode = 'ai',
  user,
  boardTheme,
  pieceStyle,
  onChangeBoardTheme,
  onChangePieceStyle,
  isOnline,
  wsConnected,
  roomClosedMessage,
  matchmakingQueued,
  publicRooms,
  onlinePlayers,
  friendRequests,
  onStartLocalAiMatch,
  onJoinMatchmaking,
  onCancelMatchmaking,
  onCreateRoom,
  onJoinRoom,
  onClearClosedRoom,
  onSendFriendRequest,
  onRespondFriendRequest,
  onInviteFriend,
  onSubmitReport,
  onReturnDashboard,
}) => {
  const [subMode, setSubMode] = useState<'ai' | 'matchmaking' | 'private' | 'friends'>(
    initialSubMode === 'matchmaking' ||
      initialSubMode === 'private' ||
      initialSubMode === 'friends'
      ? initialSubMode
      : 'ai'
  );

  useEffect(() => {
    if (
      initialSubMode === 'ai' ||
      initialSubMode === 'matchmaking' ||
      initialSubMode === 'private' ||
      initialSubMode === 'friends'
    ) {
      setSubMode(initialSubMode);
    }
  }, [initialSubMode]);

  const [selectedTcId, setSelectedTcId] = useState('5+0');
  const [customMinutes, setCustomMinutes] = useState(7);
  const [customIncrement, setCustomIncrement] = useState(3);
  const selectedTimeControl: TimeControlConfig = useMemo(() => {
    if (selectedTcId === 'custom') {
      return {
        id: `custom-${customMinutes}+${customIncrement}`,
        label: `${customMinutes}+${customIncrement}`,
        category: 'custom',
        initialSeconds: Math.max(30, customMinutes * 60),
        incrementSeconds: Math.max(0, customIncrement),
      };
    }
    return TIME_CONTROLS.find((t) => t.id === selectedTcId) || TIME_CONTROLS[4];
  }, [selectedTcId, customMinutes, customIncrement]);

  // AI Match Setup
  const [aiDifficulty, setAiDifficulty] = useState<AIDifficultyId>('medium');
  const [aiPersonality, setAiPersonality] = useState<AIPersonalityId>('balanced');
  const [playerSide, setPlayerSide] = useState<'w' | 'b'>('w');
  const [practiceUndoEnabled, setPracticeUndoEnabled] = useState(true);

  // Private Room Form State
  const [roomTab, setRoomTab] = useState<'create' | 'join'>('create');
  const [createRoomCode, setCreateRoomCode] = useState(
    `ARENA-${Math.random().toString(36).substring(2, 6).toUpperCase()}`
  );
  const [createRoomName, setCreateRoomName] = useState(`${user.username}'s Arena`);
  const [createRoomPassword, setCreateRoomPassword] = useState('');
  const [createMaxSpecs, setCreateMaxSpecs] = useState(20);
  const [createPlayAs, setCreatePlayAs] = useState<'w' | 'b' | 'random'>('w');
  const [allowSpecChat, setAllowSpecChat] = useState(true);

  const [joinRoomCode, setJoinRoomCode] = useState('');
  const [joinRoomPassword, setJoinRoomPassword] = useState('');
  const [joinRoleModal, setJoinRoleModal] = useState<{ roomId: string; password: string } | null>(
    null
  );

  // Friends Search & Report State
  const [friendSearch, setFriendSearch] = useState('');
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  const [reportTarget, setReportTarget] = useState<{ uid: string; username: string } | null>(null);
  const [reportReason, setReportReason] = useState('Abusive chat or conduct');
  const [reportDetails, setReportDetails] = useState('');

  const handleSearchPlayers = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch(`/api/users/search?q=${encodeURIComponent(friendSearch)}`);
      const data = await res.json();
      setSearchResults((data.users || []).filter((u: UserProfile) => u.uid !== user.uid));
    } catch {
      setSearchResults([]);
    }
  };

  if (roomClosedMessage) {
    return (
      <div className="max-w-lg mx-auto rounded-xl bg-[#141418] border border-white/10 p-8 text-center space-y-5 my-10">
        <KeyRound className="w-10 h-10 text-[#D4AF37] mx-auto" />
        <h2 className="font-display text-2xl font-bold text-[#F5F5F0]">Room Closed</h2>
        <p className="text-sm text-[#9898A3]">{roomClosedMessage}</p>
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            onClick={() => {
              onClearClosedRoom();
              onReturnDashboard();
            }}
            className="px-5 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm font-medium text-[#F5F5F0] hover:bg-white/10 transition-colors"
          >
            Return to Dashboard
          </button>
          <button
            onClick={() => {
              onClearClosedRoom();
              setSubMode('private');
              setRoomTab('create');
              setCreateRoomCode(
                `ARENA-${Math.random().toString(36).substring(2, 6).toUpperCase()}`
              );
            }}
            className="px-5 py-2.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-sm font-semibold hover:bg-[#E5C158] transition-colors"
          >
            Create Another Room
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Sub-mode Switcher & Board Appearance Lobby Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 rounded-xl bg-[#141418] border border-white/10 p-3">
        <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-1 p-1 bg-[#0A0A0C] rounded-lg w-full lg:w-auto">
          <button
            onClick={() => setSubMode('ai')}
            className={`flex items-center justify-center sm:justify-start gap-2 px-3 py-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap min-h-[42px] ${
              subMode === 'ai'
                ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                : 'text-[#9898A3] hover:text-[#F5F5F0]'
            }`}
          >
            <Bot className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">vs Computer</span>
          </button>
          <button
            onClick={() => setSubMode('matchmaking')}
            className={`flex items-center justify-center sm:justify-start gap-2 px-3 py-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap min-h-[42px] ${
              subMode === 'matchmaking'
                ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                : 'text-[#9898A3] hover:text-[#F5F5F0]'
            }`}
          >
            <Globe className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Matchmaking</span>
          </button>
          <button
            onClick={() => setSubMode('private')}
            className={`flex items-center justify-center sm:justify-start gap-2 px-3 py-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap min-h-[42px] ${
              subMode === 'private'
                ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                : 'text-[#9898A3] hover:text-[#F5F5F0]'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Private Rooms</span>
          </button>
          <button
            onClick={() => setSubMode('friends')}
            className={`flex items-center justify-center sm:justify-start gap-2 px-3 py-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap min-h-[42px] ${
              subMode === 'friends'
                ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                : 'text-[#9898A3] hover:text-[#F5F5F0]'
            }`}
          >
            <Users className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Friends</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:flex sm:flex-wrap items-center gap-2 w-full lg:w-auto">
          <select
            value={boardTheme}
            onChange={(e) => onChangeBoardTheme(e.target.value as BoardThemeId)}
            aria-label="Board theme"
            className="w-full sm:w-auto px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0] focus:outline-none focus:border-[#D4AF37] min-h-[42px]"
          >
            {Object.values(BOARD_THEMES).map((t) => (
              <option key={t.id} value={t.id}>
                Board: {t.name}
              </option>
            ))}
          </select>

          <select
            value={pieceStyle}
            onChange={(e) => onChangePieceStyle(e.target.value as PieceStyleId)}
            aria-label="Piece style"
            className="w-full sm:w-auto px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0] focus:outline-none focus:border-[#D4AF37] min-h-[42px]"
          >
            {PIECE_STYLES.map((ps) => (
              <option key={ps.id} value={ps.id}>
                Pieces: {ps.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* SUB-MODE A: PLAY VS COMPUTER / TRUE OFFLINE SETUP */}
      {subMode === 'ai' && (
        <div className="max-w-3xl mx-auto rounded-xl bg-[#141418] border border-white/10 p-6 md:p-8 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#F5F5F0]">
                Play vs Computer Engine
              </h2>
              <p className="text-xs text-[#9898A3] mt-1">
                {isOnline
                  ? 'Select engine strength, personality, and time control to launch the dedicated match board.'
                  : 'True Offline Mode Active — Local engine and offline match archive ready without internet.'}
              </p>
            </div>
            <span className="px-3 py-1 rounded-md bg-[#0A0A0C] border border-[#D4AF37]/40 text-xs font-mono text-[#D4AF37]">
              {isOnline ? 'Engine Online' : 'Offline Ready'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-[#9898A3] mb-1.5">AI Difficulty Level</label>
              <select
                value={aiDifficulty}
                onChange={(e) => setAiDifficulty(e.target.value as AIDifficultyId)}
                className="w-full px-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              >
                <option value="beginner">Beginner (~600)</option>
                <option value="easy">Easy (~900)</option>
                <option value="medium">Medium (~1300)</option>
                <option value="hard">Hard (~1650)</option>
                <option value="expert">Expert (~2000)</option>
                <option value="master">Master (~2300)</option>
                <option value="grandmaster">Grandmaster (~2600)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-[#9898A3] mb-1.5">AI Personality</label>
              <select
                value={aiPersonality}
                onChange={(e) => setAiPersonality(e.target.value as AIPersonalityId)}
                className="w-full px-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              >
                <option value="balanced">Balanced Strategist</option>
                <option value="tactician">Tal Tactician (Aggressive)</option>
                <option value="fortress">Petrosian Fortress (Defensive)</option>
                <option value="endgame">Capablanca Endgame Specialist</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-[#9898A3] mb-1.5">Time Control</label>
              <select
                value={selectedTcId}
                onChange={(e) => setSelectedTcId(e.target.value)}
                className="w-full px-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              >
                {TIME_CONTROLS.map((tc) => (
                  <option key={tc.id} value={tc.id}>
                    {tc.label} ({tc.category})
                  </option>
                ))}
                <option value="custom">Custom Clock</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-[#9898A3] mb-1.5">Your Side</label>
              <select
                value={playerSide}
                onChange={(e) => setPlayerSide(e.target.value as 'w' | 'b')}
                className="w-full px-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              >
                <option value="w">White (First Move)</option>
                <option value="b">Black</option>
              </select>
            </div>
          </div>

          {selectedTcId === 'custom' && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-[#9898A3] mb-1">Minutes</label>
                <input
                  type="number"
                  min={1}
                  max={90}
                  value={customMinutes}
                  onChange={(e) => setCustomMinutes(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                />
              </div>
              <div>
                <label className="block text-xs text-[#9898A3] mb-1">Increment (sec)</label>
                <input
                  type="number"
                  min={0}
                  max={60}
                  value={customIncrement}
                  onChange={(e) => setCustomIncrement(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                />
              </div>
            </div>
          )}

          <label className="flex items-center gap-2 text-xs text-[#9898A3] cursor-pointer">
            <input
              type="checkbox"
              checked={practiceUndoEnabled}
              onChange={(e) => setPracticeUndoEnabled(e.target.checked)}
              className="accent-[#D4AF37]"
            />
            Allow Undo Move & Hints (Practice Mode)
          </label>

          <button
            onClick={() =>
              onStartLocalAiMatch({
                difficulty: aiDifficulty,
                personality: aiPersonality,
                playerSide,
                timeControl: selectedTimeControl,
                practiceUndoEnabled,
              })
            }
            className="w-full flex items-center justify-center gap-2 py-3 px-5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-sm font-semibold hover:bg-[#E5C158] transition-colors"
          >
            <Play className="w-4 h-4" />
            Start Computer Match ({selectedTimeControl.label})
          </button>
        </div>
      )}

      {/* SUB-MODE B: WORLDWIDE MATCHMAKING */}
      {subMode === 'matchmaking' && (
        <div className="rounded-xl bg-[#141418] border border-white/10 p-6 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 className="font-display text-2xl font-bold text-[#F5F5F0]">
                Worldwide Skill-Based Matchmaking
              </h2>
              <p className="text-xs text-[#9898A3] mt-1">
                Pairs you automatically with an available opponent near your {user.rating} Elo rating and opens the dedicated match interface.
                {!wsConnected && ' Connecting to real-time arena server...'}
              </p>
            </div>
            <div className="text-right font-mono text-xs text-[#D4AF37] tabular-nums">
              {onlinePlayers.length} Players Online
            </div>
          </div>

          {!isOnline ? (
            <div className="p-6 rounded-xl bg-[#0A0A0C] border border-amber-500/30 text-sm text-amber-300">
              You are currently offline. Worldwide matchmaking requires an internet connection. Switch to Play vs Computer for True Offline Mode.
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {TIME_CONTROLS.map((tc) => (
                  <button
                    key={tc.id}
                    onClick={() => setSelectedTcId(tc.id)}
                    className={`p-3 rounded-xl border text-left transition-colors ${
                      selectedTcId === tc.id
                        ? 'bg-[#D4AF37]/15 border-[#D4AF37] text-[#F5F5F0]'
                        : 'bg-[#0A0A0C] border-white/10 text-[#9898A3] hover:border-white/30'
                    }`}
                  >
                    <p className="font-mono text-lg font-bold text-[#F5F5F0]">{tc.label}</p>
                    <p className="text-xs capitalize text-[#9898A3]">{tc.category}</p>
                  </button>
                ))}
                <button
                  onClick={() => setSelectedTcId('custom')}
                  className={`p-3 rounded-xl border text-left transition-colors ${
                    selectedTcId === 'custom'
                      ? 'bg-[#D4AF37]/15 border-[#D4AF37] text-[#F5F5F0]'
                      : 'bg-[#0A0A0C] border-white/10 text-[#9898A3] hover:border-white/30'
                  }`}
                >
                  <p className="font-mono text-lg font-bold text-[#F5F5F0]">Custom</p>
                  <p className="text-xs text-[#9898A3]">Set clock</p>
                </button>
              </div>

              {selectedTcId === 'custom' && (
                <div className="flex flex-wrap items-center gap-4 p-4 rounded-xl bg-[#0A0A0C] border border-white/10">
                  <div>
                    <label className="block text-xs text-[#9898A3] mb-1">Minutes</label>
                    <input
                      type="number"
                      min={1}
                      max={90}
                      value={customMinutes}
                      onChange={(e) => setCustomMinutes(Number(e.target.value))}
                      className="w-28 px-3 py-1.5 rounded bg-[#141418] border border-white/10 text-xs text-[#F5F5F0]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#9898A3] mb-1">Increment (sec)</label>
                    <input
                      type="number"
                      min={0}
                      max={60}
                      value={customIncrement}
                      onChange={(e) => setCustomIncrement(Number(e.target.value))}
                      className="w-28 px-3 py-1.5 rounded bg-[#141418] border border-white/10 text-xs text-[#F5F5F0]"
                    />
                  </div>
                </div>
              )}

              <div className="flex items-center gap-4">
                {!matchmakingQueued ? (
                  <button
                    onClick={() => onJoinMatchmaking(selectedTimeControl)}
                    disabled={!wsConnected}
                    className="flex items-center gap-2 px-6 py-3 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-sm font-semibold hover:bg-[#E5C158] transition-colors disabled:opacity-50"
                  >
                    <Clock className="w-4 h-4" />
                    Quick Match ({selectedTimeControl.label})
                  </button>
                ) : (
                  <div className="flex items-center gap-4">
                    <div className="px-4 py-2.5 rounded-lg bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-xs text-[#D4AF37] font-medium">
                      Searching worldwide queue ({selectedTimeControl.label}) near Elo {user.rating}...
                    </div>
                    <button
                      onClick={onCancelMatchmaking}
                      className="px-4 py-2.5 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] hover:bg-white/10"
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      )}

      {/* SUB-MODE C: PRIVATE ROOM SYSTEM */}
      {subMode === 'private' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-6 rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-6 space-y-5">
            <div className="grid grid-cols-2 sm:inline-flex items-center gap-1 p-1 bg-[#0A0A0C] rounded-lg w-full sm:w-fit">
              <button
                onClick={() => setRoomTab('create')}
                className={`px-3 sm:px-4 py-2 rounded-md text-xs font-medium min-h-[40px] ${
                  roomTab === 'create'
                    ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                    : 'text-[#9898A3] hover:text-white'
                }`}
              >
                Create Room
              </button>
              <button
                onClick={() => setRoomTab('join')}
                className={`px-3 sm:px-4 py-2 rounded-md text-xs font-medium min-h-[40px] ${
                  roomTab === 'join'
                    ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                    : 'text-[#9898A3] hover:text-white'
                }`}
              >
                Join by ID
              </button>
            </div>

            {roomTab === 'create' ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  onCreateRoom({
                    roomId: createRoomCode,
                    roomName: createRoomName,
                    password: createRoomPassword,
                    gameMode: selectedTimeControl.category,
                    timeControl: selectedTimeControl,
                    maxSpectators: createMaxSpecs,
                    playAs: createPlayAs,
                    allowSpectatorChat: allowSpecChat,
                  });
                }}
                className="space-y-4"
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-[#9898A3] mb-1">Unique Room Code</label>
                    <input
                      type="text"
                      required
                      value={createRoomCode}
                      onChange={(e) => setCreateRoomCode(e.target.value.toUpperCase())}
                      className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 font-mono text-xs text-[#F5F5F0]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#9898A3] mb-1">Room Password</label>
                    <input
                      type="password"
                      value={createRoomPassword}
                      onChange={(e) => setCreateRoomPassword(e.target.value)}
                      placeholder="Optional secure password"
                      className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-[#9898A3] mb-1">Room Name</label>
                  <input
                    type="text"
                    required
                    value={createRoomName}
                    onChange={(e) => setCreateRoomName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs text-[#9898A3] mb-1">Time Control</label>
                    <select
                      value={selectedTcId}
                      onChange={(e) => setSelectedTcId(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                    >
                      {TIME_CONTROLS.map((tc) => (
                        <option key={tc.id} value={tc.id}>
                          {tc.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-[#9898A3] mb-1">Max Spectators</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={createMaxSpecs}
                      onChange={(e) => setCreateMaxSpecs(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#9898A3] mb-1">Your Color</label>
                    <select
                      value={createPlayAs}
                      onChange={(e) => setCreatePlayAs(e.target.value as 'w' | 'b' | 'random')}
                      className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                    >
                      <option value="w">White</option>
                      <option value="b">Black</option>
                      <option value="random">Random</option>
                    </select>
                  </div>
                </div>

                <label className="flex items-center gap-2 text-xs text-[#9898A3] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={allowSpecChat}
                    onChange={(e) => setAllowSpecChat(e.target.checked)}
                    className="accent-[#D4AF37]"
                  />
                  Enable Spectator Chat Channel
                </label>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold hover:bg-[#E5C158]"
                >
                  <Plus className="w-4 h-4" />
                  Create Room
                </button>
              </form>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!joinRoomCode.trim()) return;
                  setJoinRoleModal({
                    roomId: joinRoomCode.trim().toUpperCase(),
                    password: joinRoomPassword,
                  });
                }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-xs text-[#9898A3] mb-1">Room ID / Code</label>
                  <input
                    type="text"
                    required
                    value={joinRoomCode}
                    onChange={(e) => setJoinRoomCode(e.target.value.toUpperCase())}
                    placeholder="e.g. ARENA-7X9P"
                    className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 font-mono text-xs text-[#F5F5F0]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#9898A3] mb-1">Room Password</label>
                  <input
                    type="password"
                    value={joinRoomPassword}
                    onChange={(e) => setJoinRoomPassword(e.target.value)}
                    placeholder="Leave blank if room has no password"
                    className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                  />
                </div>
                <div>
                  <label className="block text-xs text-[#9898A3] mb-1">Player Identity</label>
                  <input
                    type="text"
                    disabled
                    value={`${user.username} (${user.playerId})`}
                    className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C]/60 border border-white/10 text-xs text-[#9898A3]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold hover:bg-[#E5C158]"
                >
                  Enter Room
                </button>
              </form>
            )}
          </div>

          <div className="lg:col-span-6 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
            <h3 className="font-display text-xl font-semibold text-[#F5F5F0]">
              Active Arena Rooms
            </h3>
            {publicRooms.length === 0 ? (
              <p className="text-xs text-[#9898A3] py-4">
                No active custom rooms right now. Create one to invite friends or spectators.
              </p>
            ) : (
              <div className="divide-y divide-white/5">
                {publicRooms.map((rm) => {
                  const playerCount = rm.participants.filter((p) => p.role === 'player').length;
                  const specCount = rm.participants.filter((p) => p.role === 'spectator').length;
                  return (
                    <div
                      key={rm.roomId}
                      className="py-3 first:pt-0 last:pb-0 flex items-center justify-between gap-4"
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-[#F5F5F0] truncate">
                          {rm.roomName}
                        </p>
                        <p className="text-xs text-[#9898A3] font-mono">
                          {rm.roomId} · {rm.timeControl.label} · {playerCount}/2 Players ·{' '}
                          {specCount}/{rm.maxSpectators} Spectators
                          {rm.hasPassword ? ' · Password Protected' : ''}
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          if (rm.hasPassword) {
                            setRoomTab('join');
                            setJoinRoomCode(rm.roomId);
                          } else {
                            setJoinRoleModal({ roomId: rm.roomId, password: '' });
                          }
                        }}
                        className="px-3.5 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] hover:border-[#D4AF37] shrink-0"
                      >
                        Enter
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-MODE D: PLAY WITH FRIENDS */}
      {subMode === 'friends' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-6 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
            <h3 className="font-display text-xl font-semibold text-[#F5F5F0]">
              Find Players by Username or Player ID
            </h3>
            <form onSubmit={handleSearchPlayers} className="flex gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-[#9898A3] absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={friendSearch}
                  onChange={(e) => setFriendSearch(e.target.value)}
                  placeholder="Username or CA-XXXX..."
                  className="w-full pl-9 pr-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
              >
                Search
              </button>
            </form>

            <div className="divide-y divide-white/5">
              {(searchResults.length > 0
                ? searchResults
                : onlinePlayers.filter((p) => p.uid !== user.uid)
              ).map((p) => (
                <div key={p.uid} className="py-3 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={p.avatar}
                      alt={p.username}
                      className="w-9 h-9 rounded-md object-cover"
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-[#F5F5F0] truncate">
                        {getCountryFlag(p.country)} {p.username}
                      </p>
                      <p className="text-xs text-[#9898A3] font-mono tabular-nums">
                        {p.playerId} · {p.rating} · {p.country}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => onSendFriendRequest(p.uid, p.username)}
                      className="p-2 rounded-lg bg-white/5 border border-white/10 text-[#F5F5F0] hover:border-[#D4AF37]"
                      title="Add Friend"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onInviteFriend(p.uid, selectedTimeControl)}
                      className="px-3 py-1.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
                    >
                      Challenge
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-6 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
            <h3 className="font-display text-xl font-semibold text-[#F5F5F0]">
              Friend Requests & Connections
            </h3>
            {friendRequests.length === 0 ? (
              <p className="text-xs text-[#9898A3]">
                No pending or active friend connections yet. Search for a player to connect.
              </p>
            ) : (
              <div className="divide-y divide-white/5">
                {friendRequests.map((fr) => {
                  const isIncoming = fr.toUid === user.uid;
                  const otherUid = isIncoming ? fr.fromUid : fr.toUid;
                  const otherName = isIncoming ? fr.fromUsername : fr.toUsername;
                  const isOnlineUser = onlinePlayers.some((op) => op.uid === otherUid);
                  return (
                    <div
                      key={fr.requestId}
                      className="py-3 flex items-center justify-between gap-3"
                    >
                      <div>
                        <p className="text-sm font-medium text-[#F5F5F0]">{otherName}</p>
                        <p className="text-xs text-[#9898A3]">
                          {fr.status === 'accepted'
                            ? isOnlineUser
                              ? 'Online'
                              : 'Offline'
                            : isIncoming
                              ? 'Incoming Request'
                              : 'Sent Request'}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        {fr.status === 'pending' && isIncoming && (
                          <>
                            <button
                              onClick={() => onRespondFriendRequest(fr.requestId, 'accepted')}
                              className="px-3 py-1 rounded bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
                            >
                              Accept
                            </button>
                            <button
                              onClick={() => onRespondFriendRequest(fr.requestId, 'declined')}
                              className="px-3 py-1 rounded bg-white/5 text-xs text-[#9898A3]"
                            >
                              Decline
                            </button>
                          </>
                        )}
                        {fr.status === 'accepted' && (
                          <>
                            <button
                              onClick={() => onInviteFriend(otherUid, selectedTimeControl)}
                              className="px-3 py-1.5 rounded bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
                            >
                              Invite
                            </button>
                            <button
                              onClick={() => setReportTarget({ uid: otherUid, username: otherName })}
                              className="p-1.5 rounded bg-white/5 text-[#9898A3] hover:text-red-400"
                              title="Block or Report"
                            >
                              <ShieldAlert className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ROLE SELECTION MODAL WHEN ENTERING A PRIVATE ROOM */}
      {joinRoleModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-xl bg-[#141418] border border-white/10 p-5 sm:p-6 space-y-5 max-h-[90dvh] overflow-y-auto">
            <div>
              <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">
                Enter Room {joinRoleModal.roomId}
              </h3>
              <p className="text-xs text-[#9898A3] mt-1">
                Select how you want to participate in this chess room.
              </p>
            </div>
            <div className="grid grid-cols-1 gap-3">
              <button
                onClick={() => {
                  onJoinRoom(joinRoleModal.roomId, joinRoleModal.password, 'player');
                  setJoinRoleModal(null);
                }}
                className="flex items-center justify-between p-4 rounded-xl bg-[#D4AF37] text-[#0A0A0C] font-semibold text-sm hover:bg-[#E5C158] transition-colors min-h-[52px]"
              >
                <span>1. PLAY AS PLAYER</span>
                <UserCheck className="w-5 h-5" />
              </button>
              <button
                onClick={() => {
                  onJoinRoom(joinRoleModal.roomId, joinRoleModal.password, 'spectator');
                  setJoinRoleModal(null);
                }}
                className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/15 text-[#F5F5F0] font-semibold text-sm hover:bg-white/10 transition-colors min-h-[52px]"
              >
                <span>2. JOIN AS SPECTATOR</span>
                <Eye className="w-5 h-5 text-[#D4AF37]" />
              </button>
            </div>
            <button
              onClick={() => setJoinRoleModal(null)}
              className="w-full py-2.5 text-xs text-[#9898A3] hover:text-white min-h-[44px]"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* PLAYER REPORT MODAL */}
      {reportTarget && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onSubmitReport(
                reportTarget.uid,
                reportTarget.username,
                reportReason,
                reportDetails
              );
              setReportTarget(null);
              setReportDetails('');
            }}
            className="w-full max-w-md rounded-xl bg-[#141418] border border-white/10 p-5 sm:p-6 space-y-4 max-h-[90dvh] overflow-y-auto"
          >
            <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
              Report Player: {reportTarget.username}
            </h3>
            <select
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
            >
              <option>Abusive chat or conduct</option>
              <option>Suspected engine / fair-play violation</option>
              <option>Intentional stalling</option>
            </select>
            <textarea
              rows={3}
              value={reportDetails}
              onChange={(e) => setReportDetails(e.target.value)}
              placeholder="Provide details for moderators..."
              className="w-full px-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setReportTarget(null)}
                className="px-4 py-2.5 rounded-lg text-xs text-[#9898A3] min-h-[44px]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2.5 rounded-lg bg-red-600 text-white text-xs font-semibold min-h-[44px]"
              >
                Submit Report
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
