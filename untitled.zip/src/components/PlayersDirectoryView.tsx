import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  Award,
  BarChart2,
  BookOpen,
  Search,
  ShieldAlert,
  ShieldBan,
  Swords,
  UserCheck,
  UserMinus,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { PROFILE_FRAMES, PROFILE_THEMES, getCountryFlag, getRankTitle } from '../data/themes';
import { FriendRequest, MatchRecord, TimeControlConfig, UserProfile } from '../types/chess';

interface PlayersDirectoryViewProps {
  currentUser: UserProfile;
  onlinePlayers: {
    uid: string;
    playerId: string;
    username: string;
    rating: number;
    country: string;
    avatar: string;
    inGame: boolean;
  }[];
  leaderboardPlayers: UserProfile[];
  recentMatches: MatchRecord[];
  friendRequests: FriendRequest[];
  onSendFriendRequest: (toUid: string, toUsername: string) => void;
  onFollowPlayer: (targetUid: string, follow: boolean) => void;
  onChallengePlayer: (targetUid: string, tc: TimeControlConfig) => void;
  onBlockPlayer: (targetUid: string, block: boolean) => void;
  onSubmitReport: (targetId: string, targetName: string, reason: string, details: string) => void;
  onReplayMatch: (match: MatchRecord) => void;
}

const DEFAULT_CHALLENGE_TC: TimeControlConfig = {
  id: '5+0',
  label: '5+0 Blitz',
  category: 'blitz',
  initialSeconds: 300,
  incrementSeconds: 0,
};

export const PlayersDirectoryView: React.FC<PlayersDirectoryViewProps> = ({
  currentUser,
  onlinePlayers,
  leaderboardPlayers,
  recentMatches,
  friendRequests,
  onSendFriendRequest,
  onFollowPlayer,
  onChallengePlayer,
  onBlockPlayer,
  onSubmitReport,
  onReplayMatch,
}) => {
  const [queryText, setQueryText] = useState('');
  const [exactMatch, setExactMatch] = useState(false);
  const [filterTab, setFilterTab] = useState<'all' | 'online' | 'friends' | 'following' | 'recent'>('all');
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);

  // Inspect Player Modal
  const [selectedProfile, setSelectedProfile] = useState<UserProfile | null>(null);
  const [selectedRecentMatches, setSelectedRecentMatches] = useState<MatchRecord[]>([]);
  const [selectedOnline, setSelectedOnline] = useState(false);
  const [compareModal, setCompareModal] = useState(false);
  const [reportText, setReportText] = useState('');
  const [showReportBox, setShowReportBox] = useState(false);

  const friendsUids = useMemo(
    () =>
      new Set(
        friendRequests
          .filter((r) => r.status === 'accepted')
          .map((r) => (r.fromUid === currentUser.uid ? r.toUid : r.fromUid))
      ),
    [friendRequests, currentUser.uid]
  );

  const onlineUidSet = useMemo(() => new Set(onlinePlayers.map((o) => o.uid)), [onlinePlayers]);
  const followingSet = useMemo(() => new Set(currentUser.following || []), [currentUser.following]);
  const blockedSet = useMemo(() => new Set(currentUser.blockedUids || []), [currentUser.blockedUids]);

  const recentOpponentUids = useMemo(() => {
    const s = new Set<string>();
    for (const m of recentMatches) {
      if (m.whiteId === currentUser.uid && !m.blackId.startsWith('ai_')) s.add(m.blackId);
      if (m.blackId === currentUser.uid && !m.whiteId.startsWith('ai_')) s.add(m.whiteId);
    }
    return s;
  }, [recentMatches, currentUser.uid]);

  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      fetch(
        `/api/users/search?q=${encodeURIComponent(queryText.trim())}&exact=${exactMatch}&viewerUid=${encodeURIComponent(currentUser.uid)}`
      )
        .then((r) => r.json())
        .then((data) => {
          if (Array.isArray(data.users)) {
            setSearchResults(data.users);
          }
        })
        .catch(() => {})
        .finally(() => setLoading(false));
    }, 200);
    return () => clearTimeout(timer);
  }, [queryText, exactMatch, currentUser.uid]);

  const combinedDirectory = useMemo(() => {
    const map = new Map<string, UserProfile>();
    for (const p of leaderboardPlayers) map.set(p.uid, p);
    for (const p of searchResults) map.set(p.uid, p);
    return Array.from(map.values())
      .filter((u) => {
        if (u.uid === currentUser.uid) return false;
        if (queryText.trim()) {
          const q = queryText.trim().toLowerCase();
          if (exactMatch) {
            if (u.username.toLowerCase() !== q && u.playerId.toLowerCase() !== q) return false;
          } else {
            if (
              !u.username.toLowerCase().includes(q) &&
              !u.playerId.toLowerCase().includes(q) &&
              !(u.displayName || '').toLowerCase().includes(q)
            ) {
              return false;
            }
          }
        }
        if (filterTab === 'online') return onlineUidSet.has(u.uid) || u.online;
        if (filterTab === 'friends') return friendsUids.has(u.uid);
        if (filterTab === 'following') return followingSet.has(u.uid);
        if (filterTab === 'recent') return recentOpponentUids.has(u.uid);
        return true;
      })
      .sort((a, b) => Number(onlineUidSet.has(b.uid)) - Number(onlineUidSet.has(a.uid)) || b.rating - a.rating);
  }, [
    leaderboardPlayers,
    searchResults,
    currentUser.uid,
    queryText,
    exactMatch,
    filterTab,
    onlineUidSet,
    friendsUids,
    followingSet,
    recentOpponentUids,
  ]);

  const openPlayerProfile = async (player: UserProfile) => {
    setSelectedProfile(player);
    setSelectedOnline(onlineUidSet.has(player.uid) || !!player.online);
    setShowReportBox(false);
    setCompareModal(false);
    try {
      const res = await fetch(
        `/api/users/${encodeURIComponent(player.uid)}?viewerUid=${encodeURIComponent(currentUser.uid)}`
      );
      if (res.ok) {
        const data = await res.json();
        if (data.user) setSelectedProfile(data.user);
        setSelectedRecentMatches(Array.isArray(data.recentMatches) ? data.recentMatches : []);
        setSelectedOnline(Boolean(data.online));
      }
    } catch {
      // keep preview data
    }
  };

  // Friend Activity Feed derived from recent matches & online friends
  const friendActivity = useMemo(() => {
    const items: { id: string; text: string; time: string }[] = [];
    for (const op of onlinePlayers) {
      if (friendsUids.has(op.uid)) {
        items.push({
          id: `act_on_${op.uid}`,
          text: `${op.username} (${op.rating}) is currently ${op.inGame ? 'playing a match' : 'online and ready for a challenge'}.`,
          time: 'Live Now',
        });
      }
    }
    for (const m of recentMatches) {
      if (friendsUids.has(m.whiteId) || friendsUids.has(m.blackId)) {
        items.push({
          id: `act_m_${m.matchId}`,
          text: `${m.whiteName} vs ${m.blackName} finished (${m.resultReason})`,
          time: new Date(m.createdAt).toLocaleDateString(),
        });
      }
    }
    return items.slice(0, 8);
  }, [onlinePlayers, friendsUids, recentMatches]);

  return (
    <div className="space-y-6">
      {/* Global Search Header */}
      <div className="rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#F5F5F0]">
              Global Player Search & Directory
            </h2>
            <p className="text-xs text-[#9898A3] mt-1">
              Search players worldwide by exact username or Player ID, inspect stats, compare Elo, follow, and send match challenges.
            </p>
          </div>
          <div className="text-xs font-mono text-[#D4AF37] tabular-nums">
            {onlinePlayers.length} Online Now · {friendsUids.size} Friends · {followingSet.size} Following
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          <div className="relative flex-1 min-w-0">
            <Search className="w-4 h-4 text-[#9898A3] absolute left-3 top-3.5 sm:top-3" />
            <input
              type="text"
              value={queryText}
              onChange={(e) => setQueryText(e.target.value)}
              placeholder="Search username or Player ID (CA-...)"
              className="w-full pl-9 pr-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-sm text-[#F5F5F0] focus:outline-none focus:border-[#D4AF37] min-h-[44px]"
            />
          </div>

          <label className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0] cursor-pointer min-h-[44px] shrink-0">
            <input
              type="checkbox"
              checked={exactMatch}
              onChange={(e) => setExactMatch(e.target.checked)}
              className="accent-[#D4AF37]"
            />
            Exact Match Only
          </label>
        </div>

        <div className="flex overflow-x-auto sm:flex-wrap gap-1.5 no-scrollbar pb-0.5">
          {[
            { id: 'all', label: 'All Players' },
            { id: 'online', label: `Online Now (${onlinePlayers.length})` },
            { id: 'friends', label: `Friends (${friendsUids.size})` },
            { id: 'following', label: `Following (${followingSet.size})` },
            { id: 'recent', label: 'Recently Played' },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setFilterTab(t.id as typeof filterTab)}
              className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 min-h-[40px] ${
                filterTab === t.id
                  ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                  : 'bg-[#0A0A0C] text-[#9898A3] hover:text-[#F5F5F0]'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Directory Results */}
        <div className="lg:col-span-8 space-y-3">
          {loading && combinedDirectory.length === 0 ? (
            <div className="rounded-xl bg-[#141418] border border-white/10 p-8 text-center text-xs text-[#9898A3]">
              Searching worldwide players...
            </div>
          ) : combinedDirectory.length === 0 ? (
            <div className="rounded-xl bg-[#141418] border border-white/10 p-8 text-center text-xs text-[#9898A3]">
              No matching players found. Try disabling Exact Match or clearing search filters.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {combinedDirectory.map((p) => {
                const isOnlineNow = onlineUidSet.has(p.uid) || !!p.online;
                const liveInfo = onlinePlayers.find((o) => o.uid === p.uid);
                const rank = getRankTitle(p.rating);
                const isFriend = friendsUids.has(p.uid);
                const isFollowing = followingSet.has(p.uid);
                const frameObj = PROFILE_FRAMES.find((f) => f.id === p.profileFrame) || PROFILE_FRAMES[0];

                return (
                  <div
                    key={p.uid}
                    className="rounded-xl bg-[#141418] border border-white/10 hover:border-[#D4AF37]/50 transition-colors p-4 space-y-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <button
                        onClick={() => openPlayerProfile(p)}
                        className="flex items-center gap-3 text-left min-w-0 flex-1"
                      >
                        <div className="relative shrink-0">
                          <img
                            src={p.avatar}
                            alt={p.username}
                            loading="lazy"
                            className={`w-12 h-12 rounded-lg object-cover ${frameObj.ringClass}`}
                          />
                          <span
                            className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-[#141418] ${
                              isOnlineNow ? 'bg-emerald-400' : 'bg-zinc-600'
                            }`}
                          />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-[#F5F5F0] truncate">
                            {p.username} <span title={p.country}>{getCountryFlag(p.country)}</span>
                          </p>
                          <p className="font-mono text-[11px] text-[#9898A3] truncate">{p.playerId}</p>
                          <p className="text-[11px] text-[#D4AF37] mt-0.5 truncate">
                            {p.rating} Elo · {rank.tier}
                            {liveInfo?.inGame ? ' · In Match' : isOnlineNow ? ' · Online' : ' · Offline'}
                          </p>
                        </div>
                      </button>

                      <button
                        onClick={() => openPlayerProfile(p)}
                        className="px-3 py-1.5 rounded bg-white/5 border border-white/10 text-[11px] text-[#F5F5F0] hover:border-[#D4AF37] min-h-[36px] shrink-0"
                      >
                        View
                      </button>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-[#9898A3] pt-1 border-t border-white/5">
                      <span>
                        {p.privacySections?.stats === false
                          ? 'Stats Private'
                          : `${p.wins}W · ${p.losses}L · ${p.draws}D`}
                      </span>
                      <div className="flex items-center gap-1.5">
                        {!isFriend && (
                          <button
                            onClick={() => onSendFriendRequest(p.uid, p.username)}
                            className="p-1.5 rounded bg-white/5 hover:bg-white/10 text-[#F5F5F0]"
                            title="Add Friend"
                          >
                            <UserPlus className="w-3.5 h-3.5 text-[#D4AF37]" />
                          </button>
                        )}
                        <button
                          onClick={() => onFollowPlayer(p.uid, !isFollowing)}
                          className={`px-2 py-1 rounded text-[11px] ${
                            isFollowing
                              ? 'bg-[#D4AF37]/20 text-[#D4AF37]'
                              : 'bg-white/5 text-[#9898A3] hover:text-white'
                          }`}
                        >
                          {isFollowing ? 'Following' : 'Follow'}
                        </button>
                        {isOnlineNow && (
                          <button
                            onClick={() => onChallengePlayer(p.uid, DEFAULT_CHALLENGE_TC)}
                            className="px-2.5 py-1 rounded bg-[#D4AF37] text-[#0A0A0C] font-semibold"
                          >
                            Challenge
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Friend Activity Feed */}
        <div className="lg:col-span-4 rounded-xl bg-[#141418] border border-white/10 p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#D4AF37]" />
            <h3 className="font-display text-xl font-bold text-[#F5F5F0]">Friend Activity Feed</h3>
          </div>
          {friendActivity.length === 0 ? (
            <p className="text-xs text-[#9898A3]">
              Add friends or follow players to track live availability and recent match completions here.
            </p>
          ) : (
            <div className="space-y-2.5">
              {friendActivity.map((act) => (
                <div
                  key={act.id}
                  className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs space-y-1"
                >
                  <p className="text-[#F5F5F0] leading-relaxed">{act.text}</p>
                  <p className="font-mono text-[10px] text-[#D4AF37]">{act.time}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Full Player Profile Modal */}
      {selectedProfile && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-2.5 sm:p-4">
          <div className="w-full max-w-3xl rounded-2xl bg-[#141418] border border-white/15 overflow-hidden shadow-2xl max-h-[92dvh] flex flex-col">
            {/* Banner Header */}
            <div
              className={`bg-gradient-to-r ${
                (PROFILE_THEMES.find((t) => t.id === selectedProfile.profileTheme) || PROFILE_THEMES[0])
                  .gradient
              } p-4 sm:p-6 border-b border-white/10 relative shrink-0`}
            >
              <button
                onClick={() => setSelectedProfile(null)}
                className="absolute top-3 right-3 sm:top-4 sm:right-4 p-2 rounded-lg bg-black/40 text-[#9898A3] hover:text-white min-w-[40px] min-h-[40px] flex items-center justify-center"
                aria-label="Close profile"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex flex-wrap items-center gap-3 sm:gap-4 pr-10">
                <img
                  src={selectedProfile.avatar}
                  alt={selectedProfile.username}
                  className={`w-14 h-14 sm:w-20 sm:h-20 rounded-xl object-cover shrink-0 ${
                    (PROFILE_FRAMES.find((f) => f.id === selectedProfile.profileFrame) || PROFILE_FRAMES[0])
                      .ringClass
                  }`}
                />
                <div className="space-y-1 min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#F5F5F0] truncate">
                      {selectedProfile.displayName || selectedProfile.username}
                    </h3>
                    <span className="text-lg">{getCountryFlag(selectedProfile.country)}</span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                        selectedOnline
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : 'bg-zinc-700/40 text-zinc-300'
                      }`}
                    >
                      {selectedOnline ? 'Online' : 'Offline'}
                    </span>
                  </div>
                  <p className="font-mono text-xs text-[#D4AF37] truncate">
                    @{selectedProfile.username} · {selectedProfile.playerId} · {selectedProfile.country}
                  </p>
                  {selectedProfile.bio && (
                    <p className="text-xs text-[#D4D4CE] pt-1 max-w-xl line-clamp-2 sm:line-clamp-none">{selectedProfile.bio}</p>
                  )}
                </div>
              </div>

              {/* Quick Actions */}
              <div className="flex flex-wrap items-center gap-2 mt-4">
                {!friendsUids.has(selectedProfile.uid) ? (
                  <button
                    onClick={() => onSendFriendRequest(selectedProfile.uid, selectedProfile.username)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
                  >
                    <UserPlus className="w-3.5 h-3.5" /> Add Friend
                  </button>
                ) : (
                  <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/15 text-emerald-300 text-xs font-semibold">
                    <UserCheck className="w-3.5 h-3.5" /> Friends
                  </span>
                )}

                <button
                  onClick={() =>
                    onFollowPlayer(selectedProfile.uid, !followingSet.has(selectedProfile.uid))
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0]"
                >
                  {followingSet.has(selectedProfile.uid) ? (
                    <>
                      <UserMinus className="w-3.5 h-3.5" /> Unfollow
                    </>
                  ) : (
                    <>
                      <Users className="w-3.5 h-3.5" /> Follow
                    </>
                  )}
                </button>

                {selectedOnline && (
                  <button
                    onClick={() => {
                      onChallengePlayer(selectedProfile.uid, DEFAULT_CHALLENGE_TC);
                      setSelectedProfile(null);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 text-[#0A0A0C] text-xs font-semibold"
                  >
                    <Swords className="w-3.5 h-3.5" /> Challenge Match
                  </button>
                )}

                <button
                  onClick={() => setCompareModal((c) => !c)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs text-[#D4AF37]"
                >
                  <BarChart2 className="w-3.5 h-3.5" /> {compareModal ? 'Hide Compare' : 'Compare Players'}
                </button>

                <button
                  onClick={() =>
                    onBlockPlayer(selectedProfile.uid, !blockedSet.has(selectedProfile.uid))
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs text-[#9898A3] hover:text-red-300"
                >
                  <ShieldBan className="w-3.5 h-3.5" />
                  {blockedSet.has(selectedProfile.uid) ? 'Unblock' : 'Block'}
                </button>

                <button
                  onClick={() => setShowReportBox((s) => !s)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300"
                >
                  <ShieldAlert className="w-3.5 h-3.5" /> Report
                </button>
              </div>
            </div>

            <div className="p-4 sm:p-6 space-y-5 flex-1 overflow-y-auto">
              {showReportBox && (
                <div className="p-3 rounded-lg bg-[#0A0A0C] border border-red-500/30 space-y-2">
                  <input
                    type="text"
                    value={reportText}
                    onChange={(e) => setReportText(e.target.value)}
                    placeholder="Reason for reporting this player..."
                    className="w-full px-3 py-2 rounded bg-[#141418] border border-white/10 text-xs text-[#F5F5F0]"
                  />
                  <button
                    onClick={() => {
                      onSubmitReport(
                        selectedProfile.uid,
                        selectedProfile.username,
                        'Player Profile Report',
                        reportText || 'Reported from Player Directory'
                      );
                      setShowReportBox(false);
                      setReportText('');
                    }}
                    className="px-3 py-2 rounded bg-red-600 text-white text-xs font-semibold min-h-[40px]"
                  >
                    Submit Report
                  </button>
                </div>
              )}

              {/* Side-by-Side Comparison */}
              {compareModal && (
                <div className="rounded-xl bg-[#0A0A0C] border border-[#D4AF37]/40 p-4 space-y-3">
                  <h4 className="font-display text-lg font-bold text-[#D4AF37]">
                    Head-to-Head Stat Comparison
                  </h4>
                  <div className="grid grid-cols-3 gap-2 text-xs text-center font-mono">
                    <div className="font-semibold text-[#F5F5F0] truncate">{currentUser.username}</div>
                    <div className="text-[#9898A3]">Metric</div>
                    <div className="font-semibold text-[#F5F5F0] truncate">{selectedProfile.username}</div>

                    <div className="text-[#D4AF37] font-bold">{currentUser.rating}</div>
                    <div className="text-[#9898A3]">Arena Elo</div>
                    <div className="text-[#D4AF37] font-bold">{selectedProfile.rating}</div>

                    <div>{currentUser.peakRating}</div>
                    <div className="text-[#9898A3]">Peak Elo</div>
                    <div>{selectedProfile.peakRating}</div>

                    <div>
                      {currentUser.wins + currentUser.losses + currentUser.draws > 0
                        ? `${Math.round(
                            (currentUser.wins /
                              (currentUser.wins + currentUser.losses + currentUser.draws)) *
                              100
                          )}%`
                        : '0%'}
                    </div>
                    <div className="text-[#9898A3]">Win Rate</div>
                    <div>
                      {selectedProfile.wins + selectedProfile.losses + selectedProfile.draws > 0
                        ? `${Math.round(
                            (selectedProfile.wins /
                              (selectedProfile.wins + selectedProfile.losses + selectedProfile.draws)) *
                              100
                          )}%`
                        : '0%'}
                    </div>

                    <div>{currentUser.bestWinStreak}</div>
                    <div className="text-[#9898A3]">Best Streak</div>
                    <div>{selectedProfile.bestWinStreak}</div>
                  </div>
                </div>
              )}

              {/* Stats Grid (Respects Privacy) */}
              {selectedProfile.privacySections?.stats !== false ? (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
                    <p className="text-[#9898A3]">Elo Rating</p>
                    <p className="font-mono text-lg font-bold text-[#D4AF37] mt-0.5">
                      {selectedProfile.rating}
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
                    <p className="text-[#9898A3]">Record</p>
                    <p className="font-mono text-sm font-bold text-[#F5F5F0] mt-1">
                      {selectedProfile.wins}W-{selectedProfile.losses}L-{selectedProfile.draws}D
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
                    <p className="text-[#9898A3]">Puzzle Rating</p>
                    <p className="font-mono text-lg font-bold text-[#F5F5F0] mt-0.5">
                      {selectedProfile.puzzleRating}
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
                    <p className="text-[#9898A3]">Level & XP</p>
                    <p className="font-mono text-sm font-bold text-[#F5F5F0] mt-1">
                      Lv.{selectedProfile.level} · {selectedProfile.xp} XP
                    </p>
                  </div>
                </div>
              ) : (
                <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/5 text-xs text-[#9898A3]">
                  Statistics are set to private by this player.
                </div>
              )}

              {/* Chess Bio, Experience, Learning Journey, Favorite Openings */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                {selectedProfile.privacySections?.learningJourney !== false && (
                  <div className="p-4 rounded-xl bg-[#0A0A0C] border border-white/10 space-y-1.5">
                    <p className="font-semibold text-[#D4AF37] flex items-center gap-1.5">
                      <BookOpen className="w-3.5 h-3.5" /> Learning Journey
                    </p>
                    <p className="text-[#9898A3]">
                      Experience: <span className="text-[#F5F5F0]">{selectedProfile.chessExperience || 'Club Player'}</span>
                    </p>
                    {selectedProfile.mentorName && (
                      <p className="text-[#9898A3]">
                        Mentor: <span className="text-[#F5F5F0]">{selectedProfile.mentorName}</span>
                      </p>
                    )}
                    {selectedProfile.learningJourney && (
                      <p className="text-[#D4D4CE] pt-1">{selectedProfile.learningJourney}</p>
                    )}
                  </div>
                )}

                {selectedProfile.privacySections?.favoriteOpenings !== false && (
                  <div className="p-4 rounded-xl bg-[#0A0A0C] border border-white/10 space-y-1.5">
                    <p className="font-semibold text-[#D4AF37] flex items-center gap-1.5">
                      <Award className="w-3.5 h-3.5" /> Repertoire & Inspiration
                    </p>
                    <p className="text-[#9898A3]">
                      Favorite Opening:{' '}
                      <span className="text-[#F5F5F0]">
                        {selectedProfile.favoriteOpening || 'Not specified'}
                      </span>
                    </p>
                    <p className="text-[#9898A3]">
                      Favorite Grandmaster:{' '}
                      <span className="text-[#F5F5F0]">
                        {selectedProfile.favoritePlayer || 'Not specified'}
                      </span>
                    </p>
                  </div>
                )}
              </div>

              {/* Match History (Respects Privacy) */}
              {selectedProfile.privacySections?.matchHistory !== false && (
                <div className="space-y-2">
                  <h4 className="font-display text-lg font-bold text-[#F5F5F0]">Recent Matches</h4>
                  {selectedRecentMatches.length === 0 ? (
                    <p className="text-xs text-[#9898A3]">No recent recorded games visible.</p>
                  ) : (
                    <div className="divide-y divide-white/5 rounded-xl bg-[#0A0A0C] border border-white/10 px-3">
                      {selectedRecentMatches.map((m) => (
                        <div key={m.matchId} className="py-2.5 flex items-center justify-between text-xs">
                          <div>
                            <p className="text-[#F5F5F0] font-medium">
                              {m.whiteName} vs {m.blackName}
                            </p>
                            <p className="text-[11px] text-[#9898A3]">
                              {m.mode.toUpperCase()} · {m.timeControl} · {m.resultReason}
                            </p>
                          </div>
                          <button
                            onClick={() => {
                              onReplayMatch(m);
                              setSelectedProfile(null);
                            }}
                            className="px-2.5 py-1 rounded bg-white/5 border border-white/10 text-[#D4AF37] hover:bg-white/10"
                          >
                            Analyze
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
