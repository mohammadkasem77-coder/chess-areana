import React, { useEffect, useMemo, useState } from 'react';
import { Chess } from 'chess.js';
import {
  Award,
  BookOpen,
  Check,
  Download,
  Lock,
  MessageSquare,
  Palette,
  Send,
  Settings,
  Share2,
  Shield,
  Sliders,
  TrendingUp,
  Upload,
  User as UserIcon,
  Users,
} from 'lucide-react';
import { ACHIEVEMENTS } from '../data/achievements';
import {
  AVATAR_OPTIONS,
  COUNTRIES,
  OPENING_PRESETS_LIST,
  PROFILE_FRAMES,
  PROFILE_THEMES,
  getCountryFlag,
  getRankTitle,
} from '../data/themes';
import { DEFAULT_LEARNING_VIDEOS } from '../data/trainingData';
import {
  claimUniqueUsernameDoc,
  sendDirectMessageDoc,
  subscribeDirectMessages,
} from '../services/firestoreService';
import {
  DirectMessage,
  FriendRequest,
  LearningVideo,
  MatchRecord,
  PrivacySections,
  ProfileFrameId,
  ProfileThemeId,
  UserPreferences,
  UserProfile,
} from '../types/chess';

interface ProfileSettingsViewProps {
  user: UserProfile;
  matches: MatchRecord[];
  friendRequests: FriendRequest[];
  onlinePlayers: {
    uid: string;
    playerId: string;
    username: string;
    rating: number;
    country: string;
    avatar: string;
    inGame: boolean;
  }[];
  learningVideos: LearningVideo[];
  preferences: UserPreferences;
  onUpdatePreferences: (prefs: UserPreferences) => void;
  onUpdateProfile: (updates: Partial<UserProfile>) => Promise<void>;
  onReplayMatch: (match: MatchRecord) => void;
  onOpenLearning: () => void;
  onOpenAdminPortal: () => void;
  onLogout: () => void;
}

export const ProfileSettingsView: React.FC<ProfileSettingsViewProps> = ({
  user,
  matches,
  friendRequests,
  onlinePlayers,
  learningVideos,
  preferences,
  onUpdatePreferences,
  onUpdateProfile,
  onReplayMatch,
  onOpenLearning,
  onOpenAdminPortal,
  onLogout,
}) => {
  const [tab, setTab] = useState<
    'overview' | 'stats' | 'history' | 'achievements' | 'learning' | 'friends' | 'openings' | 'settings'
  >('overview');

  // Profile Editor State
  const [displayName, setDisplayName] = useState(user.displayName || user.username);
  const [bio, setBio] = useState(user.bio || '');
  const [country, setCountry] = useState(user.country);
  const [avatar, setAvatar] = useState(user.avatar);
  const [chessExperience, setChessExperience] = useState(user.chessExperience || 'Club Player');
  const [learningJourney, setLearningJourney] = useState(user.learningJourney || '');
  const [mentorName, setMentorName] = useState(user.mentorName || '');
  const [favoritePlayer, setFavoritePlayer] = useState(user.favoritePlayer || '');
  const [favoriteOpening, setFavoriteOpening] = useState(user.favoriteOpening || 'Italian Game');
  const [profileTheme, setProfileTheme] = useState<ProfileThemeId>(user.profileTheme || 'obsidian_gold');
  const [profileFrame, setProfileFrame] = useState<ProfileFrameId>(user.profileFrame || 'gold_laurel');

  // Unique Username Change State
  const [newUsernameInput, setNewUsernameInput] = useState(user.username);
  const [usernameStatus, setUsernameStatus] = useState<string>('');
  const [usernameBusy, setUsernameBusy] = useState(false);

  // Privacy Sections & Controls
  const [privacyMsgs, setPrivacyMsgs] = useState(user.privacyAllowMessages);
  const [privacyInvites, setPrivacyInvites] = useState(user.privacyAllowInvites);
  const [privacySections, setPrivacySections] = useState<PrivacySections>(
    user.privacySections || {
      stats: true,
      matchHistory: true,
      achievements: true,
      learningJourney: true,
      friends: true,
      favoriteOpenings: true,
    }
  );

  // Upload Avatar state
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [avatarMsg, setAvatarMsg] = useState('');
  const [savedNotice, setSavedNotice] = useState(false);
  const [copiedShareId, setCopiedShareId] = useState<string | null>(null);

  // PGN Import Modal
  const [pgnImportText, setPgnImportText] = useState('');
  const [pgnImportError, setPgnImportError] = useState('');
  const [showPgnImport, setShowPgnImport] = useState(false);

  // Direct Messages state
  const [directMessages, setDirectMessages] = useState<DirectMessage[]>([]);
  const [selectedDmUid, setSelectedDmUid] = useState<string>('');
  const [dmText, setDmText] = useState('');

  useEffect(() => {
    setNewUsernameInput(user.username);
    setAvatar(user.avatar);
  }, [user.username, user.avatar]);

  useEffect(() => {
    if (user.isGuest) return;
    return subscribeDirectMessages(user.uid, (msgs) => {
      setDirectMessages(msgs);
    });
  }, [user.uid, user.isGuest]);

  const acceptedFriends = useMemo(() => {
    return friendRequests
      .filter((r) => r.status === 'accepted')
      .map((r) => ({
        uid: r.fromUid === user.uid ? r.toUid : r.fromUid,
        username: r.fromUid === user.uid ? r.toUsername : r.fromUsername,
      }));
  }, [friendRequests, user.uid]);

  useEffect(() => {
    if (!selectedDmUid && acceptedFriends.length > 0) {
      setSelectedDmUid(acceptedFriends[0].uid);
    }
  }, [acceptedFriends, selectedDmUid]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await onUpdateProfile({
      displayName: displayName.trim().slice(0, 40) || user.username,
      bio: bio.slice(0, 400),
      country,
      avatar,
      chessExperience,
      learningJourney: learningJourney.slice(0, 600),
      mentorName: mentorName.slice(0, 64),
      favoritePlayer: favoritePlayer.slice(0, 64),
      favoriteOpening: favoriteOpening.slice(0, 80),
      profileTheme,
      profileFrame,
      privacyAllowMessages: privacyMsgs,
      privacyAllowInvites: privacyInvites,
      privacySections,
    });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2000);
  };

  const handleUsernameChange = async () => {
    const clean = newUsernameInput.trim();
    if (!clean || clean === user.username) return;
    setUsernameBusy(true);
    setUsernameStatus('');
    try {
      const checkRes = await fetch(
        `/api/users/check-username?username=${encodeURIComponent(clean)}&uid=${encodeURIComponent(user.uid)}`
      );
      const checkData = await checkRes.json();
      if (!checkData.available) {
        setUsernameStatus(checkData.reason || 'That username is already taken.');
        return;
      }

      const res = await fetch('/api/users/change-username', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid: user.uid, newUsername: clean }),
      });
      const data = await res.json();
      if (!res.ok) {
        setUsernameStatus(data.error || 'Could not change username.');
        return;
      }

      if (!user.isGuest) {
        await claimUniqueUsernameDoc(user.uid, clean, user.username);
      }
      await onUpdateProfile({
        username: data.user?.username || clean,
        lastUsernameChangeAt: data.user?.lastUsernameChangeAt || new Date().toISOString(),
      });
      setUsernameStatus('Unique username updated across Chess Arena!');
    } catch {
      setUsernameStatus('Unable to verify username right now.');
    } finally {
      setUsernameBusy(false);
    }
  };

  const handleAvatarFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1.4 * 1024 * 1024) {
      setAvatarMsg('Please choose an image smaller than 1.4 MB.');
      return;
    }
    setUploadingAvatar(true);
    setAvatarMsg('');
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const dataUrl = String(reader.result || '');
        const res = await fetch('/api/users/upload-avatar', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ uid: user.uid, dataUrl }),
        });
        const data = await res.json();
        if (!res.ok) {
          setAvatarMsg(data.error || 'Upload failed.');
        } else if (data.avatarUrl) {
          setAvatar(data.avatarUrl);
          await onUpdateProfile({ avatar: data.avatarUrl });
          setAvatarMsg('Custom avatar uploaded and saved!');
        }
      } catch {
        setAvatarMsg('Upload failed — check connection.');
      } finally {
        setUploadingAvatar(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDownloadPgn = (m: MatchRecord) => {
    const blob = new Blob([m.pgn || ''], { type: 'application/x-chess-pgn' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${m.matchId}.pgn`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportPgnAnalyze = () => {
    setPgnImportError('');
    try {
      const c = new Chess();
      c.loadPgn(pgnImportText);
      const imported: MatchRecord = {
        matchId: `imp_${Date.now()}`,
        whiteId: user.uid,
        whiteName: user.username,
        whiteRating: user.rating,
        blackId: 'imported',
        blackName: 'Imported Game',
        blackRating: 1500,
        pgn: c.pgn(),
        fen: c.fen(),
        winner: 'draw',
        resultReason: 'Imported PGN',
        timeControl: 'Custom',
        mode: 'ai',
        durationSeconds: 0,
        moveCount: c.history().length,
        ratingDeltaWhite: 0,
        ratingDeltaBlack: 0,
        createdAt: new Date().toISOString(),
      };
      setShowPgnImport(false);
      onReplayMatch(imported);
    } catch {
      setPgnImportError('Invalid PGN text. Please check move notation and try again.');
    }
  };

  const handleSendDm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDmUid || !dmText.trim() || user.isGuest) return;
    await sendDirectMessageDoc(user.uid, selectedDmUid, dmText.trim());
    setDmText('');
  };

  // Compute Rating Progression points for pure SVG Chart
  const ratingSeries = useMemo(() => {
    let cur = user.rating;
    const myMatches = matches.filter((m) => m.whiteId === user.uid || m.blackId === user.uid).slice(0, 12);
    const points: number[] = [cur];
    for (const m of myMatches) {
      const delta = m.whiteId === user.uid ? m.ratingDeltaWhite : m.ratingDeltaBlack;
      cur = Math.max(400, cur - (delta || 0));
      points.unshift(cur);
    }
    return points.length >= 2 ? points : [Math.max(400, user.rating - 15), user.rating];
  }, [matches, user.uid, user.rating]);

  const activeTheme = PROFILE_THEMES.find((t) => t.id === profileTheme) || PROFILE_THEMES[0];
  const activeFrame = PROFILE_FRAMES.find((f) => f.id === profileFrame) || PROFILE_FRAMES[0];
  const rank = getRankTitle(user.rating);
  const videoCatalog = learningVideos.length > 0 ? learningVideos : DEFAULT_LEARNING_VIDEOS;
  const totalGames = user.wins + user.losses + user.draws;

  return (
    <div className="space-y-6">
      {/* Banner Header */}
      <div
        className={`rounded-2xl bg-gradient-to-r ${activeTheme.gradient} border border-white/10 p-4 sm:p-6 flex flex-wrap items-center justify-between gap-4 sm:gap-6`}
      >
        <div className="flex items-center gap-3 sm:gap-4 min-w-0">
          <img
            src={avatar}
            alt={user.username}
            className={`w-16 h-16 sm:w-20 sm:h-20 rounded-xl object-cover shrink-0 ${activeFrame.ringClass}`}
          />
          <div className="min-w-0 space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#F5F5F0] truncate">
                {displayName || user.username}
              </h2>
              <span className="text-lg">{getCountryFlag(country)}</span>
              <span className="px-2 py-0.5 rounded bg-[#D4AF37]/20 text-[#D4AF37] font-mono text-xs font-semibold">
                {user.rating} Elo · {rank.tier}
              </span>
            </div>
            <p className="font-mono text-xs text-[#D4AF37] truncate">
              @{user.username} · {user.playerId} · Level {user.level}
            </p>
            {bio && <p className="text-xs text-[#D4D4CE] max-w-xl break-words">{bio}</p>}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {!user.isGuest && (
            <button
              type="button"
              onClick={onLogout}
              className="px-3.5 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#9898A3] hover:text-white min-h-[40px]"
            >
              Sign Out
            </button>
          )}
        </div>
      </div>

      {/* 8-Section Sub-Navigation */}
      <div className="flex overflow-x-auto sm:flex-wrap items-center gap-1 p-1.5 rounded-xl bg-[#141418] border border-white/10 no-scrollbar">
        {[
          { id: 'overview', label: 'Overview & Edit', icon: UserIcon },
          { id: 'stats', label: 'Statistics & Elo Chart', icon: TrendingUp },
          { id: 'history', label: 'Match History & PGN', icon: BookOpen },
          { id: 'achievements', label: 'Achievements', icon: Award },
          { id: 'learning', label: 'Learning Journey', icon: Sliders },
          { id: 'friends', label: 'Friends & Messages', icon: Users },
          { id: 'openings', label: 'Favorite Openings', icon: Palette },
          { id: 'settings', label: 'Preferences & Security', icon: Settings },
        ].map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id as typeof tab)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 min-h-[40px] ${
                tab === t.id
                  ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                  : 'text-[#9898A3] hover:text-[#F5F5F0]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* SECTION 1: OVERVIEW & PROFILE CUSTOMIZATION */}
      {tab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6 items-start">
          <form
            onSubmit={handleSaveProfile}
            className="lg:col-span-7 rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-6 space-y-5"
          >
            <h3 className="font-display text-xl sm:text-2xl font-bold text-[#F5F5F0]">
              Profile Identity & Appearance
            </h3>

            {/* Avatar Upload + Preset Pickers */}
            <div className="space-y-3">
              <label className="block text-xs text-[#9898A3]">Avatar Picture (Preset or Custom Upload)</label>
              <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
                {AVATAR_OPTIONS.map((av) => (
                  <button
                    key={av.id}
                    type="button"
                    onClick={() => setAvatar(av.url)}
                    className={`rounded-xl overflow-hidden border-2 transition-all ${
                      avatar === av.url ? 'border-[#D4AF37] scale-105' : 'border-white/10 opacity-75'
                    }`}
                  >
                    <img src={av.url} alt={av.label} loading="lazy" className="w-12 h-12 sm:w-14 sm:h-14 object-cover" />
                  </button>
                ))}

                <label className="cursor-pointer flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-[#0A0A0C] border border-dashed border-[#D4AF37]/50 text-xs text-[#D4AF37] hover:bg-white/5 min-h-[44px]">
                  <Upload className="w-4 h-4" />
                  {uploadingAvatar ? 'Uploading...' : 'Upload Picture'}
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/gif"
                    onChange={handleAvatarFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
              {avatarMsg && <p className="text-xs text-emerald-400">{avatarMsg}</p>}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-[#9898A3] mb-1">Display Name</label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  maxLength={40}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                />
              </div>
              <div>
                <label className="block text-xs text-[#9898A3] mb-1">Country Flag</label>
                <select
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                >
                  {COUNTRIES.map((c) => (
                    <option key={c} value={c}>
                      {getCountryFlag(c)} {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs text-[#9898A3] mb-1">Chess Bio</label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                maxLength={400}
                placeholder="Share your chess ambitions, favorite tournaments, or playing style..."
                className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-[#9898A3] mb-1">Profile Banner Theme</label>
                <select
                  value={profileTheme}
                  onChange={(e) => setProfileTheme(e.target.value as ProfileThemeId)}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                >
                  {PROFILE_THEMES.map((pt) => (
                    <option key={pt.id} value={pt.id}>
                      {pt.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs text-[#9898A3] mb-1">Profile Avatar Frame</label>
                <select
                  value={profileFrame}
                  onChange={(e) => setProfileFrame(e.target.value as ProfileFrameId)}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                >
                  {PROFILE_FRAMES.map((pf) => (
                    <option key={pf.id} value={pf.id}>
                      {pf.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="submit"
                className="px-5 py-2.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold hover:bg-[#E5C158] min-h-[44px]"
              >
                Save Customization
              </button>
              {savedNotice && (
                <span className="text-xs text-emerald-400 flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> Saved
                </span>
              )}
            </div>
          </form>

          {/* Unique Username Change & Section Visibility */}
          <div className="lg:col-span-5 space-y-5 sm:space-y-6">
            <div className="rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-6 space-y-3">
              <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
                Unique Username Management
              </h3>
              <p className="text-xs text-[#9898A3]">
                Usernames are globally unique across Chess Arena. Changes enforce a 7-day cooldown.
              </p>
              <div className="flex flex-col xs:flex-row gap-2">
                <input
                  type="text"
                  value={newUsernameInput}
                  onChange={(e) => setNewUsernameInput(e.target.value)}
                  maxLength={32}
                  className="flex-1 min-w-0 px-3 py-2.5 sm:py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                />
                <button
                  type="button"
                  disabled={usernameBusy || newUsernameInput.trim() === user.username}
                  onClick={handleUsernameChange}
                  className="px-3.5 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold disabled:opacity-40 min-h-[42px] shrink-0"
                >
                  {usernameBusy ? 'Checking...' : 'Update'}
                </button>
              </div>
              {usernameStatus && <p className="text-xs text-[#D4AF37]">{usernameStatus}</p>}
            </div>

            <div className="rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-6 space-y-3">
              <h3 className="font-display text-xl font-bold text-[#F5F5F0] flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#D4AF37]" /> Section Privacy Visibility
              </h3>
              <p className="text-xs text-[#9898A3]">
                Choose which profile sections are publicly visible in Player Search.
              </p>
              <div className="space-y-2 text-xs">
                {[
                  { key: 'stats', label: 'Show Chess Statistics & Elo' },
                  { key: 'matchHistory', label: 'Show Recent Match History' },
                  { key: 'achievements', label: 'Show Unlocked Achievements' },
                  { key: 'learningJourney', label: 'Show Learning Journey & Mentor' },
                  { key: 'friends', label: 'Show Friends List' },
                  { key: 'favoriteOpenings', label: 'Show Favorite Openings & GM' },
                ].map((item) => (
                  <label key={item.key} className="flex items-center justify-between py-1 cursor-pointer">
                    <span className="text-[#D4D4CE]">{item.label}</span>
                    <input
                      type="checkbox"
                      checked={privacySections[item.key as keyof PrivacySections]}
                      onChange={(e) => {
                        const updated = {
                          ...privacySections,
                          [item.key]: e.target.checked,
                        };
                        setPrivacySections(updated);
                        onUpdateProfile({ privacySections: updated });
                      }}
                      className="accent-[#D4AF37]"
                    />
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: STATISTICS & SVG RATING CHART */}
      {tab === 'stats' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
            <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">Competitive Metrics</h3>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
                <p className="text-[#9898A3]">Current Rating</p>
                <p className="font-mono text-2xl font-bold text-[#D4AF37]">{user.rating}</p>
              </div>
              <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
                <p className="text-[#9898A3]">Peak Rating</p>
                <p className="font-mono text-2xl font-bold text-[#F5F5F0]">{user.peakRating}</p>
              </div>
              <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
                <p className="text-[#9898A3]">Total Matches</p>
                <p className="font-mono text-xl font-bold text-[#F5F5F0]">{totalGames}</p>
              </div>
              <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
                <p className="text-[#9898A3]">Win Rate</p>
                <p className="font-mono text-xl font-bold text-emerald-400">
                  {totalGames > 0 ? Math.round((user.wins / totalGames) * 100) : 0}%
                </p>
              </div>
              <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
                <p className="text-[#9898A3]">Best Win Streak</p>
                <p className="font-mono text-xl font-bold text-[#F5F5F0]">{user.bestWinStreak}</p>
              </div>
              <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10">
                <p className="text-[#9898A3]">Puzzles Solved</p>
                <p className="font-mono text-xl font-bold text-[#D4AF37]">{user.puzzlesSolved}</p>
              </div>
            </div>
          </div>

          {/* Pure SVG Rating Chart */}
          <div className="lg:col-span-7 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">
                Chess Rating Progression
              </h3>
              <span className="font-mono text-xs text-[#D4AF37]">
                Min {Math.min(...ratingSeries)} · Max {Math.max(...ratingSeries)}
              </span>
            </div>
            <div className="rounded-xl bg-[#0A0A0C] border border-white/10 p-4">
              {(() => {
                const minR = Math.min(...ratingSeries) - 20;
                const maxR = Math.max(...ratingSeries) + 20;
                const span = Math.max(40, maxR - minR);
                const w = 600;
                const h = 200;
                const coords = ratingSeries.map((val, idx) => {
                  const x = (idx / Math.max(1, ratingSeries.length - 1)) * (w - 40) + 20;
                  const y = h - 20 - ((val - minR) / span) * (h - 40);
                  return { x, y, val };
                });
                const poly = coords.map((c) => `${c.x},${c.y}`).join(' ');
                return (
                  <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-52 overflow-visible">
                    <line x1="20" y1="20" x2="580" y2="20" stroke="rgba(255,255,255,0.07)" />
                    <line x1="20" y1="100" x2="580" y2="100" stroke="rgba(255,255,255,0.07)" />
                    <line x1="20" y1="180" x2="580" y2="180" stroke="rgba(255,255,255,0.07)" />
                    <polyline
                      fill="none"
                      stroke="#D4AF37"
                      strokeWidth="3"
                      strokeLinejoin="round"
                      strokeLinecap="round"
                      points={poly}
                    />
                    {coords.map((c, idx) => (
                      <g key={idx}>
                        <circle cx={c.x} cy={c.y} r="4.5" fill="#D4AF37" />
                        <text
                          x={c.x}
                          y={c.y - 10}
                          textAnchor="middle"
                          fill="#9898A3"
                          fontSize="10"
                          fontFamily="monospace"
                        >
                          {c.val}
                        </text>
                      </g>
                    ))}
                  </svg>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: MATCH HISTORY + PGN EXPORT / IMPORT */}
      {tab === 'history' && (
        <div className="rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">
              Match Archive, PGN Import & Replays
            </h3>
            <button
              onClick={() => setShowPgnImport((s) => !s)}
              className="px-3.5 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
            >
              {showPgnImport ? 'Cancel Import' : 'Import & Analyze PGN'}
            </button>
          </div>

          {showPgnImport && (
            <div className="p-4 rounded-xl bg-[#0A0A0C] border border-[#D4AF37]/40 space-y-3">
              <textarea
                rows={4}
                value={pgnImportText}
                onChange={(e) => setPgnImportText(e.target.value)}
                placeholder="Paste PGN notation (e.g. 1. e4 e5 2. Nf3 Nc6...)"
                className="w-full px-3 py-2 rounded-lg bg-[#141418] border border-white/10 font-mono text-xs text-[#F5F5F0]"
              />
              {pgnImportError && <p className="text-xs text-red-400">{pgnImportError}</p>}
              <button
                onClick={handleImportPgnAnalyze}
                className="px-4 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
              >
                Open in AI Analyzer
              </button>
            </div>
          )}

          {matches.length === 0 ? (
            <p className="text-xs text-[#9898A3]">No archived matches yet.</p>
          ) : (
            <div className="divide-y divide-white/5">
              {matches.map((m) => (
                <div
                  key={m.matchId}
                  className="py-3.5 flex flex-wrap items-center justify-between gap-4 text-xs"
                >
                  <div>
                    <p className="text-sm font-semibold text-[#F5F5F0]">
                      {m.whiteName} ({m.whiteRating}) vs {m.blackName} ({m.blackRating})
                    </p>
                    <p className="text-[#9898A3] mt-0.5">
                      {m.mode.toUpperCase()} · {m.timeControl} · {m.moveCount} moves · {m.durationSeconds}s ·{' '}
                      {m.resultReason}
                      {m.isOffline ? ' · Offline Record' : ''}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onReplayMatch(m)}
                      className="px-3 py-1.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] font-semibold"
                    >
                      Replay & Analyze
                    </button>
                    <button
                      onClick={() => handleDownloadPgn(m)}
                      className="p-2 rounded-lg bg-white/5 border border-white/10 text-[#F5F5F0]"
                      title="Download PGN"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(
                          `CHESS ARENA Match: ${m.whiteName} vs ${m.blackName} (${m.resultReason})\n${m.pgn}`
                        );
                        setCopiedShareId(m.matchId);
                        setTimeout(() => setCopiedShareId(null), 1500);
                      }}
                      className="p-2 rounded-lg bg-white/5 border border-white/10 text-[#F5F5F0]"
                      title="Share Result"
                    >
                      {copiedShareId === m.matchId ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Share2 className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SECTION 4: ACHIEVEMENTS */}
      {tab === 'achievements' && (
        <div className="rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">
              Achievements & Honor Badges
            </h3>
            <span className="font-mono text-xs text-[#D4AF37]">
              {user.achievements.length}/{ACHIEVEMENTS.length} Unlocked
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {ACHIEVEMENTS.map((ach) => {
              const unlocked = user.achievements.includes(ach.id);
              return (
                <div
                  key={ach.id}
                  className={`p-3.5 rounded-lg border text-xs ${
                    unlocked
                      ? 'bg-[#D4AF37]/10 border-[#D4AF37]/40 text-[#F5F5F0]'
                      : 'bg-[#0A0A0C] border-white/5 text-[#9898A3] opacity-75'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold flex items-center gap-1.5">
                      <Award className={`w-3.5 h-3.5 ${unlocked ? 'text-[#D4AF37]' : 'text-[#9898A3]'}`} />
                      {ach.title}
                    </span>
                    <span className="font-mono text-[10px] text-[#D4AF37]">+{ach.pointsReward} pts</span>
                  </div>
                  <p className="mt-1.5 leading-relaxed">{ach.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SECTION 5: LEARNING JOURNEY */}
      {tab === 'learning' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
            <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">
              Chess Learning Journey & Mentorship
            </h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[#9898A3] mb-1">Chess Experience Level</label>
                <select
                  value={chessExperience}
                  onChange={(e) => setChessExperience(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                >
                  {['Complete Beginner', 'Casual Player', 'Club Player', 'Tournament Competitor', 'Titled Aspirant'].map(
                    (lv) => (
                      <option key={lv} value={lv}>
                        {lv}
                      </option>
                    )
                  )}
                </select>
              </div>
              <div>
                <label className="block text-[#9898A3] mb-1">Coach / Mentor Name</label>
                <input
                  type="text"
                  value={mentorName}
                  onChange={(e) => setMentorName(e.target.value)}
                  placeholder="Optional coach or sparring mentor"
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                />
              </div>
              <div>
                <label className="block text-[#9898A3] mb-1">Learning Goals & Notes</label>
                <textarea
                  rows={4}
                  value={learningJourney}
                  onChange={(e) => setLearningJourney(e.target.value)}
                  placeholder="What chess topics are you studying right now?"
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                />
              </div>
              <button
                onClick={() =>
                  onUpdateProfile({ chessExperience, mentorName, learningJourney })
                }
                className="px-4 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] font-semibold"
              >
                Save Learning Notes
              </button>
            </div>
          </div>

          <div className="lg:col-span-6 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">
                Video Curriculum Progress
              </h3>
              <button onClick={onOpenLearning} className="text-xs text-[#D4AF37] hover:underline">
                Open Learning Center
              </button>
            </div>
            <p className="text-xs text-[#9898A3]">
              Completed {(user.completedVideos || []).length} of {videoCatalog.length} video lessons ·{' '}
              {(user.favoriteVideos || []).length} favorites saved
            </p>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {videoCatalog.map((v) => {
                const done = (user.completedVideos || []).includes(v.videoId);
                return (
                  <div
                    key={v.videoId}
                    className="p-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 flex items-center justify-between text-xs"
                  >
                    <span className="truncate pr-2 text-[#F5F5F0]">{v.title}</span>
                    <span className={done ? 'text-emerald-400 font-semibold' : 'text-[#9898A3]'}>
                      {done ? 'Completed' : 'Pending'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 6: FRIENDS & REAL-TIME DIRECT MESSAGES */}
      {tab === 'friends' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6">
          <div className="lg:col-span-5 rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-5 space-y-3">
            <h3 className="font-display text-xl font-bold text-[#F5F5F0]">
              Friends ({acceptedFriends.length})
            </h3>
            {acceptedFriends.length === 0 ? (
              <p className="text-xs text-[#9898A3]">
                No friends connected yet. Use the Players Directory to add friends!
              </p>
            ) : (
              <div className="space-y-2">
                {acceptedFriends.map((f) => {
                  const isOn = onlinePlayers.some((o) => o.uid === f.uid);
                  return (
                    <button
                      key={f.uid}
                      onClick={() => setSelectedDmUid(f.uid)}
                      className={`w-full text-left p-3 rounded-lg border text-xs flex items-center justify-between min-h-[44px] ${
                        selectedDmUid === f.uid
                          ? 'bg-[#D4AF37]/15 border-[#D4AF37]'
                          : 'bg-[#0A0A0C] border-white/10'
                      }`}
                    >
                      <span className="font-semibold text-[#F5F5F0] truncate pr-2">{f.username}</span>
                      <span className={`shrink-0 ${isOn ? 'text-emerald-400' : 'text-[#9898A3]'}`}>
                        {isOn ? 'Online' : 'Offline'}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="lg:col-span-7 rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-5 flex flex-col h-[360px] sm:h-[420px]">
            <div className="flex items-center gap-2 pb-3 border-b border-white/10">
              <MessageSquare className="w-4 h-4 text-[#D4AF37] shrink-0" />
              <h3 className="font-display text-lg sm:text-xl font-bold text-[#F5F5F0] truncate">
                Direct Messages{' '}
                {selectedDmUid
                  ? `with ${acceptedFriends.find((f) => f.uid === selectedDmUid)?.username || 'Friend'}`
                  : ''}
              </h3>
            </div>

            {user.isGuest ? (
              <div className="flex-1 flex items-center justify-center text-xs text-[#9898A3] text-center px-4">
                Sign in with an account to use private friend messaging.
              </div>
            ) : !selectedDmUid ? (
              <div className="flex-1 flex items-center justify-center text-xs text-[#9898A3] text-center px-4">
                Select a friend to start chatting.
              </div>
            ) : (
              <>
                <div className="flex-1 overflow-y-auto py-3 space-y-2">
                  {directMessages
                    .filter(
                      (m) =>
                        (m.senderUid === user.uid && m.recipientUid === selectedDmUid) ||
                        (m.senderUid === selectedDmUid && m.recipientUid === user.uid)
                    )
                    .map((m) => {
                      const mine = m.senderUid === user.uid;
                      return (
                        <div
                          key={m.messageId}
                          className={`max-w-[85%] sm:max-w-[80%] rounded-lg px-3 py-2 text-xs break-words ${
                            mine
                              ? 'ml-auto bg-[#D4AF37] text-[#0A0A0C]'
                              : 'bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]'
                          }`}
                        >
                          <p>{m.text}</p>
                        </div>
                      );
                    })}
                </div>
                <form onSubmit={handleSendDm} className="pt-2 border-t border-white/10 flex gap-2">
                  <input
                    type="text"
                    value={dmText}
                    onChange={(e) => setDmText(e.target.value)}
                    placeholder="Write a direct message..."
                    className="flex-1 min-w-0 px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] font-semibold min-w-[44px] min-h-[42px] flex items-center justify-center shrink-0"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      )}

      {/* SECTION 7: FAVORITE OPENINGS & INSPIRATION */}
      {tab === 'openings' && (
        <div className="rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4 max-w-2xl">
          <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">
            Favorite Opening Repertoire & Grandmaster Inspiration
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-[#9898A3] mb-1">Favorite Chess Opening</label>
              <select
                value={favoriteOpening}
                onChange={(e) => setFavoriteOpening(e.target.value)}
                className="w-full px-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
              >
                {OPENING_PRESETS_LIST.map((op) => (
                  <option key={op} value={op}>
                    {op}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[#9898A3] mb-1">Favorite Grandmaster / Idol</label>
              <input
                type="text"
                value={favoritePlayer}
                onChange={(e) => setFavoritePlayer(e.target.value)}
                placeholder="e.g. Magnus Carlsen, Mikhail Tal, Judit Polgar"
                className="w-full px-3 py-2.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => onUpdateProfile({ favoriteOpening, favoritePlayer })}
              className="px-4 py-2.5 sm:py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold min-h-[42px]"
            >
              Save Favorites
            </button>
            <button
              onClick={onOpenLearning}
              className="px-4 py-2.5 sm:py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] min-h-[42px]"
            >
              Practice in Opening Trainer
            </button>
          </div>
        </div>
      )}

      {/* SECTION 8: SETTINGS, PREFERENCES, PRIVACY & HIDDEN STAFF ADMIN ACCESS */}
      {tab === 'settings' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-5">
            <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">
              Appearance, Audio & Accessibility
            </h3>

            <div className="space-y-3 text-xs">
              <label className="flex items-center justify-between py-2 border-b border-white/5 cursor-pointer">
                <div>
                  <p className="font-semibold text-[#F5F5F0]">Color Theme Mode</p>
                  <p className="text-[#9898A3]">Switch between Obsidian Dark and Daylight Light mode</p>
                </div>
                <select
                  value={preferences.colorMode}
                  onChange={(e) =>
                    onUpdatePreferences({
                      ...preferences,
                      colorMode: e.target.value as 'dark' | 'light',
                    })
                  }
                  className="px-3 py-1.5 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                >
                  <option value="dark">Obsidian Dark</option>
                  <option value="light">Daylight Light</option>
                </select>
              </label>

              {[
                {
                  key: 'soundEnabled',
                  title: 'Board & Clock Sound Effects',
                  desc: 'Play crisp acoustic feedback on moves, captures, checks, and game endings',
                },
                {
                  key: 'notifyInvites',
                  title: 'Match Invitation Alerts',
                  desc: 'Show toast & notification badges when friends challenge you',
                },
                {
                  key: 'notifyMessages',
                  title: 'Chat Message Alerts',
                  desc: 'Show unread message badges during live matches',
                },
                {
                  key: 'notifyTournaments',
                  title: 'Tournament Bracket Alerts',
                  desc: 'Receive updates when pairings go live',
                },
                {
                  key: 'highContrast',
                  title: 'High Contrast Borders',
                  desc: 'Enhance panel outlines and focus rings for higher readability',
                },
                {
                  key: 'largeText',
                  title: 'Larger Typography',
                  desc: 'Increase base font scaling across menus and controls',
                },
                {
                  key: 'reducedMotion',
                  title: 'Reduced Motion',
                  desc: 'Disable UI animations and micro-transitions',
                },
              ].map((pref) => (
                <label
                  key={pref.key}
                  className="flex items-center justify-between py-2 border-b border-white/5 cursor-pointer"
                >
                  <div className="pr-4">
                    <p className="font-semibold text-[#F5F5F0]">{pref.title}</p>
                    <p className="text-[#9898A3]">{pref.desc}</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={Boolean(preferences[pref.key as keyof UserPreferences])}
                    onChange={(e) =>
                      onUpdatePreferences({
                        ...preferences,
                        [pref.key]: e.target.checked,
                      })
                    }
                    className="accent-[#D4AF37]"
                  />
                </label>
              ))}
            </div>
          </div>

          <div className="lg:col-span-6 space-y-6">
            <div className="rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
              <h3 className="font-display text-2xl font-bold text-[#F5F5F0] flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#D4AF37]" /> Communication Privacy
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[#9898A3] mb-1">Direct Messages</label>
                  <select
                    value={privacyMsgs}
                    onChange={(e) => {
                      const val = e.target.value as 'everyone' | 'friends' | 'none';
                      setPrivacyMsgs(val);
                      onUpdateProfile({ privacyAllowMessages: val });
                    }}
                    className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                  >
                    <option value="everyone">Everyone</option>
                    <option value="friends">Friends Only</option>
                    <option value="none">Disabled</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[#9898A3] mb-1">Match Invitations</label>
                  <select
                    value={privacyInvites}
                    onChange={(e) => {
                      const val = e.target.value as 'everyone' | 'friends' | 'none';
                      setPrivacyInvites(val);
                      onUpdateProfile({ privacyAllowInvites: val });
                    }}
                    className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                  >
                    <option value="everyone">Everyone</option>
                    <option value="friends">Friends Only</option>
                    <option value="none">Disabled</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Subtle Hidden Staff / Admin Entry (NO credentials stored client-side) */}
            <div className="rounded-xl bg-[#141418] border border-white/10 p-6 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-[#9898A3]" />
                  <h4 className="text-sm font-semibold text-[#F5F5F0]">Platform Administration</h4>
                </div>
                <span className="font-mono text-[10px] text-[#9898A3]">Authorized Staff Only</span>
              </div>
              <p className="text-xs text-[#9898A3]">
                Access the protected moderation and visual studio console. Server verification is required on entry.
              </p>
              <button
                type="button"
                onClick={onOpenAdminPortal}
                className="px-4 py-2.5 sm:py-2 rounded-lg bg-white/5 border border-white/15 text-xs text-[#F5F5F0] hover:border-[#D4AF37] min-h-[42px]"
              >
                Open Staff Console
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
