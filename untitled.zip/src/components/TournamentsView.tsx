import React, { useState } from 'react';
import { Calendar, Play, Plus, Trophy, Users } from 'lucide-react';
import { TIME_CONTROLS } from '../data/themes';
import { Tournament, UserProfile } from '../types/chess';

interface TournamentsViewProps {
  user: UserProfile;
  tournaments: Tournament[];
  onCreateTournament: (payload: {
    title: string;
    format: 'knockout' | 'round_robin';
    visibility: 'public' | 'private';
    timeControl: string;
    maxPlayers: number;
  }) => void;
  onJoinTournament: (tournamentId: string) => void;
  onStartTournament: (tournamentId: string) => void;
  onLaunchTournamentMatch: (tournamentId: string, matchId: string) => void;
}

export const TournamentsView: React.FC<TournamentsViewProps> = ({
  user,
  tournaments,
  onCreateTournament,
  onJoinTournament,
  onStartTournament,
  onLaunchTournamentMatch,
}) => {
  const [title, setTitle] = useState('');
  const [format, setFormat] = useState<'knockout' | 'round_robin'>('knockout');
  const [visibility, setVisibility] = useState<'public' | 'private'>('public');
  const [timeControl, setTimeControl] = useState('5+0');
  const [maxPlayers, setMaxPlayers] = useState(8);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const selectedTournament =
    tournaments.find((t) => t.tournamentId === selectedId) || tournaments[0] || null;

  return (
    <div className="space-y-5 sm:space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6 items-start">
        {/* Create Tournament Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (title.trim().length < 3) return;
            onCreateTournament({
              title: title.trim(),
              format,
              visibility,
              timeControl,
              maxPlayers,
            });
            setTitle('');
          }}
          className="lg:col-span-4 rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-6 space-y-4"
        >
          <h2 className="font-display text-xl sm:text-2xl font-bold text-[#F5F5F0]">
            Create Tournament
          </h2>
          <div>
            <label className="block text-xs text-[#9898A3] mb-1">Tournament Name</label>
            <input
              type="text"
              required
              minLength={3}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Obsidian Blitz Open"
              className="w-full px-3 py-2.5 sm:py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
            />
          </div>

          <div className="grid grid-cols-1 xs:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-[#9898A3] mb-1">Format</label>
              <select
                value={format}
                onChange={(e) => setFormat(e.target.value as 'knockout' | 'round_robin')}
                className="w-full px-3 py-2.5 sm:py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              >
                <option value="knockout">Knockout Bracket</option>
                <option value="round_robin">Round-Robin</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-[#9898A3] mb-1">Visibility</label>
              <select
                value={visibility}
                onChange={(e) => setVisibility(e.target.value as 'public' | 'private')}
                className="w-full px-3 py-2.5 sm:py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              >
                <option value="public">Public</option>
                <option value="private">Private</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 xs:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-[#9898A3] mb-1">Time Control</label>
              <select
                value={timeControl}
                onChange={(e) => setTimeControl(e.target.value)}
                className="w-full px-3 py-2.5 sm:py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              >
                {TIME_CONTROLS.map((tc) => (
                  <option key={tc.id} value={tc.id}>
                    {tc.label} ({tc.category})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-[#9898A3] mb-1">Max Players</label>
              <input
                type="number"
                min={2}
                max={32}
                value={maxPlayers}
                onChange={(e) => setMaxPlayers(Number(e.target.value))}
                className="w-full px-3 py-2.5 sm:py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold hover:bg-[#E5C158] min-h-[44px]"
          >
            <Plus className="w-4 h-4" />
            Launch Tournament
          </button>
        </form>

        {/* Tournaments List & Live Bracket */}
        <div className="lg:col-span-8 space-y-5 sm:space-y-6">
          <div className="rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-6 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-display text-xl sm:text-2xl font-bold text-[#F5F5F0]">
                Active & Upcoming Tournaments
              </h2>
              <span className="font-mono text-xs text-[#9898A3] tabular-nums shrink-0">
                {tournaments.length} Events
              </span>
            </div>

            {tournaments.length === 0 ? (
              <p className="text-xs text-[#9898A3] py-4">
                No tournaments created yet. Create a Knockout or Round-Robin event to begin.
              </p>
            ) : (
              <div className="divide-y divide-white/5">
                {tournaments.map((t) => {
                  const isJoined = t.participants.includes(user.uid);
                  const isCreator = t.createdBy === user.uid;
                  return (
                    <div
                      key={t.tournamentId}
                      onClick={() => setSelectedId(t.tournamentId)}
                      className="py-3.5 first:pt-0 last:pb-0 flex flex-wrap items-center justify-between gap-3 cursor-pointer hover:bg-white/[0.02] px-2 rounded-lg transition-colors"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-semibold text-[#F5F5F0] truncate">{t.title}</p>
                        <p className="text-xs text-[#9898A3] mt-0.5">
                          {t.format === 'round_robin' ? 'Round-Robin' : 'Knockout'} · {t.timeControl} ·{' '}
                          {t.participants.length}/{t.maxPlayers} Players · {t.status.toUpperCase()}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {t.status === 'registration' && !isJoined && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onJoinTournament(t.tournamentId);
                            }}
                            className="px-3.5 py-2 sm:py-1.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold min-h-[40px] sm:min-h-0"
                          >
                            Register
                          </button>
                        )}
                        {t.status === 'registration' && isCreator && t.participants.length >= 2 && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onStartTournament(t.tournamentId);
                            }}
                            className="px-3.5 py-2 sm:py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-semibold min-h-[40px] sm:min-h-0"
                          >
                            Start Bracket
                          </button>
                        )}
                        {isJoined && (
                          <span className="text-xs text-[#D4AF37] font-medium">Registered</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {selectedTournament && (
            <div className="rounded-xl bg-[#141418] border border-white/10 p-4 sm:p-6 space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="font-display text-xl sm:text-2xl font-bold text-[#F5F5F0] break-words">
                    {selectedTournament.title} — Brackets & Standings
                  </h3>
                  <p className="text-xs text-[#9898A3] truncate">
                    Hosted by {selectedTournament.creatorName} · {selectedTournament.tournamentId}
                  </p>
                </div>
                <div className="flex items-center gap-4 text-xs text-[#9898A3]">
                  <span className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5 text-[#D4AF37]" />
                    {selectedTournament.participants.length} Players
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
                    {selectedTournament.status}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Match Schedule / Brackets */}
                <div className="space-y-3">
                  <h4 className="text-xs font-semibold text-[#9898A3]">Match Schedule</h4>
                  {selectedTournament.matches.length === 0 ? (
                    <p className="text-xs text-[#9898A3]">
                      Pairings will be generated once the organizer starts the tournament.
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {selectedTournament.matches.map((m) => {
                        const isMyMatch = m.whiteUid === user.uid || m.blackUid === user.uid;
                        return (
                          <div
                            key={m.id}
                            className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs"
                          >
                            <div className="min-w-0">
                              <p className="text-[#F5F5F0] font-medium truncate">
                                {m.whiteName} vs {m.blackName}
                              </p>
                              <p className="text-[#9898A3] mt-0.5">
                                Round {m.round} · {m.status.toUpperCase()}
                              </p>
                            </div>
                            {isMyMatch && m.status !== 'completed' && m.blackUid && (
                              <button
                                onClick={() =>
                                  onLaunchTournamentMatch(selectedTournament.tournamentId, m.id)
                                }
                                className="flex items-center gap-1 px-3 py-2 sm:py-1.5 rounded bg-[#D4AF37] text-[#0A0A0C] font-semibold min-h-[40px] sm:min-h-0"
                              >
                                <Play className="w-3 h-3" />
                                Play
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Standings */}
                <div className="space-y-3">
                  <h4 className="text-xs font-semibold text-[#9898A3] flex items-center gap-1.5">
                    <Trophy className="w-3.5 h-3.5 text-[#D4AF37]" />
                    Live Standings
                  </h4>
                  <div className="divide-y divide-white/5 text-xs">
                    {[...selectedTournament.standings]
                      .sort((a, b) => b.points - a.points || b.rating - a.rating)
                      .map((st, idx) => (
                        <div key={st.uid} className="py-2 flex items-center justify-between gap-2">
                          <span className="text-[#F5F5F0] min-w-0 truncate">
                            <span className="font-mono text-[#D4AF37] mr-2">#{idx + 1}</span>
                            {st.username}
                          </span>
                          <span className="font-mono text-[#9898A3] tabular-nums shrink-0">
                            {st.points} pts ({st.wins}W-{st.draws}D-{st.losses}L)
                          </span>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
