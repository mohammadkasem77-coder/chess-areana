import React, { useMemo, useState } from 'react';
import { Chess, Square } from 'chess.js';
import {
  BookOpen,
  CheckCircle2,
  Compass,
  Download,
  Heart,
  Lightbulb,
  Play,
  RotateCcw,
  Sparkles,
  Target,
  Video,
  WifiOff,
  Zap,
} from 'lucide-react';
import {
  CHESS_FUNDAMENTALS,
  CHESS_LESSONS,
  CHESS_PUZZLES,
  CHESS_STRATEGIES,
  DAILY_CHESS_TIPS,
  ENDGAME_DRILLS,
  OPENING_LESSONS,
  VIDEO_CATEGORIES,
} from '../data/trainingData';
import { analyzeGameMoves, findBestMove } from '../engine/chessAI';
import {
  BoardThemeId,
  LearningVideo,
  MatchRecord,
  MoveAnalysisItem,
  PieceStyleId,
  PuzzleItem,
  UserProfile,
  VideoCategory,
} from '../types/chess';
import {
  downloadOfflinePuzzlePack,
  getDownloadedPuzzlePack,
  getSolvedPuzzleIds,
  isPuzzlePackDownloaded,
  recordOfflinePuzzleSolved,
} from '../utils/offlineStorage';
import { soundFX } from '../utils/soundFX';
import { ChessBoard } from './ChessBoard';

interface TrainingCenterViewProps {
  user: UserProfile;
  boardTheme: BoardThemeId;
  pieceStyle: PieceStyleId;
  isOnline: boolean;
  dailyTip?: string;
  learningVideos: LearningVideo[];
  replayMatch?: MatchRecord | null;
  onPuzzleSolved: (puzzle: PuzzleItem) => void;
  onOpeningCompleted: () => void;
  onToggleVideoComplete: (videoId: string) => void;
  onToggleVideoFavorite: (videoId: string) => void;
}

export const TrainingCenterView: React.FC<TrainingCenterViewProps> = ({
  user,
  boardTheme,
  pieceStyle,
  isOnline,
  dailyTip,
  learningVideos,
  replayMatch,
  onPuzzleSolved,
  onOpeningCompleted,
  onToggleVideoComplete,
  onToggleVideoFavorite,
}) => {
  const [section, setSection] = useState<
    'fundamentals' | 'strategies' | 'videos' | 'puzzles' | 'openings' | 'endgames' | 'analyzer'
  >(replayMatch ? 'analyzer' : 'videos');

  // Fundamentals state
  const [selectedFundamentalIdx, setSelectedFundamentalIdx] = useState(0);
  const activeFundamental = CHESS_FUNDAMENTALS[selectedFundamentalIdx];

  // Video Learning state
  const [selectedCategory, setSelectedCategory] = useState<VideoCategory | 'All'>('All');
  const [activeVideo, setActiveVideo] = useState<LearningVideo | null>(learningVideos[0] || null);

  const filteredVideos = useMemo(() => {
    if (selectedCategory === 'All') return learningVideos;
    return learningVideos.filter((v) => v.category === selectedCategory);
  }, [learningVideos, selectedCategory]);

  // Puzzles state
  const [packDownloaded, setPackDownloaded] = useState(isPuzzlePackDownloaded());
  const [puzzles, setPuzzles] = useState<PuzzleItem[]>(() => getDownloadedPuzzlePack());
  const [puzzleFilter, setPuzzleFilter] = useState<string>('all');
  const [puzzleIndex, setPuzzleIndex] = useState(0);
  const [solvedIds, setSolvedIds] = useState<string[]>(() => getSolvedPuzzleIds());

  const filteredPuzzles = useMemo(() => {
    if (puzzleFilter === 'all') return puzzles;
    if (puzzleFilter === 'daily') return puzzles.filter((p) => p.isDaily);
    return puzzles.filter((p) => p.theme === puzzleFilter);
  }, [puzzles, puzzleFilter]);

  const activePuzzle =
    filteredPuzzles[puzzleIndex % Math.max(1, filteredPuzzles.length)] || CHESS_PUZZLES[0];
  const [puzzleStep, setPuzzleStep] = useState(0);
  const [puzzleFen, setPuzzleFen] = useState(activePuzzle.fen);
  const [puzzleFeedback, setPuzzleFeedback] = useState<string>('');

  // Opening Trainer state
  const [selectedOpeningIdx, setSelectedOpeningIdx] = useState(0);
  const activeOpening = OPENING_LESSONS[selectedOpeningIdx];
  const [openingStep, setOpeningStep] = useState(0);
  const [openingFen, setOpeningFen] = useState(new Chess().fen());
  const [openingFeedback, setOpeningFeedback] = useState('');

  // Endgame Drills state
  const [selectedEndgameIdx, setSelectedEndgameIdx] = useState(0);
  const activeEndgame = ENDGAME_DRILLS[selectedEndgameIdx];
  const [endgameChess, setEndgameChess] = useState(() => new Chess(activeEndgame.fen));
  const [endgameStatus, setEndgameStatus] = useState('');

  // Analyzer state
  const [pgnInput, setPgnInput] = useState(
    replayMatch?.pgn ||
      '1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7 6. Re1 b5 7. Bb3 d6 8. c3 O-O'
  );
  const [analysisItems, setAnalysisItems] = useState<MoveAnalysisItem[]>(() =>
    replayMatch?.pgn ? analyzeGameMoves(replayMatch.pgn) : []
  );
  const [replayPly, setReplayPly] = useState(0);
  const [aiExplain, setAiExplain] = useState('');
  const [aiExplainLoading, setAiExplainLoading] = useState(false);

  const completedVideoSet = new Set(user.completedVideos || []);
  const favoriteVideoSet = new Set(user.favoriteVideos || []);
  const tipText =
    dailyTip ||
    DAILY_CHESS_TIPS[new Date().getDate() % DAILY_CHESS_TIPS.length];

  const loadPuzzle = (pz: PuzzleItem) => {
    setPuzzleFen(pz.fen);
    setPuzzleStep(0);
    setPuzzleFeedback('');
  };

  const handlePuzzleMove = (from: string, to: string, promotion?: string) => {
    const uci = `${from}${to}`;
    const expected = activePuzzle.solution[puzzleStep];
    if (!expected) return;

    if (uci === expected.slice(0, 4)) {
      const c = new Chess(puzzleFen);
      c.move({
        from: from as Square,
        to: to as Square,
        promotion: (promotion as 'q' | 'r' | 'b' | 'n') || 'q',
      });
      soundFX.playMove();
      const nextStep = puzzleStep + 1;

      if (nextStep >= activePuzzle.solution.length) {
        setPuzzleFen(c.fen());
        setPuzzleStep(nextStep);
        setPuzzleFeedback(`Solved! ${activePuzzle.explanation}`);
        soundFX.playGameEnd();
        const nextSolved = recordOfflinePuzzleSolved(activePuzzle.id);
        setSolvedIds(nextSolved);
        onPuzzleSolved(activePuzzle);
      } else {
        const replyUci = activePuzzle.solution[nextStep];
        const rFrom = replyUci.slice(0, 2) as Square;
        const rTo = replyUci.slice(2, 4) as Square;
        c.move({ from: rFrom, to: rTo, promotion: 'q' });
        setPuzzleFen(c.fen());
        setPuzzleStep(nextStep + 1);
        setPuzzleFeedback('Strong move! Find the follow-up.');
      }
    } else {
      setPuzzleFeedback('Not the sharpest move. Look for checks, captures, or threats.');
    }
  };

  const handleOpeningMove = (from: string, to: string, promotion?: string) => {
    const expectedSan = activeOpening.moves[openingStep];
    if (!expectedSan) return;
    const c = new Chess(openingFen);
    try {
      const res = c.move({
        from: from as Square,
        to: to as Square,
        promotion: (promotion as 'q' | 'r' | 'b' | 'n') || 'q',
      });
      if (!res) return;
      if (res.san === expectedSan) {
        soundFX.playMove();
        let nextStep = openingStep + 1;
        if (nextStep < activeOpening.moves.length) {
          c.move(activeOpening.moves[nextStep]);
          nextStep++;
        }
        setOpeningFen(c.fen());
        setOpeningStep(nextStep);
        if (nextStep >= activeOpening.moves.length) {
          setOpeningFeedback(`Repertoire complete: ${activeOpening.name}!`);
          soundFX.playGameEnd();
          onOpeningCompleted();
        } else {
          setOpeningFeedback(`Correct (${res.san}). Continue the line.`);
        }
      } else {
        setOpeningFeedback(`Try the main theory move instead of ${res.san}.`);
      }
    } catch {
      // ignore
    }
  };

  const handleEndgameMove = (from: string, to: string, promotion?: string) => {
    const copy = new Chess(endgameChess.fen());
    try {
      const res = copy.move({
        from: from as Square,
        to: to as Square,
        promotion: (promotion as 'q' | 'r' | 'b' | 'n') || 'q',
      });
      if (!res) return;
      soundFX.playMove();
      setEndgameChess(copy);
      if (copy.isCheckmate()) {
        setEndgameStatus('Checkmate! Endgame mastered.');
        soundFX.playGameEnd();
        return;
      }
      if (copy.isDraw()) {
        setEndgameStatus('Draw reached. Reset to practice winning technique.');
        return;
      }
      setTimeout(() => {
        const { move } = findBestMove(copy.fen(), 'hard', 'endgame');
        if (move) {
          copy.move(move);
          setEndgameChess(new Chess(copy.fen()));
          if (copy.isCheckmate()) setEndgameStatus('Opponent checkmated.');
        }
      }, 300);
    } catch {
      // ignore
    }
  };

  const handleRunLocalAnalyzer = () => {
    const items = analyzeGameMoves(pgnInput);
    setAnalysisItems(items);
    setReplayPly(items.length);
  };

  const handleRunGeminiExplain = async () => {
    if (!isOnline) {
      setAiExplain('Connect to the internet for Gemini AI natural-language coaching.');
      return;
    }
    setAiExplainLoading(true);
    try {
      const summary = analysisItems
        .filter((m) => m.classification === 'Mistake' || m.classification === 'Blunder')
        .map((m) => `Ply ${m.ply} (${m.moveSan}): ${m.classification}, best ${m.bestMoveSan}`)
        .join('\n');
      const res = await fetch('/api/ai/analyze-match', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pgn: pgnInput,
          playerColor: 'w',
          mistakesSummary: summary,
        }),
      });
      const data = await res.json();
      setAiExplain(data.analysis || data.error || 'Analysis complete.');
    } catch {
      setAiExplain('Unable to reach AI analyzer.');
    } finally {
      setAiExplainLoading(false);
    }
  };

  const analyzerBoardFen = useMemo(() => {
    const sim = new Chess();
    try {
      sim.loadPgn(pgnInput);
      const hist = sim.history();
      const target = new Chess();
      for (let i = 0; i < Math.min(replayPly, hist.length); i++) {
        target.move(hist[i]);
      }
      return target.fen();
    } catch {
      return new Chess().fen();
    }
  }, [pgnInput, replayPly]);

  const videoEmbedUrl = useMemo(() => {
    if (!activeVideo) return '';
    if (activeVideo.isPlaylist && activeVideo.playlistId) {
      return `https://www.youtube-nocookie.com/embed/videoseries?list=${encodeURIComponent(activeVideo.playlistId)}`;
    }
    if (activeVideo.youtubeId) {
      return `https://www.youtube-nocookie.com/embed/${encodeURIComponent(activeVideo.youtubeId)}`;
    }
    return '';
  }, [activeVideo]);

  return (
    <div className="space-y-6">
      {/* Daily Chess Tip Banner */}
      <div className="rounded-xl bg-[#141418] border border-[#D4AF37]/30 px-5 py-3.5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <Lightbulb className="w-4 h-4 text-[#D4AF37] shrink-0" />
          <p className="text-xs sm:text-sm text-[#F5F5F0]">
            <span className="font-semibold text-[#D4AF37] mr-2">Daily Chess Tip:</span>
            {tipText}
          </p>
        </div>
        <span className="font-mono text-xs text-[#9898A3]">
          {completedVideoSet.size} Videos Completed · {solvedIds.length} Puzzles Solved
        </span>
      </div>

      {/* Learning Navigation Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 rounded-xl bg-[#141418] border border-white/10 p-3">
        <div className="flex overflow-x-auto lg:flex-wrap items-center gap-1 p-1 bg-[#0A0A0C] rounded-lg no-scrollbar">
          {[
            { id: 'videos', label: 'Video Learning', icon: Video },
            { id: 'fundamentals', label: 'Chess Fundamentals', icon: BookOpen },
            { id: 'strategies', label: 'Chess Strategies', icon: Compass },
            { id: 'puzzles', label: 'Tactical Puzzles', icon: Target },
            { id: 'openings', label: 'Opening Trainer', icon: Zap },
            { id: 'endgames', label: 'Endgame Drills', icon: CheckCircle2 },
            { id: 'analyzer', label: 'AI Analyzer', icon: Sparkles },
          ].map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setSection(t.id as typeof section)}
                className={`flex items-center gap-2 px-3 py-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 min-h-[40px] ${
                  section === t.id
                    ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                    : 'text-[#9898A3] hover:text-[#F5F5F0]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {t.label}
              </button>
            );
          })}
        </div>

        <button
          onClick={() => {
            const downloaded = downloadOfflinePuzzlePack();
            setPuzzles(downloaded);
            setPackDownloaded(true);
          }}
          className="flex items-center justify-center gap-2 px-3.5 py-2 rounded-lg border border-white/10 text-xs text-[#F5F5F0] hover:border-[#D4AF37] shrink-0 min-h-[42px]"
        >
          <Download className="w-3.5 h-3.5 text-[#D4AF37]" />
          {packDownloaded ? 'Offline Puzzles Cached' : 'Download Puzzles Offline'}
        </button>
      </div>

      {/* SECTION A: VIDEO LEARNING */}
      {section === 'videos' && (
        <div className="space-y-6">
          <div className="flex overflow-x-auto sm:flex-wrap gap-1.5 no-scrollbar pb-0.5">
            <button
              onClick={() => setSelectedCategory('All')}
              className={`px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 min-h-[40px] ${
                selectedCategory === 'All'
                  ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                  : 'bg-[#141418] border border-white/10 text-[#9898A3] hover:text-white'
              }`}
            >
              All Categories ({learningVideos.length})
            </button>
            {VIDEO_CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 min-h-[40px] ${
                  selectedCategory === cat
                    ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                    : 'bg-[#141418] border border-white/10 text-[#9898A3] hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Embedded Responsive Video Player */}
            <div className="lg:col-span-7 rounded-xl bg-[#141418] border border-white/10 overflow-hidden">
              {!isOnline ? (
                <div className="aspect-video flex flex-col items-center justify-center p-6 text-center bg-[#0A0A0C] space-y-2">
                  <WifiOff className="w-8 h-8 text-[#D4AF37]" />
                  <p className="text-sm font-semibold text-[#F5F5F0]">Offline Mode Active</p>
                  <p className="text-xs text-[#9898A3] max-w-md">
                    YouTube video streaming requires an active internet connection. Chess Fundamentals, Strategies, and cached Tactical Puzzles remain fully available offline.
                  </p>
                </div>
              ) : activeVideo && videoEmbedUrl ? (
                <div className="aspect-video bg-black">
                  <iframe
                    src={videoEmbedUrl}
                    title={activeVideo.title}
                    loading="lazy"
                    className="w-full h-full"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>
              ) : (
                <div className="aspect-video flex items-center justify-center text-xs text-[#9898A3]">
                  Select a video lesson from the library to begin watching.
                </div>
              )}

              {activeVideo && (
                <div className="p-5 space-y-3">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <span className="text-[11px] font-mono text-[#D4AF37]">
                        {activeVideo.category} · {activeVideo.author}
                      </span>
                      <h3 className="font-display text-2xl font-bold text-[#F5F5F0] mt-0.5">
                        {activeVideo.title}
                      </h3>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onToggleVideoFavorite(activeVideo.videoId)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs ${
                          favoriteVideoSet.has(activeVideo.videoId)
                            ? 'bg-pink-500/20 border-pink-400/40 text-pink-300'
                            : 'bg-white/5 border-white/10 text-[#9898A3]'
                        }`}
                      >
                        <Heart className="w-3.5 h-3.5" />
                        {favoriteVideoSet.has(activeVideo.videoId) ? 'Favorited' : 'Favorite'}
                      </button>
                      <button
                        onClick={() => onToggleVideoComplete(activeVideo.videoId)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold ${
                          completedVideoSet.has(activeVideo.videoId)
                            ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-300'
                            : 'bg-[#D4AF37] text-[#0A0A0C] border-transparent'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {completedVideoSet.has(activeVideo.videoId) ? 'Completed' : 'Mark Completed'}
                      </button>
                    </div>
                  </div>
                  <p className="text-xs text-[#9898A3] leading-relaxed">{activeVideo.description}</p>
                </div>
              )}
            </div>

            {/* Video Lesson Playlist */}
            <div className="lg:col-span-5 rounded-xl bg-[#141418] border border-white/10 p-4 space-y-3 max-h-[600px] overflow-y-auto">
              <h4 className="font-display text-xl font-bold text-[#F5F5F0]">
                Video Curriculum ({filteredVideos.length})
              </h4>
              {filteredVideos.map((v) => {
                const isSelected = activeVideo?.videoId === v.videoId;
                const done = completedVideoSet.has(v.videoId);
                const fav = favoriteVideoSet.has(v.videoId);
                const thumb = v.youtubeId
                  ? `https://i.ytimg.com/vi/${v.youtubeId}/hqdefault.jpg`
                  : undefined;

                return (
                  <button
                    key={v.videoId}
                    onClick={() => setActiveVideo(v)}
                    className={`w-full text-left p-2.5 rounded-xl border transition-colors flex gap-3 ${
                      isSelected
                        ? 'bg-[#D4AF37]/15 border-[#D4AF37]'
                        : 'bg-[#0A0A0C] border-white/10 hover:border-white/25'
                    }`}
                  >
                    <div className="w-28 h-16 rounded-lg overflow-hidden bg-zinc-900 shrink-0 relative">
                      {thumb ? (
                        <img
                          src={thumb}
                          alt={v.title}
                          referrerPolicy="no-referrer"
                          loading="lazy"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-[#D4AF37]">
                          <Play className="w-5 h-5" />
                        </div>
                      )}
                      {done && (
                        <span className="absolute top-1 right-1 bg-emerald-500 text-black rounded-full p-0.5">
                          <CheckCircle2 className="w-3 h-3" />
                        </span>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-[#F5F5F0] line-clamp-2">{v.title}</p>
                      <p className="text-[11px] text-[#9898A3] mt-1">
                        {v.author} · {v.category} {fav ? ' · ♥' : ''}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SECTION B: CHESS FUNDAMENTALS */}
      {section === 'fundamentals' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-6">
            <ChessBoard
              fen={activeFundamental.fen}
              orientation="w"
              boardTheme={boardTheme}
              pieceStyle={pieceStyle}
              interactive={false}
              onMove={() => {}}
            />
          </div>
          <div className="lg:col-span-6 space-y-4">
            <div className="flex flex-wrap gap-2">
              {CHESS_FUNDAMENTALS.map((f, idx) => (
                <button
                  key={f.id}
                  onClick={() => setSelectedFundamentalIdx(idx)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium ${
                    selectedFundamentalIdx === idx
                      ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                      : 'bg-[#141418] border border-white/10 text-[#9898A3]'
                  }`}
                >
                  {f.badge}
                </button>
              ))}
            </div>

            <div className="rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
              <span className="font-mono text-xs text-[#D4AF37] uppercase">{activeFundamental.badge}</span>
              <h3 className="font-display text-3xl font-bold text-[#F5F5F0]">
                {activeFundamental.title}
              </h3>
              <p className="text-xs sm:text-sm text-[#D4D4CE] leading-relaxed">
                {activeFundamental.summary}
              </p>
              <ul className="space-y-2.5 text-xs text-[#D4D4CE] list-disc pl-4">
                {activeFundamental.rules.map((r, i) => (
                  <li key={i} className="leading-relaxed">
                    {r}
                  </li>
                ))}
              </ul>
            </div>

            <div className="grid grid-cols-1 gap-3">
              {CHESS_LESSONS.map((ls) => (
                <div
                  key={ls.id}
                  className="rounded-xl bg-[#141418] border border-white/10 p-4 space-y-2"
                >
                  <div className="flex items-center justify-between text-xs text-[#D4AF37]">
                    <span>{ls.level}</span>
                    <span>{ls.duration}</span>
                  </div>
                  <h4 className="font-display text-lg font-bold text-[#F5F5F0]">{ls.title}</h4>
                  <p className="text-xs text-[#9898A3]">{ls.summary}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SECTION C: CHESS STRATEGIES */}
      {section === 'strategies' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {CHESS_STRATEGIES.map((st) => (
            <div
              key={st.id}
              className="rounded-xl bg-[#141418] border border-white/10 p-6 space-y-3"
            >
              <span className="font-mono text-[11px] text-[#D4AF37] uppercase">{st.phase}</span>
              <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">{st.title}</h3>
              <p className="text-xs text-[#D4D4CE] leading-relaxed">{st.headline}</p>
              <ul className="space-y-2 text-xs text-[#9898A3] list-disc pl-4 pt-1">
                {st.principles.map((p, idx) => (
                  <li key={idx} className="leading-relaxed">
                    {p}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}

      {/* SECTION D: PUZZLES */}
      {section === 'puzzles' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7">
            <ChessBoard
              fen={puzzleFen}
              orientation={activePuzzle.fen.includes(' b ') ? 'b' : 'w'}
              boardTheme={boardTheme}
              pieceStyle={pieceStyle}
              onMove={handlePuzzleMove}
            />
          </div>

          <div className="lg:col-span-5 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-[#D4AF37] font-mono">
                  Rating {activePuzzle.rating} · {activePuzzle.theme.replace('_', ' ').toUpperCase()}
                </p>
                <h3 className="font-display text-2xl font-bold text-[#F5F5F0] mt-0.5">
                  {activePuzzle.title}
                </h3>
              </div>
              <span className="font-mono text-xs text-[#9898A3] tabular-nums">
                {solvedIds.length}/{puzzles.length} Solved
              </span>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {[
                { id: 'all', label: 'All' },
                { id: 'daily', label: 'Daily' },
                { id: 'mate_in_1', label: 'Mate in 1' },
                { id: 'mate_in_2', label: 'Mate in 2' },
                { id: 'fork', label: 'Forks' },
                { id: 'endgame', label: 'Endgame' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => {
                    setPuzzleFilter(f.id);
                    setPuzzleIndex(0);
                    const nextList =
                      f.id === 'all'
                        ? puzzles
                        : f.id === 'daily'
                          ? puzzles.filter((p) => p.isDaily)
                          : puzzles.filter((p) => p.theme === f.id);
                    if (nextList[0]) loadPuzzle(nextList[0]);
                  }}
                  className={`px-2.5 py-1 rounded text-xs ${
                    puzzleFilter === f.id
                      ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                      : 'bg-[#0A0A0C] text-[#9898A3] hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <p className="text-xs text-[#9898A3]">
              Turn to move: <strong className="text-[#F5F5F0]">{puzzleFen.includes(' b ') ? 'Black' : 'White'}</strong>
            </p>

            {puzzleFeedback && (
              <div className="p-3 rounded-lg bg-[#0A0A0C] border border-[#D4AF37]/30 text-xs text-[#F5F5F0] leading-relaxed">
                {puzzleFeedback}
              </div>
            )}

            <div className="flex flex-wrap gap-2 pt-2">
              <button
                onClick={() => {
                  const nextUci = activePuzzle.solution[puzzleStep];
                  if (nextUci) {
                    setPuzzleFeedback(`Hint: Move from ${nextUci.slice(0, 2)} to ${nextUci.slice(2, 4)}.`);
                  }
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0]"
              >
                <Lightbulb className="w-3.5 h-3.5 text-[#D4AF37]" />
                Hint
              </button>
              <button
                onClick={() => loadPuzzle(activePuzzle)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0]"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset
              </button>
              <button
                onClick={() => {
                  const nextIdx = (puzzleIndex + 1) % filteredPuzzles.length;
                  setPuzzleIndex(nextIdx);
                  loadPuzzle(filteredPuzzles[nextIdx]);
                }}
                className="flex-1 px-4 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold hover:bg-[#E5C158]"
              >
                Next Puzzle
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SECTION E: OPENING TRAINER */}
      {section === 'openings' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7">
            <ChessBoard
              fen={openingFen}
              orientation={activeOpening.side}
              boardTheme={boardTheme}
              pieceStyle={pieceStyle}
              onMove={handleOpeningMove}
            />
          </div>
          <div className="lg:col-span-5 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
            <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">Opening Trainer</h3>
            <select
              value={selectedOpeningIdx}
              onChange={(e) => {
                const idx = Number(e.target.value);
                setSelectedOpeningIdx(idx);
                const chosen = OPENING_LESSONS[idx];
                const fresh = new Chess();
                let step = 0;
                if (chosen.side === 'b') {
                  fresh.move(chosen.moves[0]);
                  step = 1;
                }
                setOpeningFen(fresh.fen());
                setOpeningStep(step);
                setOpeningFeedback('');
              }}
              className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-xs text-[#F5F5F0]"
            >
              {OPENING_LESSONS.map((op, i) => (
                <option key={op.id} value={i}>
                  {op.eco} · {op.name} ({op.difficulty})
                </option>
              ))}
            </select>

            <p className="text-xs text-[#9898A3] leading-relaxed">{activeOpening.description}</p>
            <ul className="space-y-1.5 text-xs text-[#D4D4CE] list-disc pl-4">
              {activeOpening.keyIdeas.map((idea, idx) => (
                <li key={idx}>{idea}</li>
              ))}
            </ul>

            <div className="p-3 rounded-lg bg-[#0A0A0C] border border-white/10 font-mono text-xs text-[#D4AF37]">
              Next Expected Move:{' '}
              {activeOpening.moves[openingStep] ? activeOpening.moves[openingStep] : 'Completed'}
            </div>

            {openingFeedback && <p className="text-xs text-emerald-400">{openingFeedback}</p>}

            <button
              onClick={() => {
                const fresh = new Chess();
                let step = 0;
                if (activeOpening.side === 'b') {
                  fresh.move(activeOpening.moves[0]);
                  step = 1;
                }
                setOpeningFen(fresh.fen());
                setOpeningStep(step);
                setOpeningFeedback('');
              }}
              className="w-full py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-[#F5F5F0] hover:border-[#D4AF37]"
            >
              Restart Repertoire Line
            </button>
          </div>
        </div>
      )}

      {/* SECTION F: ENDGAME DRILLS */}
      {section === 'endgames' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7">
            <ChessBoard
              fen={endgameChess.fen()}
              orientation="w"
              boardTheme={boardTheme}
              pieceStyle={pieceStyle}
              onMove={handleEndgameMove}
            />
          </div>
          <div className="lg:col-span-5 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
            <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">Endgame Training</h3>
            <div className="space-y-2">
              {ENDGAME_DRILLS.map((eg, i) => (
                <button
                  key={eg.id}
                  onClick={() => {
                    setSelectedEndgameIdx(i);
                    setEndgameChess(new Chess(eg.fen));
                    setEndgameStatus('');
                  }}
                  className={`w-full text-left p-3 rounded-lg border text-xs transition-colors ${
                    selectedEndgameIdx === i
                      ? 'bg-[#D4AF37]/15 border-[#D4AF37] text-[#F5F5F0]'
                      : 'bg-[#0A0A0C] border-white/10 text-[#9898A3]'
                  }`}
                >
                  <p className="font-semibold text-[#F5F5F0]">{eg.title}</p>
                  <p className="mt-1">
                    {eg.difficulty} · {eg.goal}
                  </p>
                </button>
              ))}
            </div>
            {endgameStatus && (
              <div className="p-3 rounded-lg bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-xs text-[#D4AF37]">
                {endgameStatus}
              </div>
            )}
            <button
              onClick={() => {
                setEndgameChess(new Chess(activeEndgame.fen));
                setEndgameStatus('');
              }}
              className="w-full py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
            >
              Reset Position
            </button>
          </div>
        </div>
      )}

      {/* SECTION G: POST-MATCH PGN & AI MISTAKE ANALYZER */}
      {section === 'analyzer' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-6 space-y-3">
            <ChessBoard
              fen={analyzerBoardFen}
              orientation="w"
              boardTheme={boardTheme}
              pieceStyle={pieceStyle}
              interactive={false}
              onMove={() => {}}
            />
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-[#141418] border border-white/10 p-2.5 sm:p-3">
              <button
                onClick={() => setReplayPly(0)}
                className="px-3 py-2 rounded bg-white/5 text-xs text-[#F5F5F0] min-h-[40px]"
              >
                Start
              </button>
              <button
                onClick={() => setReplayPly((p) => Math.max(0, p - 1))}
                className="px-3 py-2 rounded bg-white/5 text-xs text-[#F5F5F0] min-h-[40px]"
              >
                Prev
              </button>
              <span className="font-mono text-xs text-[#D4AF37] tabular-nums">
                Ply {replayPly} / {analysisItems.length}
              </span>
              <button
                onClick={() => setReplayPly((p) => Math.min(analysisItems.length, p + 1))}
                className="px-3 py-2 rounded bg-white/5 text-xs text-[#F5F5F0] min-h-[40px]"
              >
                Next
              </button>
              <button
                onClick={() => setReplayPly(analysisItems.length)}
                className="px-3 py-2 rounded bg-white/5 text-xs text-[#F5F5F0] min-h-[40px]"
              >
                End
              </button>
            </div>
          </div>

          <div className="lg:col-span-6 rounded-xl bg-[#141418] border border-white/10 p-6 space-y-4">
            <h3 className="font-display text-2xl font-bold text-[#F5F5F0]">
              Mistake & Blunder Analyzer
            </h3>
            <textarea
              rows={3}
              value={pgnInput}
              onChange={(e) => setPgnInput(e.target.value)}
              placeholder="Paste PGN notation..."
              className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 font-mono text-xs text-[#F5F5F0]"
            />
            <div className="flex flex-wrap gap-2">
              <button
                onClick={handleRunLocalAnalyzer}
                className="px-4 py-2 rounded-lg bg-[#D4AF37] text-[#0A0A0C] text-xs font-semibold"
              >
                Run Engine Evaluation
              </button>
              <button
                onClick={handleRunGeminiExplain}
                disabled={aiExplainLoading}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-white/5 border border-[#D4AF37]/40 text-xs text-[#D4AF37]"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {aiExplainLoading ? 'Explaining...' : 'Explain Mistakes with AI'}
              </button>
            </div>

            {aiExplain && (
              <div className="p-3 rounded-lg bg-[#0A0A0C] border border-[#D4AF37]/30 text-xs text-[#D4D4CE] whitespace-pre-wrap leading-relaxed">
                {aiExplain}
              </div>
            )}

            <div className="max-h-60 overflow-y-auto divide-y divide-white/5 text-xs">
              {analysisItems.map((item) => (
                <button
                  key={item.ply}
                  onClick={() => setReplayPly(item.ply)}
                  className="w-full py-2 flex items-center justify-between text-left hover:bg-white/5 px-2 rounded"
                >
                  <span className="font-mono text-[#F5F5F0]">
                    {Math.ceil(item.ply / 2)}.{item.color === 'b' ? '..' : ''} {item.moveSan}
                  </span>
                  <span
                    className={
                      item.classification === 'Blunder'
                        ? 'text-red-400 font-semibold'
                        : item.classification === 'Mistake'
                          ? 'text-amber-400 font-semibold'
                          : item.classification === 'Inaccuracy'
                            ? 'text-yellow-300'
                            : 'text-emerald-400'
                    }
                  >
                    {item.classification}
                    {item.bestMoveSan && item.bestMoveSan !== item.moveSan
                      ? ` · Best: ${item.bestMoveSan}`
                      : ''}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
