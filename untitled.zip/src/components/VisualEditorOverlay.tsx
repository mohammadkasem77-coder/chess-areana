import React, { useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  CheckCircle2,
  Eye,
  MousePointerClick,
  Redo2,
  Save,
  Undo2,
  X,
} from 'lucide-react';
import { AppUiConfig } from '../types/chess';

export type VisualEditTarget =
  | 'siteTitle'
  | 'bannerText'
  | 'heroHeadline'
  | 'heroSubtitle'
  | 'heroImageUrl'
  | 'dailyTip'
  | 'colors'
  | 'buttons'
  | 'sections'
  | 'navigation'
  | null;

interface VisualEditorOverlayProps {
  draftConfig: AppUiConfig;
  selectedTarget: VisualEditTarget;
  onSelectTarget: (target: VisualEditTarget) => void;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onChangeDraft: (next: AppUiConfig) => void;
  onSaveDraft: () => void;
  onPublishLive: () => void;
  onCancel: () => void;
  savingStatus: string;
}

const DEFAULT_SECTIONS = ['banner', 'hero', 'metrics', 'dailyTip', 'mainGrid'];

export const VisualEditorOverlay: React.FC<VisualEditorOverlayProps> = ({
  draftConfig,
  selectedTarget,
  onSelectTarget,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onChangeDraft,
  onSaveDraft,
  onPublishLive,
  onCancel,
  savingStatus,
}) => {
  const [livePreviewOnly, setLivePreviewOnly] = useState(false);

  const sectionOrder = draftConfig.sectionOrder?.length
    ? draftConfig.sectionOrder
    : DEFAULT_SECTIONS;

  const moveSection = (idx: number, dir: -1 | 1) => {
    const targetIdx = idx + dir;
    if (targetIdx < 0 || targetIdx >= sectionOrder.length) return;
    const copy = [...sectionOrder];
    const [item] = copy.splice(idx, 1);
    copy.splice(targetIdx, 0, item);
    onChangeDraft({ ...draftConfig, sectionOrder: copy });
  };

  return (
    <>
      {/* Top Studio Bar — clears mobile bottom nav bar cleanly */}
      <div className="fixed bottom-[68px] md:bottom-4 left-1/2 -translate-x-1/2 z-50 w-[96vw] max-w-5xl max-h-[65dvh] overflow-y-auto rounded-2xl bg-[#141418]/95 backdrop-blur-xl border-2 border-[#D4AF37] shadow-2xl p-3 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2.5 sm:gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="p-1.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] shrink-0">
              <MousePointerClick className="w-4 h-4" />
            </span>
            <div className="min-w-0">
              <p className="text-xs font-bold text-[#F5F5F0]">
                Super Admin Live Visual Editor
              </p>
              <p className="text-[11px] text-[#9898A3] truncate sm:whitespace-normal">
                {livePreviewOnly
                  ? 'Live Preview active — inspect changes cleanly.'
                  : 'Click any highlighted zone on the Dashboard or pick an element below to edit.'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-xs">
            <button
              onClick={onUndo}
              disabled={!canUndo}
              className="p-2 rounded-lg bg-white/5 border border-white/10 text-[#F5F5F0] disabled:opacity-40 min-w-[38px] min-h-[38px] flex items-center justify-center"
              title="Undo"
            >
              <Undo2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onRedo}
              disabled={!canRedo}
              className="p-2 rounded-lg bg-white/5 border border-white/10 text-[#F5F5F0] disabled:opacity-40 min-w-[38px] min-h-[38px] flex items-center justify-center"
              title="Redo"
            >
              <Redo2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setLivePreviewOnly((p) => !p)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border min-h-[38px] ${
                livePreviewOnly
                  ? 'bg-[#D4AF37]/20 border-[#D4AF37] text-[#D4AF37]'
                  : 'bg-white/5 border-white/10 text-[#F5F5F0]'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              {livePreviewOnly ? 'Show Inspector' : 'Live Preview'}
            </button>
            <button
              onClick={onSaveDraft}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 border border-white/15 text-[#F5F5F0] hover:bg-white/15 min-h-[38px]"
            >
              <Save className="w-3.5 h-3.5 text-[#D4AF37]" />
              Save Draft
            </button>
            <button
              onClick={onPublishLive}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#D4AF37] text-[#0A0A0C] font-semibold hover:bg-[#E5C158] min-h-[38px]"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              Publish Live
            </button>
            <button
              onClick={onCancel}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-500/15 border border-red-500/30 text-red-300 min-h-[38px]"
            >
              <X className="w-3.5 h-3.5" />
              Exit
            </button>
          </div>
        </div>

        {!livePreviewOnly && (
          <div className="border-t border-white/10 pt-3 space-y-3">
            {/* Quick Target Selectors */}
            <div className="flex overflow-x-auto sm:flex-wrap gap-1.5 text-[11px] no-scrollbar pb-1 sm:pb-0">
              {[
                { id: 'siteTitle', label: 'Brand Title' },
                { id: 'heroHeadline', label: 'Hero Headline' },
                { id: 'heroSubtitle', label: 'Hero Subtitle' },
                { id: 'heroImageUrl', label: 'Hero Image' },
                { id: 'bannerText', label: 'Banner Announcement' },
                { id: 'dailyTip', label: 'Daily Chess Tip' },
                { id: 'colors', label: 'Colors & Surfaces' },
                { id: 'buttons', label: 'Button Labels' },
                { id: 'navigation', label: 'Nav Labels & Tabs' },
                { id: 'sections', label: 'Reorder Sections' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => onSelectTarget(item.id as VisualEditTarget)}
                  className={`px-2.5 py-1.5 sm:py-1 rounded-md font-medium whitespace-nowrap shrink-0 min-h-[36px] sm:min-h-0 ${
                    selectedTarget === item.id
                      ? 'bg-[#D4AF37] text-[#0A0A0C] font-semibold'
                      : 'bg-[#0A0A0C] text-[#9898A3] hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              {savingStatus && (
                <span className="ml-auto text-emerald-400 font-medium self-center whitespace-nowrap">{savingStatus}</span>
              )}
            </div>

            {/* Active Element Inspector */}
            {selectedTarget === 'siteTitle' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[#9898A3] mb-1">Platform Wordmark Title</label>
                  <input
                    type="text"
                    value={draftConfig.siteTitle}
                    onChange={(e) => onChangeDraft({ ...draftConfig, siteTitle: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                  />
                </div>
              </div>
            )}

            {selectedTarget === 'heroHeadline' && (
              <div className="text-xs">
                <label className="block text-[#9898A3] mb-1">Hero Headline</label>
                <input
                  type="text"
                  value={draftConfig.heroHeadline}
                  onChange={(e) => onChangeDraft({ ...draftConfig, heroHeadline: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                />
              </div>
            )}

            {selectedTarget === 'heroSubtitle' && (
              <div className="text-xs">
                <label className="block text-[#9898A3] mb-1">Hero Subtitle</label>
                <input
                  type="text"
                  value={draftConfig.heroSubtitle}
                  onChange={(e) => onChangeDraft({ ...draftConfig, heroSubtitle: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                />
              </div>
            )}

            {selectedTarget === 'heroImageUrl' && (
              <div className="text-xs">
                <label className="block text-[#9898A3] mb-1">Hero Showcase Image URL</label>
                <input
                  type="text"
                  value={draftConfig.heroImageUrl || '/src/assets/images/hero_chess_arena_1794980498823.jpg'}
                  onChange={(e) => onChangeDraft({ ...draftConfig, heroImageUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                />
              </div>
            )}

            {selectedTarget === 'bannerText' && (
              <div className="text-xs">
                <label className="block text-[#9898A3] mb-1">Top Announcement Banner Text (blank uses active announcement)</label>
                <input
                  type="text"
                  value={draftConfig.bannerText}
                  onChange={(e) => onChangeDraft({ ...draftConfig, bannerText: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                />
              </div>
            )}

            {selectedTarget === 'dailyTip' && (
              <div className="text-xs">
                <label className="block text-[#9898A3] mb-1">Custom Daily Chess Tip Override</label>
                <input
                  type="text"
                  value={draftConfig.dailyTip || ''}
                  placeholder="Leave blank to rotate built-in Grandmaster tips..."
                  onChange={(e) => onChangeDraft({ ...draftConfig, dailyTip: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                />
              </div>
            )}

            {selectedTarget === 'colors' && (
              <div className="grid grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-[#9898A3] mb-1">Accent Color</label>
                  <input
                    type="color"
                    value={draftConfig.accentColor}
                    onChange={(e) => onChangeDraft({ ...draftConfig, accentColor: e.target.value })}
                    className="w-full h-9 rounded bg-transparent cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block text-[#9898A3] mb-1">Canvas Background</label>
                  <input
                    type="color"
                    value={draftConfig.canvasColor}
                    onChange={(e) => onChangeDraft({ ...draftConfig, canvasColor: e.target.value })}
                    className="w-full h-9 rounded bg-transparent cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block text-[#9898A3] mb-1">Card Surface</label>
                  <input
                    type="color"
                    value={draftConfig.surfaceColor}
                    onChange={(e) => onChangeDraft({ ...draftConfig, surfaceColor: e.target.value })}
                    className="w-full h-9 rounded bg-transparent cursor-pointer"
                  />
                </div>
              </div>
            )}

            {selectedTarget === 'buttons' && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                {[
                  { key: 'playWorldwide', label: 'Worldwide CTA', def: 'Play Worldwide' },
                  { key: 'playComputer', label: 'Computer CTA', def: 'Play vs Computer' },
                  { key: 'privateRoom', label: 'Private Room CTA', def: 'Private Room' },
                  { key: 'dailyPuzzle', label: 'Puzzle CTA', def: 'Daily Puzzle' },
                ].map((b) => (
                  <div key={b.key}>
                    <label className="block text-[#9898A3] mb-1">{b.label}</label>
                    <input
                      type="text"
                      value={
                        draftConfig.buttonLabels?.[
                          b.key as keyof NonNullable<AppUiConfig['buttonLabels']>
                        ] ?? b.def
                      }
                      onChange={(e) =>
                        onChangeDraft({
                          ...draftConfig,
                          buttonLabels: {
                            ...(draftConfig.buttonLabels || {}),
                            [b.key]: e.target.value,
                          },
                        })
                      }
                      className="w-full px-2.5 py-1.5 rounded bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                    />
                  </div>
                ))}
              </div>
            )}

            {selectedTarget === 'navigation' && (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 text-xs">
                {[
                  { key: 'dashboard', def: 'Dashboard' },
                  { key: 'play', def: 'Play Arena' },
                  { key: 'players', def: 'Players' },
                  { key: 'training', def: 'Learning' },
                  { key: 'tournaments', def: 'Tournaments' },
                  { key: 'leaderboards', def: 'Rankings' },
                ].map((n) => (
                  <div key={n.key}>
                    <label className="block text-[#9898A3] mb-1 capitalize">{n.key}</label>
                    <input
                      type="text"
                      value={
                        draftConfig.navLabels?.[
                          n.key as keyof NonNullable<AppUiConfig['navLabels']>
                        ] ?? n.def
                      }
                      onChange={(e) =>
                        onChangeDraft({
                          ...draftConfig,
                          navLabels: {
                            ...(draftConfig.navLabels || {}),
                            [n.key]: e.target.value,
                          },
                        })
                      }
                      className="w-full px-2.5 py-1.5 rounded bg-[#0A0A0C] border border-white/10 text-[#F5F5F0]"
                    />
                  </div>
                ))}
              </div>
            )}

            {selectedTarget === 'sections' && (
              <div className="flex flex-wrap gap-2 text-xs">
                {sectionOrder.map((sec, idx) => (
                  <div
                    key={sec}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#0A0A0C] border border-white/10"
                  >
                    <span className="capitalize text-[#F5F5F0]">{sec}</span>
                    <button
                      onClick={() => moveSection(idx, -1)}
                      disabled={idx === 0}
                      className="p-0.5 text-[#D4AF37] disabled:opacity-30"
                    >
                      <ArrowUp className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => moveSection(idx, 1)}
                      disabled={idx === sectionOrder.length - 1}
                      className="p-0.5 text-[#D4AF37] disabled:opacity-30"
                    >
                      <ArrowDown className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
};
