export interface AchievementDef {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  pointsReward: number;
  category: 'combat' | 'training' | 'social' | 'seasonal';
}

export const ACHIEVEMENTS: AchievementDef[] = [
  {
    id: 'first_victory',
    title: 'First Blood',
    description: 'Win your first official match in Chess Arena.',
    xpReward: 100,
    pointsReward: 50,
    category: 'combat',
  },
  {
    id: 'streak_3',
    title: 'Unstoppable Momentum',
    description: 'Achieve a 3-game consecutive winning streak.',
    xpReward: 200,
    pointsReward: 120,
    category: 'combat',
  },
  {
    id: 'tactician_10',
    title: 'Tactical Razor',
    description: 'Solve 10 tactical chess puzzles.',
    xpReward: 180,
    pointsReward: 100,
    category: 'training',
  },
  {
    id: 'speed_demon',
    title: 'Lightning Checkmate',
    description: 'Win a match in under 90 seconds.',
    xpReward: 250,
    pointsReward: 150,
    category: 'combat',
  },
  {
    id: 'grand_scholar',
    title: 'Opening Virtuoso',
    description: 'Complete an interactive Opening Trainer repertoire.',
    xpReward: 140,
    pointsReward: 80,
    category: 'training',
  },
  {
    id: 'arena_competitor',
    title: 'Tournament Contender',
    description: 'Register and compete in a Chess Arena tournament.',
    xpReward: 220,
    pointsReward: 140,
    category: 'social',
  },
  {
    id: 'winter_crown_2026',
    title: 'Obsidian Crown Season',
    description: 'Participate during the 2026 Grandmaster Championship Season.',
    xpReward: 300,
    pointsReward: 200,
    category: 'seasonal',
  },
];

export interface MissionDef {
  id: string;
  title: string;
  type: 'daily' | 'weekly';
  target: number;
  xpReward: number;
  pointsReward: number;
}

export const DAILY_MISSIONS: MissionDef[] = [
  { id: 'daily_play_1', title: 'Complete 1 competitive or AI match', type: 'daily', target: 1, xpReward: 75, pointsReward: 40 },
  { id: 'daily_puzzle_2', title: 'Solve 2 tactical puzzles', type: 'daily', target: 2, xpReward: 90, pointsReward: 50 },
  { id: 'weekly_wins_5', title: 'Win 5 matches this week', type: 'weekly', target: 5, xpReward: 400, pointsReward: 250 },
];
