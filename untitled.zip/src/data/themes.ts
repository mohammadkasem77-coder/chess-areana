import { BoardThemeId, PieceStyleId, ProfileFrameId, ProfileThemeId, TimeControlConfig } from '../types/chess';

export interface BoardThemeDefinition {
  id: BoardThemeId;
  name: string;
  lightSquare: string;
  darkSquare: string;
  highlightLast: string;
  highlightSelected: string;
  coordLight: string;
  coordDark: string;
  frameBorder: string;
}

export const BOARD_THEMES: Record<BoardThemeId, BoardThemeDefinition> = {
  classic_wood: {
    id: 'classic_wood',
    name: 'Classic Wood',
    lightSquare: '#DFC49C',
    darkSquare: '#8C5B37',
    highlightLast: 'rgba(212, 175, 55, 0.42)',
    highlightSelected: 'rgba(229, 193, 88, 0.55)',
    coordLight: '#8C5B37',
    coordDark: '#DFC49C',
    frameBorder: '#4A301D',
  },
  modern_marble: {
    id: 'modern_marble',
    name: 'Modern Marble',
    lightSquare: '#E5E7EB',
    darkSquare: '#475569',
    highlightLast: 'rgba(212, 175, 55, 0.40)',
    highlightSelected: 'rgba(245, 158, 11, 0.48)',
    coordLight: '#475569',
    coordDark: '#E5E7EB',
    frameBorder: '#334155',
  },
  midnight: {
    id: 'midnight',
    name: 'Midnight',
    lightSquare: '#313644',
    darkSquare: '#1B1E27',
    highlightLast: 'rgba(212, 175, 55, 0.34)',
    highlightSelected: 'rgba(212, 175, 55, 0.50)',
    coordLight: '#8E96A8',
    coordDark: '#6B7280',
    frameBorder: '#272B36',
  },
  emerald: {
    id: 'emerald',
    name: 'Emerald',
    lightSquare: '#DDE6D5',
    darkSquare: '#2D6A4F',
    highlightLast: 'rgba(212, 175, 55, 0.44)',
    highlightSelected: 'rgba(245, 158, 11, 0.52)',
    coordLight: '#2D6A4F',
    coordDark: '#DDE6D5',
    frameBorder: '#1B4332',
  },
  golden: {
    id: 'golden',
    name: 'Golden',
    lightSquare: '#EFE1B8',
    darkSquare: '#7C6229',
    highlightLast: 'rgba(255, 255, 255, 0.36)',
    highlightSelected: 'rgba(212, 175, 55, 0.65)',
    coordLight: '#7C6229',
    coordDark: '#EFE1B8',
    frameBorder: '#52401A',
  },
  minimal: {
    id: 'minimal',
    name: 'Minimal',
    lightSquare: '#D6D6D2',
    darkSquare: '#52525B',
    highlightLast: 'rgba(212, 175, 55, 0.42)',
    highlightSelected: 'rgba(212, 175, 55, 0.55)',
    coordLight: '#52525B',
    coordDark: '#D6D6D2',
    frameBorder: '#27272A',
  },
};

export const PIECE_STYLES: { id: PieceStyleId; name: string; description: string }[] = [
  { id: 'staunton', name: 'Classic Staunton', description: 'Tournament standard silhouette with crisp outline' },
  { id: 'neo', name: 'Neo Modern', description: 'Clean geometric contours with soft highlights' },
  { id: 'royal', name: 'Royal Gold & Obsidian', description: 'Gilded metallic accents for prestige matches' },
  { id: 'minimal', name: 'Minimalist Flat', description: 'High-contrast flat iconography for speed chess' },
];

export const TIME_CONTROLS: TimeControlConfig[] = [
  { id: '1+0', label: '1+0', category: 'bullet', initialSeconds: 60, incrementSeconds: 0 },
  { id: '2+1', label: '2+1', category: 'bullet', initialSeconds: 120, incrementSeconds: 1 },
  { id: '3+0', label: '3+0', category: 'blitz', initialSeconds: 180, incrementSeconds: 0 },
  { id: '3+2', label: '3+2', category: 'blitz', initialSeconds: 180, incrementSeconds: 2 },
  { id: '5+0', label: '5+0', category: 'blitz', initialSeconds: 300, incrementSeconds: 0 },
  { id: '5+3', label: '5+3', category: 'blitz', initialSeconds: 300, incrementSeconds: 3 },
  { id: '10+0', label: '10+0', category: 'rapid', initialSeconds: 600, incrementSeconds: 0 },
  { id: '10+5', label: '10+5', category: 'rapid', initialSeconds: 600, incrementSeconds: 5 },
  { id: '15+10', label: '15+10', category: 'rapid', initialSeconds: 900, incrementSeconds: 10 },
  { id: '30+0', label: '30+0', category: 'classical', initialSeconds: 1800, incrementSeconds: 0 },
  { id: '30+20', label: '30+20', category: 'classical', initialSeconds: 1800, incrementSeconds: 20 },
];

export const AVATAR_OPTIONS = [
  {
    id: 'knight_obsidian',
    label: 'Obsidian Knight',
    url: '/src/assets/images/avatar_knight_obsidian_1794980498230.jpg',
  },
  {
    id: 'queen_gold',
    label: 'Royal Crown',
    url: '/src/assets/images/avatar_queen_gold_1794980498804.jpg',
  },
  {
    id: 'rook_emerald',
    label: 'Emerald Bastion',
    url: '/src/assets/images/avatar_rook_emerald_1794980498723.jpg',
  },
];

export const HERO_BANNER_IMAGE = '/src/assets/images/hero_chess_arena_1794980498823.jpg';

export const COUNTRIES = [
  'Global',
  'United States',
  'United Kingdom',
  'India',
  'Norway',
  'Germany',
  'France',
  'Spain',
  'Canada',
  'Brazil',
  'Japan',
  'South Korea',
  'United Arab Emirates',
  'Bangladesh',
  'Turkey',
  'Poland',
  'Netherlands',
  'Australia',
];

export const COUNTRY_FLAGS: Record<string, string> = {
  Global: '🌐',
  'United States': '🇺🇸',
  'United Kingdom': '🇬🇧',
  India: '🇮🇳',
  Norway: '🇳🇴',
  Germany: '🇩🇪',
  France: '🇫🇷',
  Spain: '🇪🇸',
  Canada: '🇨🇦',
  Brazil: '🇧🇷',
  Japan: '🇯🇵',
  'South Korea': '🇰🇷',
  'United Arab Emirates': '🇦🇪',
  Bangladesh: '🇧🇩',
  Turkey: '🇹🇷',
  Poland: '🇵🇱',
  Netherlands: '🇳🇱',
  Australia: '🇦🇺',
};

export function getCountryFlag(country?: string): string {
  if (!country) return '🌐';
  return COUNTRY_FLAGS[country] || '🌐';
}

export const PROFILE_THEMES: { id: ProfileThemeId; name: string; gradient: string; accent: string }[] = [
  { id: 'obsidian_gold', name: 'Obsidian Gold', gradient: 'from-[#1B1914] via-[#141418] to-[#0A0A0C]', accent: '#D4AF37' },
  { id: 'royal_emerald', name: 'Royal Emerald', gradient: 'from-[#10241C] via-[#121A18] to-[#0A0A0C]', accent: '#34D399' },
  { id: 'midnight_sapphire', name: 'Midnight Sapphire', gradient: 'from-[#111B2E] via-[#141418] to-[#0A0A0C]', accent: '#60A5FA' },
  { id: 'crimson_grandmaster', name: 'Crimson Grandmaster', gradient: 'from-[#2A1216] via-[#181418] to-[#0A0A0C]', accent: '#F87171' },
];

export const PROFILE_FRAMES: { id: ProfileFrameId; name: string; ringClass: string }[] = [
  { id: 'none', name: 'Clean Minimal', ringClass: 'ring-1 ring-white/15' },
  { id: 'gold_laurel', name: 'Champion Gold', ringClass: 'ring-2 ring-[#D4AF37] shadow-[0_0_16px_rgba(212,175,55,0.3)]' },
  { id: 'emerald_crest', name: 'Emerald Crest', ringClass: 'ring-2 ring-emerald-400 shadow-[0_0_16px_rgba(52,211,153,0.28)]' },
  { id: 'ivory_border', name: 'Grand Ivory', ringClass: 'ring-2 ring-[#F5F5F0]' },
];

export function getRankTitle(rating: number): { title: string; tier: string } {
  if (rating >= 2500) return { title: 'Grandmaster', tier: 'GM' };
  if (rating >= 2300) return { title: 'International Master', tier: 'IM' };
  if (rating >= 2100) return { title: 'FIDE Master', tier: 'FM' };
  if (rating >= 1800) return { title: 'Candidate Master', tier: 'CM' };
  if (rating >= 1500) return { title: 'Club Strategist', tier: 'Class A' };
  if (rating >= 1300) return { title: 'Tactician', tier: 'Class B' };
  return { title: 'Challenger', tier: 'Class C' };
}

export const OPENING_PRESETS_LIST: string[] = [
  'Italian Game',
  'Ruy Lopez (Spanish Opening)',
  'Sicilian Defense',
  "Queen's Gambit",
  'French Defense',
  'Caro-Kann Defense',
  'London System',
  "King's Indian Defense",
  'Nimzo-Indian Defense',
  'Scandinavian Defense',
];

