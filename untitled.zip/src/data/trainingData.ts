import { LearningVideo, OpeningLesson, PuzzleItem, VideoCategory } from '../types/chess';

export const CHESS_PUZZLES: PuzzleItem[] = [
  {
    id: 'pz_01',
    title: 'Back-Rank Strike',
    theme: 'mate_in_1',
    rating: 950,
    fen: '6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1',
    solution: ['d1d8'],
    explanation: 'Black has no luft for the king on g8. Rd8# delivers an immediate back-rank checkmate.',
    isDaily: true,
  },
  {
    id: 'pz_02',
    title: 'Royal Fork',
    theme: 'fork',
    rating: 1120,
    fen: 'r3k3/8/8/3N4/8/8/8/4K2R w Kq - 0 1',
    solution: ['d5c7'],
    explanation: 'Nc7+ forks the Black king on e8 and the undefended rook on a8.',
  },
  {
    id: 'pz_03',
    title: "Philidor's Legacy",
    theme: 'mate_in_2',
    rating: 1480,
    fen: '6rk/6pp/7N/8/2Q5/8/8/6K1 w - - 0 1',
    solution: ['c4g8', 'g8g8', 'h6f7'],
    explanation: "Qg8+ forces Rxg8, blocking the king's escape, and Nf7# delivers a classic smothered checkmate.",
  },
  {
    id: 'pz_04',
    title: 'Arabian Mate',
    theme: 'mate_in_1',
    rating: 1180,
    fen: '7k/8/5N2/8/8/8/7R/6K1 w - - 0 1',
    solution: ['h2h7'],
    explanation: 'The Knight on f6 covers g8 and h7; Rook to h7 delivers the classic Arabian Mate!',
  },
  {
    id: 'pz_05',
    title: 'Scholarly Pin',
    theme: 'pin',
    rating: 1240,
    fen: '4k3/4q3/8/8/1B6/8/8/4R1K1 w - - 0 1',
    solution: ['b4e7'],
    explanation: 'Bxe7 wins the pinned queen directly along the central file.',
  },
  {
    id: 'pz_06',
    title: 'Deadly Skewer',
    theme: 'skewer',
    rating: 1290,
    fen: '4k3/8/8/8/8/8/4q3/R5K1 w - - 0 1',
    solution: ['a1a8'],
    explanation: 'Ra8+ forces the king away while controlling the 8th rank.',
  },
  {
    id: 'pz_07',
    title: 'Queen & Pawn Opposition',
    theme: 'endgame',
    rating: 1350,
    fen: '8/8/8/4k3/8/4P3/4K3/8 w - - 0 1',
    solution: ['e2d3'],
    explanation: 'Advancing the king in front or alongside the pawn maintains key squares.',
  },
  {
    id: 'pz_08',
    title: 'Rook Battery Checkmate',
    theme: 'mate_in_1',
    rating: 1050,
    fen: '6k1/5p1p/6p1/8/8/8/1R6/R5K1 w - - 0 1',
    solution: ['b2b8'],
    explanation: 'Rb8# delivers checkmate along the 8th rank because f7, g6, and h7 block escape.',
  },
  {
    id: 'pz_09',
    title: 'Double Rook Roller',
    theme: 'mate_in_1',
    rating: 900,
    fen: '3k4/R7/8/1R6/8/8/8/6K1 w - - 0 1',
    solution: ['b5b8'],
    explanation: 'Rb8# completes the ladder mate as Ra7 controls the entire 7th rank.',
  },
  {
    id: 'pz_10',
    title: 'Greek Gift Sacrifice',
    theme: 'tactic',
    rating: 1580,
    fen: 'r1bq1rk1/ppp2ppp/2n2n2/3p4/3P4/2NBPN2/PPP2PPP/R1BQK2R w KQ - 0 1',
    solution: ['d3h7'],
    explanation: "Bxh7+! Classic Greek Gift sacrifice stripping the castled king's shelter before Ng5+ and Qh5.",
  },
  {
    id: 'pz_11',
    title: 'Lucena Bridge Builder',
    theme: 'endgame',
    rating: 1750,
    fen: '1K1k4/1P6/8/8/8/8/4R3/2r5 w - - 0 1',
    solution: ['e2e4'],
    explanation: 'Re4 prepares to build the Lucena bridge on the 4th rank so the White king can escape checks and promote.',
  },
  {
    id: 'pz_12',
    title: 'Knight Outpost Fork',
    theme: 'fork',
    rating: 1190,
    fen: 'r4rk1/ppp2ppp/8/3n4/8/2N2Q2/PPP2PPP/R4RK1 b - - 0 1',
    solution: ['d5c3'],
    explanation: "Black exchanges the strong knight on c3 to shatter White's queenside structure.",
  },
];

export const OPENING_LESSONS: OpeningLesson[] = [
  {
    id: 'op_italian',
    name: 'Italian Game — Giuoco Piano',
    eco: 'C50',
    side: 'w',
    difficulty: 'Beginner',
    moves: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5', 'c3', 'Nf6', 'd4'],
    description: 'Controls the center rapidly while targeting the vulnerable f7 square and preparing a central pawn break with d4.',
    keyIdeas: [
      'Develop knights before bishops and castle early.',
      'Use c3 to prepare a strong d4 central pawn advance.',
      'Aim the light-squared bishop down the a2-g8 diagonal.',
    ],
  },
  {
    id: 'op_sicilian',
    name: 'Sicilian Defense — Najdorf Setup',
    eco: 'B90',
    side: 'b',
    difficulty: 'Master',
    moves: ['e4', 'c5', 'Nf3', 'd6', 'd4', 'cxd4', 'Nxd4', 'Nf6', 'Nc3', 'a6'],
    description: 'The sharpest asymmetric counter-attacking response to 1.e4, fighting for the c-file and queenside space.',
    keyIdeas: [
      "Trade a flank c-pawn for White's central d-pawn.",
      '6...a6 prevents Bb5/Nb5 jumps and prepares ...e5 or ...b5.',
      'Create dynamic counterplay along the half-open c-file.',
    ],
  },
  {
    id: 'op_queens_gambit',
    name: "Queen's Gambit Declined",
    eco: 'D30',
    side: 'w',
    difficulty: 'Intermediate',
    moves: ['d4', 'd5', 'c4', 'e6', 'Nc3', 'Nf6', 'Bg5', 'Be7', 'e3'],
    description: 'Classical positional battle for central dark squares and harmonious queenside development.',
    keyIdeas: [
      "Challenge Black's d5 center immediately with 2.c4.",
      'Pin the f6 knight to apply pressure on d5.',
      'Prepare a minority attack on the queenside.',
    ],
  },
  {
    id: 'op_london',
    name: 'London System',
    eco: 'D02',
    side: 'w',
    difficulty: 'Beginner',
    moves: ['d4', 'd5', 'Bf4', 'Nf6', 'e3', 'e6', 'Nf3', 'c5', 'c3'],
    description: 'Rock-solid universal system with a resilient d4-e3-c3 pawn pyramid and active dark-squared bishop.',
    keyIdeas: [
      'Develop the dark-squared bishop to f4 before playing e3.',
      'Anchor the e5 outpost with knights and pawns.',
      'Maintain a flexible, blunder-resistant structure.',
    ],
  },
];

export const ENDGAME_DRILLS = [
  {
    id: 'eg_lucena',
    title: 'Rook & Pawn — The Lucena Position',
    difficulty: 'Master',
    fen: '1K1k4/1P6/8/8/8/8/4R3/2r5 w - - 0 1',
    goal: 'Build a bridge with your rook on the 4th rank to shelter your king and promote.',
  },
  {
    id: 'eg_opposition',
    title: 'King & Pawn Opposition',
    difficulty: 'Beginner',
    fen: '4k3/8/8/8/4P3/4K3/8/8 w - - 0 1',
    goal: 'Advance your king ahead of the pawn to seize direct opposition and force promotion.',
  },
  {
    id: 'eg_queen_mate',
    title: 'King & Queen vs Lone King',
    difficulty: 'Beginner',
    fen: '8/8/8/3k4/8/8/8/3QK3 w - - 0 1',
    goal: 'Drive the enemy king to the edge of the board using knight-distance restriction without stalemating.',
  },
];

export const CHESS_LESSONS = [
  {
    id: 'ls_01',
    title: '01. Controlling the Center & Rapid Development',
    level: 'Foundation',
    duration: '6 min',
    summary: 'Why occupying e4, d4, e5, and d5 maximizes piece mobility and restricts your opponent.',
    points: [
      'Knights placed on central squares control up to 8 squares vs 2 in the corner.',
      'Avoid moving the same piece twice in the opening without tactical justification.',
      'Castle within the first 8 moves to connect your rooks and safeguard your king.',
    ],
  },
  {
    id: 'ls_02',
    title: '02. Tactical Motifs: Forks, Pins & Skewers',
    level: 'Intermediate',
    duration: '8 min',
    summary: 'How to spot double attacks and exploit aligned enemy pieces for decisive material gain.',
    points: [
      'Always scan for checks, captures, and threats before committing to a quiet move.',
      'A pinned piece cannot defend other pieces behind or beside it effectively.',
      'Knight forks are lethal when enemy heavy pieces share the same square color.',
    ],
  },
  {
    id: 'ls_03',
    title: '03. Endgame Precision & Pawn Structure',
    level: 'Advanced',
    duration: '10 min',
    summary: 'Converting small advantages through king activity, passed pawns, and rook placement.',
    points: [
      'In endgames, the King transforms from a liability into an active attacking piece (~4 points of strength).',
      "Rooks belong behind passed pawns — both your own and your opponent's.",
      "Create a passed pawn on the side away from the opponent's king.",
    ],
  },
];

export interface FundamentalTopic {
  id: string;
  title: string;
  badge: string;
  fen: string;
  summary: string;
  rules: string[];
}

export const CHESS_FUNDAMENTALS: FundamentalTopic[] = [
  {
    id: 'fund_board',
    title: 'How to Play Chess & Board Setup',
    badge: 'Basics',
    fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
    summary:
      'Chess is played on an 8x8 board of 64 alternating light and dark squares. Files run a–h and ranks run 1–8. Remember: "White on right" (h1 is a light square) and Queens start on their own color (White Queen on d1, Black Queen on d8).',
    rules: [
      'White always moves first, then players alternate turns.',
      'Each player starts with 16 pieces: 8 Pawns, 2 Rooks, 2 Knights, 2 Bishops, 1 Queen, and 1 King.',
      'The objective is Checkmate — trapping the enemy King under an inescapable attack.',
    ],
  },
  {
    id: 'fund_pieces',
    title: 'Piece Movements & Relative Values',
    badge: 'Pieces',
    fen: '8/8/8/3Q4/2N1B3/8/4R3/4K2k w - - 0 1',
    summary:
      'Every piece has a distinct movement pattern and strategic value used to evaluate trades cleanly.',
    rules: [
      'King (K): Moves 1 square in any direction. Never allowed to step into check.',
      'Queen (Q · 9 pts): Combines Rook and Bishop — any distance horizontally, vertically, or diagonally.',
      'Rook (R · 5 pts): Any distance horizontally or vertically along ranks and files.',
      'Bishop (B · 3 pts): Any distance diagonally; stays on its starting square color forever.',
      'Knight (N · 3 pts): Moves in an L-shape (2+1 squares) and is the ONLY piece that jumps over others.',
      'Pawn (1 pt): Moves 1 square forward (or 2 from its starting rank), captures 1 square diagonally forward.',
    ],
  },
  {
    id: 'fund_special',
    title: 'Special Rules: Castling, En Passant & Promotion',
    badge: 'Special Rules',
    fen: 'r3k2r/8/8/3pP3/8/8/8/R3K2R w KQkq d6 0 1',
    summary:
      'Mastering the three special rules unlocks essential king safety and hidden pawn tactics.',
    rules: [
      'Castling (O-O or O-O-O): Move King two squares toward a Rook and hop the Rook over. Legal only if neither piece has moved, squares between are empty, and the King does not start in, pass through, or land in check.',
      'En Passant: If an enemy pawn advances 2 squares and lands beside your pawn on the 5th (or 4th) rank, you may capture it diagonally on the very next turn as if it moved 1 square.',
      'Pawn Promotion: Any pawn reaching the opposite back rank immediately transforms into a Queen, Rook, Bishop, or Knight.',
    ],
  },
  {
    id: 'fund_endings',
    title: 'Check, Checkmate & Draw Conditions',
    badge: 'Endings',
    fen: '6k1/5Q2/6K1/8/8/8/8/8 b - - 0 1',
    summary:
      'Knowing all ways a chess game can conclude helps you press winning attacks and save lost positions.',
    rules: [
      'Check: King is directly attacked; you MUST parry by moving the King, blocking, or capturing the attacker.',
      'Checkmate: King is in check with zero legal escapes — instant victory.',
      'Stalemate (Draw): Side to move has NO legal moves and is NOT in check.',
      'Other Draws: Threefold repetition, 50-move rule without capture/pawn push, insufficient mating material (K+B vs K), or mutual agreement.',
    ],
  },
];

export interface StrategyGuide {
  id: string;
  phase: 'Opening' | 'Middlegame' | 'Endgame' | 'Tactics' | 'Positional' | 'Defense' | 'Attack';
  title: string;
  headline: string;
  principles: string[];
}

export const CHESS_STRATEGIES: StrategyGuide[] = [
  {
    id: 'str_opening',
    phase: 'Opening',
    title: 'Opening Principles',
    headline: 'Seize the center, mobilize minor pieces rapidly, and safeguard your king.',
    principles: [
      'Claim central squares (e4, d4, e5, d5) with pawns and minor pieces.',
      'Develop Knights before Bishops; avoid early Queen excursions.',
      'Castle early to connect your Rooks toward central open files.',
    ],
  },
  {
    id: 'str_middlegame',
    phase: 'Middlegame',
    title: 'Middlegame Planning',
    headline: 'Identify pawn breaks, weak squares, and improve your worst-placed piece.',
    principles: [
      'Place Rooks on open or half-open files and aim for the 7th rank.',
      'Evaluate pawn structure: create outposts (squares undefendable by enemy pawns) for Knights.',
      'Trade off your bad Bishop and keep pieces that harmonize with your pawn breaks.',
    ],
  },
  {
    id: 'str_tactics',
    phase: 'Tactics',
    title: 'Tactical Motifs Checklist',
    headline: 'Always calculate forcing moves first: Checks -> Captures -> Threats.',
    principles: [
      'Double Attacks & Forks: Target two undefended or high-value pieces simultaneously.',
      'Pins, Skewers & Discovered Attacks: Exploit geometric alignments on files, ranks, and diagonals.',
      'Deflection & Decoy: Lure an overworked defender away from a critical square.',
    ],
  },
  {
    id: 'str_endgame',
    phase: 'Endgame',
    title: 'Endgame Conversion',
    headline: 'Activate the King and push passed pawns with Rook support.',
    principles: [
      'King Opposition & Key Squares decide King + Pawn endgames.',
      'Tarrasch Rule: Put Rooks BEHIND passed pawns, never in front passively.',
      'Two Weaknesses Principle: Stretch the defender on both flanks to break fortress lines.',
    ],
  },
  {
    id: 'str_defense',
    phase: 'Defense',
    title: 'Defense & Counterplay',
    headline: 'Stay calm under pressure by trading attackers and striking back in the center.',
    principles: [
      'Answer a flank attack with a timely counter-strike in the center.',
      'Exchange the opponent\'s strongest attacking pieces to relieve cramped positions.',
      'Build a Fortress or aim for Perpetual Check when materially behind.',
    ],
  },
  {
    id: 'str_attack',
    phase: 'Attack',
    title: 'King-Hunt Attacking Techniques',
    headline: 'Open files near the enemy King and bring every spare piece into the assault.',
    principles: [
      'Use Pawn Storms when kings are castled on opposite sides of the board.',
      'Sacrifice to rip away pawn shields (e.g., Greek Gift Bxh7+ or Exchange Sac on c3/f6).',
      'Time matters more than a single pawn — never pause an attack for passive prophylaxis.',
    ],
  },
];

export const DAILY_CHESS_TIPS: string[] = [
  'Before making your move, ask: "What did my opponent\'s last move threaten?"',
  'Checks, Captures, Threats — scan forcing moves on every critical turn.',
  'Knights thrive on protected 5th-rank or 6th-rank outposts that enemy pawns cannot challenge.',
  'When ahead in material, trade pieces — not pawns — to reach an effortless winning endgame.',
  'An isolated queen pawn gives dynamic attacking space in the middlegame, but becomes a target in the endgame.',
  'Do not resign prematurely at club level — look for stalemate traps, back-rank tricks, or perpetual checks.',
];

export const VIDEO_CATEGORIES: VideoCategory[] = [
  'Beginner Chess Lessons',
  'Chess Rules Explained',
  'Opening Principles',
  'Tactical Puzzles',
  'Endgame Training',
  'Advanced Chess Strategies',
  'Grandmaster Lessons',
  'Chess Game Analysis',
  'Famous Chess Matches',
];

export const DEFAULT_LEARNING_VIDEOS: LearningVideo[] = [
  {
    videoId: 'vid_gotham_beginner',
    youtubeId: 'OCSbzArwB10',
    title: 'How To Play Chess: The Ultimate Beginner Guide',
    description: 'Complete walkthrough of chess board setup, every piece movement, castling, en passant, and core strategy.',
    category: 'Beginner Chess Lessons',
    author: 'GothamChess',
    isPlaylist: false,
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    videoId: 'vid_rules_explained',
    youtubeId: 'RFiO0qWji7A',
    title: 'How To Play Chess (For Beginners)',
    description: 'Step-by-step explanation of piece rules, check, checkmate, draws, and practical opening habits.',
    category: 'Chess Rules Explained',
    author: 'Random Chess Person',
    isPlaylist: false,
    createdAt: '2026-01-02T00:00:00Z',
  },
  {
    videoId: 'vid_25_openings',
    youtubeId: 'Mlhye6n7ug4',
    title: '25 Opening Principles Every Chess Player Should Know!',
    description: 'Essential central control, piece mobilization, and king safety heuristics for consistent openings.',
    category: 'Opening Principles',
    author: 'Critical Chess',
    isPlaylist: false,
    createdAt: '2026-01-03T00:00:00Z',
  },
  {
    videoId: 'vid_e4_crush',
    youtubeId: 'Qdyik5UwBtM',
    title: 'Learn to CRUSH with 1. e4 | 10-Minute Chess Openings',
    description: 'Dynamic 1.e4 repertoire covering sharp tactical responses against 1...e5, c5, e6, and c6.',
    category: 'Opening Principles',
    author: 'GothamChess',
    isPlaylist: false,
    createdAt: '2026-01-04T00:00:00Z',
  },
  {
    videoId: 'vid_london_system',
    youtubeId: '49H728S_VjM',
    title: 'Learn the London System | 10-Minute Chess Openings',
    description: 'Build a reliable, blunder-resistant opening pyramid with 1.d4 and 2.Bf4.',
    category: 'Opening Principles',
    author: 'GothamChess',
    isPlaylist: false,
    createdAt: '2026-01-05T00:00:00Z',
  },
  {
    videoId: 'vid_caro_kann',
    youtubeId: 'rmbU97iftC8',
    title: 'Learn the Caro-Kann Defense | 10-Minute Chess Openings',
    description: 'Solid, counter-attacking defense as Black against 1.e4 built on resilient pawn structure.',
    category: 'Opening Principles',
    author: 'GothamChess',
    isPlaylist: false,
    createdAt: '2026-01-06T00:00:00Z',
  },
  {
    videoId: 'vid_tactics_all',
    youtubeId: 'W1gWHIpQNVU',
    title: 'All The Chess Tactics You NEED To Know',
    description: 'Master forks, pins, skewers, discovered attacks, deflection, and tactical calculation.',
    category: 'Tactical Puzzles',
    author: 'Chess.com',
    isPlaylist: false,
    createdAt: '2026-01-07T00:00:00Z',
  },
  {
    videoId: 'vid_12_endgames',
    youtubeId: 'oWDPxirOPJk',
    title: '12 Endgames That Every Player Should Know! | The Dynamic Dozen',
    description: 'Saint Louis Chess Club grandmaster breakdown of opposition, Lucena, Philidor, and minor piece endings.',
    category: 'Endgame Training',
    author: 'Saint Louis Chess Club',
    isPlaylist: false,
    createdAt: '2026-01-08T00:00:00Z',
  },
  {
    videoId: 'vid_43_endgames',
    youtubeId: 'Zt8Op8Iscx0',
    title: '43 Essential Endgame Principles (From Beginner to Master)',
    description: 'Comprehensive endgame manual covering king activation, passed pawns, rook endings, and zugzwang.',
    category: 'Endgame Training',
    author: 'Critical Chess',
    isPlaylist: false,
    createdAt: '2026-01-09T00:00:00Z',
  },
  {
    videoId: 'vid_42_middlegame',
    youtubeId: 'frYioDppIWA',
    title: '42 Middlegame Principles to Improve Your Chess Strategy!',
    description: 'Deep positional strategy: weak squares, minority attacks, bishop pair, and pawn breaks.',
    category: 'Advanced Chess Strategies',
    author: 'Critical Chess',
    isPlaylist: false,
    createdAt: '2026-01-10T00:00:00Z',
  },
  {
    videoId: 'vid_carlsen_rules',
    youtubeId: 'D-c_hFQPrag',
    title: "Carlsen's 13 Rules To Play Chess So Well It's Almost Unfair",
    description: 'Positional intuition, practical decision-making, and relentless endgame squeeze insights.',
    category: 'Grandmaster Lessons',
    author: 'Remote Chess Academy',
    isPlaylist: false,
    createdAt: '2026-01-11T00:00:00Z',
  },
  {
    videoId: 'vid_ai_analysis',
    youtubeId: 'F3KsdeUDSrA',
    title: 'Gotham vs. Gotham-Bot: Can I Beat My AI Clone?',
    description: 'Instructive real-time commentary analyzing plans, sacrifices, and engine evaluations.',
    category: 'Chess Game Analysis',
    author: 'GothamChess',
    isPlaylist: false,
    createdAt: '2026-01-12T00:00:00Z',
  },
  {
    videoId: 'vid_euwe_tal',
    youtubeId: '1eZXKF1l1SA',
    title: "The Greatest Chess Game You've Never Seen || Euwe vs Tal (1960)",
    description: 'Brilliant tactical fireworks between World Champions Max Euwe and Mikhail Tal.',
    category: 'Famous Chess Matches',
    author: "agadmator's Chess Channel",
    isPlaylist: false,
    createdAt: '2026-01-13T00:00:00Z',
  },
];
