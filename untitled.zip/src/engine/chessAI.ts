import { Chess, Move } from 'chess.js';
import { AIDifficultyId, AIPersonalityId, MoveAnalysisItem } from '../types/chess';

const PIECE_VALUES: Record<string, number> = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 20000,
};

// Piece-square tables from White's perspective (a8 = index 0 .. h1 = index 63)
const PAWN_PST = [
  0, 0, 0, 0, 0, 0, 0, 0,
  50, 50, 50, 50, 50, 50, 50, 50,
  10, 10, 20, 30, 30, 20, 10, 10,
  5, 5, 10, 27, 27, 10, 5, 5,
  0, 0, 0, 24, 24, 0, 0, 0,
  5, -5, -10, 0, 0, -10, -5, 5,
  5, 10, 10, -22, -22, 10, 10, 5,
  0, 0, 0, 0, 0, 0, 0, 0,
];

const KNIGHT_PST = [
  -50, -40, -30, -30, -30, -30, -40, -50,
  -40, -20, 0, 0, 0, 0, -20, -40,
  -30, 0, 10, 15, 15, 10, 0, -30,
  -30, 5, 15, 20, 20, 15, 5, -30,
  -30, 0, 15, 20, 20, 15, 0, -30,
  -30, 5, 10, 15, 15, 10, 5, -30,
  -40, -20, 0, 5, 5, 0, -20, -40,
  -50, -40, -30, -30, -30, -30, -40, -50,
];

const BISHOP_PST = [
  -20, -10, -10, -10, -10, -10, -10, -20,
  -10, 0, 0, 0, 0, 0, 0, -10,
  -10, 0, 10, 10, 10, 10, 0, -10,
  -10, 5, 5, 10, 10, 5, 5, -10,
  -10, 0, 10, 10, 10, 10, 0, -10,
  -10, 10, 10, 10, 10, 10, 10, -10,
  -10, 5, 0, 0, 0, 0, 5, -10,
  -20, -10, -10, -10, -10, -10, -10, -20,
];

const ROOK_PST = [
  0, 0, 0, 0, 0, 0, 0, 0,
  5, 10, 10, 10, 10, 10, 10, 5,
  -5, 0, 0, 0, 0, 0, 0, -5,
  -5, 0, 0, 0, 0, 0, 0, -5,
  -5, 0, 0, 0, 0, 0, 0, -5,
  -5, 0, 0, 0, 0, 0, 0, -5,
  -5, 0, 0, 0, 0, 0, 0, -5,
  0, 0, 0, 5, 5, 0, 0, 0,
];

const QUEEN_PST = [
  -20, -10, -10, -5, -5, -10, -10, -20,
  -10, 0, 0, 0, 0, 0, 0, -10,
  -10, 0, 5, 5, 5, 5, 0, -10,
  -5, 0, 5, 5, 5, 5, 0, -5,
  0, 0, 5, 5, 5, 5, 0, -5,
  -10, 5, 5, 5, 5, 5, 0, -10,
  -10, 0, 5, 0, 0, 0, 0, -10,
  -20, -10, -10, -5, -5, -10, -10, -20,
];

const KING_MID_PST = [
  -30, -40, -40, -50, -50, -40, -40, -30,
  -30, -40, -40, -50, -50, -40, -40, -30,
  -30, -40, -40, -50, -50, -40, -40, -30,
  -30, -40, -40, -50, -50, -40, -40, -30,
  -20, -30, -30, -40, -40, -30, -30, -20,
  -10, -20, -20, -20, -20, -20, -20, -10,
  20, 20, 0, 0, 0, 0, 20, 20,
  20, 30, 10, 0, 0, 10, 30, 20,
];

const KING_END_PST = [
  -50, -40, -30, -20, -20, -30, -40, -50,
  -30, -20, -10, 0, 0, -10, -20, -30,
  -30, -10, 20, 30, 30, 20, -10, -30,
  -30, -10, 30, 40, 40, 30, -10, -30,
  -30, -10, 30, 40, 40, 30, -10, -30,
  -30, -10, 20, 30, 30, 20, -10, -30,
  -30, -30, 0, 0, 0, 0, -30, -30,
  -50, -30, -30, -30, -30, -30, -30, -50,
];

// Compact Opening Book for instant grandmaster-level opening theory offline
const OPENING_BOOK: Record<string, string[]> = {
  'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq -': ['e4', 'd4', 'c4', 'Nf3'],
  'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq -': ['c5', 'e5', 'e6', 'c6'],
  'rnbqkbnr/pppppppp/8/8/3P4/8/PPP1PPPP/RNBQKBNR b KQkq -': ['Nf6', 'd5', 'e6'],
  'rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq -': ['Nf3', 'Bc4'],
  'rnbqkbnr/pppp1ppp/8/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq -': ['Nc6', 'Nf6'],
  'r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq -': ['Bb5', 'Bc4', 'd4'],
  'rnbqkbnr/pp1ppppp/8/2p5/4P3/8/PPPP1PPP/RNBQKBNR w KQkq -': ['Nf3', 'Nc3', 'c3'],
  'rnbqkbnr/ppp1pppp/8/3p4/3P4/8/PPP1PPPP/RNBQKBNR w KQkq -': ['c4', 'Bf4', 'Nf3'],
  'rnbqkb1r/pppppppp/5n2/8/3P4/8/PPP1PPPP/RNBQKBNR w KQkq -': ['c4', 'Nf3', 'Bg5'],
};

function getDifficultyParams(difficulty: AIDifficultyId): {
  depth: number;
  timeBudgetMs: number;
  noiseCp: number;
  blunderRate: number;
  useBook: boolean;
} {
  switch (difficulty) {
    case 'beginner':
      return { depth: 1, timeBudgetMs: 120, noiseCp: 160, blunderRate: 0.3, useBook: false };
    case 'easy':
      return { depth: 2, timeBudgetMs: 200, noiseCp: 85, blunderRate: 0.14, useBook: false };
    case 'medium':
      return { depth: 2, timeBudgetMs: 350, noiseCp: 35, blunderRate: 0.04, useBook: true };
    case 'hard':
      return { depth: 3, timeBudgetMs: 550, noiseCp: 12, blunderRate: 0, useBook: true };
    case 'expert':
      return { depth: 3, timeBudgetMs: 850, noiseCp: 4, blunderRate: 0, useBook: true };
    case 'master':
      return { depth: 4, timeBudgetMs: 1200, noiseCp: 0, blunderRate: 0, useBook: true };
    case 'grandmaster':
      return { depth: 5, timeBudgetMs: 1600, noiseCp: 0, blunderRate: 0, useBook: true };
  }
}

export function evaluateBoard(chess: Chess, personality: AIPersonalityId = 'balanced'): number {
  if (chess.isCheckmate()) {
    return chess.turn() === 'w' ? -99999 : 99999;
  }
  if (chess.isDraw() || chess.isStalemate() || chess.isThreefoldRepetition() || chess.isInsufficientMaterial()) {
    return 0;
  }

  const board = chess.board();
  let totalNonKingMaterial = 0;
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (p && p.type !== 'k') totalNonKingMaterial += PIECE_VALUES[p.type];
    }
  }
  const isEndgame = totalNonKingMaterial < 2600;

  let score = 0;
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (!piece) continue;

      const idx = piece.color === 'w' ? r * 8 + c : (7 - r) * 8 + c;
      let val = PIECE_VALUES[piece.type];

      if (piece.type === 'p') val += PAWN_PST[idx];
      else if (piece.type === 'n') val += KNIGHT_PST[idx];
      else if (piece.type === 'b') val += BISHOP_PST[idx];
      else if (piece.type === 'r') val += ROOK_PST[idx];
      else if (piece.type === 'q') val += QUEEN_PST[idx];
      else if (piece.type === 'k') val += isEndgame ? KING_END_PST[idx] : KING_MID_PST[idx];

      // Personality adjustments
      if (personality === 'tactician') {
        if (piece.type === 'q' || piece.type === 'n' || piece.type === 'b') {
          const advance = piece.color === 'w' ? 7 - r : r;
          val += advance * 4;
        }
      } else if (personality === 'fortress') {
        if (piece.type === 'p' && (r === 1 || r === 6)) val += 8;
        if (piece.type === 'k' && !isEndgame && (c <= 2 || c >= 6)) val += 15;
      } else if (personality === 'endgame') {
        if (piece.type === 'p' && isEndgame) {
          const advance = piece.color === 'w' ? 7 - r : r;
          val += advance * 10;
        }
      }

      score += piece.color === 'w' ? val : -val;
    }
  }

  // Slight check bonus
  if (chess.inCheck()) {
    score += chess.turn() === 'w' ? -25 : 25;
  }

  return score;
}

function orderMoves(moves: Move[]): Move[] {
  return moves.sort((a, b) => {
    let scoreA = 0;
    let scoreB = 0;
    if (a.captured) scoreA += 10 * PIECE_VALUES[a.captured] - PIECE_VALUES[a.piece];
    if (b.captured) scoreB += 10 * PIECE_VALUES[b.captured] - PIECE_VALUES[b.piece];
    if (a.promotion) scoreA += PIECE_VALUES[a.promotion];
    if (b.promotion) scoreB += PIECE_VALUES[b.promotion];
    if (a.san.includes('+')) scoreA += 60;
    if (b.san.includes('+')) scoreB += 60;
    return scoreB - scoreA;
  });
}

function quiescence(
  chess: Chess,
  alpha: number,
  beta: number,
  maximizing: boolean,
  personality: AIPersonalityId,
  qDepth: number
): number {
  const standPat = evaluateBoard(chess, personality);
  if (qDepth <= 0) return standPat;

  if (maximizing) {
    if (standPat >= beta) return beta;
    if (alpha < standPat) alpha = standPat;
    const captures = orderMoves(
      chess.moves({ verbose: true }).filter((m) => m.captured || m.promotion)
    );
    for (const move of captures) {
      chess.move(move);
      const score = quiescence(chess, alpha, beta, false, personality, qDepth - 1);
      chess.undo();
      if (score >= beta) return beta;
      if (score > alpha) alpha = score;
    }
    return alpha;
  } else {
    if (standPat <= alpha) return alpha;
    if (beta > standPat) beta = standPat;
    const captures = orderMoves(
      chess.moves({ verbose: true }).filter((m) => m.captured || m.promotion)
    );
    for (const move of captures) {
      chess.move(move);
      const score = quiescence(chess, alpha, beta, true, personality, qDepth - 1);
      chess.undo();
      if (score <= alpha) return alpha;
      if (score < beta) beta = score;
    }
    return beta;
  }
}

interface SearchContext {
  deadline: number;
  aborted: boolean;
  nodes: number;
  personality: AIPersonalityId;
}

function alphaBeta(
  chess: Chess,
  depth: number,
  alpha: number,
  beta: number,
  maximizing: boolean,
  ctx: SearchContext
): number {
  ctx.nodes++;
  if ((ctx.nodes & 511) === 0 && performance.now() > ctx.deadline) {
    ctx.aborted = true;
    return 0;
  }

  if (chess.isGameOver()) {
    const score = evaluateBoard(chess, ctx.personality);
    if (score > 90000) return score + depth;
    if (score < -90000) return score - depth;
    return 0;
  }

  if (depth <= 0) {
    return quiescence(chess, alpha, beta, maximizing, ctx.personality, 3);
  }

  const moves = orderMoves(chess.moves({ verbose: true }));
  if (maximizing) {
    let best = -Infinity;
    for (const move of moves) {
      chess.move(move);
      const val = alphaBeta(chess, depth - 1, alpha, beta, false, ctx);
      chess.undo();
      if (ctx.aborted) return best;
      if (val > best) best = val;
      if (val > alpha) alpha = val;
      if (beta <= alpha) break;
    }
    return best;
  } else {
    let best = Infinity;
    for (const move of moves) {
      chess.move(move);
      const val = alphaBeta(chess, depth - 1, alpha, beta, true, ctx);
      chess.undo();
      if (ctx.aborted) return best;
      if (val < best) best = val;
      if (val < beta) beta = val;
      if (beta <= alpha) break;
    }
    return best;
  }
}

export function findBestMove(
  fen: string,
  difficulty: AIDifficultyId = 'medium',
  personality: AIPersonalityId = 'balanced'
): { move: Move | null; evalCp: number; depthReached: number } {
  const chess = new Chess(fen);
  const legalMoves = chess.moves({ verbose: true });
  if (legalMoves.length === 0) return { move: null, evalCp: 0, depthReached: 0 };

  const params = getDifficultyParams(difficulty);

  // Opening book lookup
  if (params.useBook) {
    const fenKey = fen.split(' ').slice(0, 4).join(' ');
    const bookSans = OPENING_BOOK[fenKey];
    if (bookSans && bookSans.length > 0) {
      const chosenSan = bookSans[Math.floor(Math.random() * bookSans.length)];
      const found = legalMoves.find((m) => m.san === chosenSan);
      if (found) {
        return { move: found, evalCp: 20, depthReached: 1 };
      }
    }
  }

  // Occasional beginner blunder simulation
  if (params.blunderRate > 0 && Math.random() < params.blunderRate) {
    const randomMove = legalMoves[Math.floor(Math.random() * legalMoves.length)];
    return { move: randomMove, evalCp: 0, depthReached: 1 };
  }

  const maximizing = chess.turn() === 'w';
  const deadline = performance.now() + params.timeBudgetMs;
  let bestOverallMove = legalMoves[0];
  let bestOverallScore = maximizing ? -Infinity : Infinity;
  let depthReached = 1;

  const orderedRoot = orderMoves([...legalMoves]);

  // Iterative deepening
  for (let d = 1; d <= params.depth; d++) {
    const ctx: SearchContext = {
      deadline,
      aborted: false,
      nodes: 0,
      personality,
    };

    let currentBestMove = orderedRoot[0];
    let currentBestScore = maximizing ? -Infinity : Infinity;
    const scoredMoves: { move: Move; score: number }[] = [];

    for (const move of orderedRoot) {
      chess.move(move);
      const val = alphaBeta(chess, d - 1, -Infinity, Infinity, !maximizing, ctx);
      chess.undo();
      if (ctx.aborted) break;

      const noisyVal =
        params.noiseCp > 0 ? val + (Math.random() * 2 - 1) * params.noiseCp : val;
      scoredMoves.push({ move, score: noisyVal });

      if (maximizing) {
        if (noisyVal > currentBestScore) {
          currentBestScore = noisyVal;
          currentBestMove = move;
        }
      } else {
        if (noisyVal < currentBestScore) {
          currentBestScore = noisyVal;
          currentBestMove = move;
        }
      }
    }

    if (!ctx.aborted) {
      bestOverallMove = currentBestMove;
      bestOverallScore = currentBestScore;
      depthReached = d;
      // Reorder root moves based on latest iteration
      scoredMoves.sort((a, b) => (maximizing ? b.score - a.score : a.score - b.score));
      orderedRoot.splice(0, orderedRoot.length, ...scoredMoves.map((s) => s.move));
    } else {
      break;
    }
  }

  return {
    move: bestOverallMove,
    evalCp: Math.round(bestOverallScore),
    depthReached,
  };
}

export function analyzeGameMoves(pgn: string): MoveAnalysisItem[] {
  const replay = new Chess();
  try {
    replay.loadPgn(pgn);
  } catch {
    return [];
  }

  const history = replay.history({ verbose: true });
  const sim = new Chess();
  const results: MoveAnalysisItem[] = [];

  for (let i = 0; i < history.length; i++) {
    const move = history[i];
    const fenBefore = sim.fen();
    const isWhite = move.color === 'w';

    // Quick 2-ply best move comparison
    const bestInfo = findBestMove(fenBefore, 'medium', 'balanced');
    const bestEval = bestInfo.evalCp;

    sim.move(move.san);
    const evalAfter = evaluateBoard(sim, 'balanced');

    const diffFromWhite = isWhite ? bestEval - evalAfter : evalAfter - bestEval;
    const cpLoss = Math.max(0, Math.round(diffFromWhite));

    let classification: MoveAnalysisItem['classification'] = 'Good';
    if (bestInfo.move && bestInfo.move.san === move.san) {
      classification = 'Best';
    } else if (cpLoss >= 250) {
      classification = 'Blunder';
    } else if (cpLoss >= 110) {
      classification = 'Mistake';
    } else if (cpLoss >= 50) {
      classification = 'Inaccuracy';
    } else if (cpLoss <= 15) {
      classification = 'Best';
    }

    results.push({
      ply: i + 1,
      moveSan: move.san,
      color: move.color,
      evalBefore: bestEval,
      evalAfter,
      centipawnLoss: cpLoss,
      classification,
      bestMoveSan: bestInfo.move?.san,
      fenBefore,
    });
  }

  return results;
}
