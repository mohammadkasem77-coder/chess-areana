import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
} from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { AVATAR_OPTIONS } from '../data/themes';
import {
  Announcement,
  AppUiConfig,
  ChatMessage,
  DirectMessage,
  FriendRequest,
  LearningVideo,
  MatchRecord,
  PlayerReport,
  Tournament,
  UserProfile,
} from '../types/chess';

function toIso(val: unknown): string {
  if (val instanceof Timestamp) return val.toDate().toISOString();
  if (typeof val === 'string') return val;
  return new Date().toISOString();
}

function generatePlayerId(uid: string): string {
  const clean = uid.replace(/[^a-zA-Z0-9]/g, '').toUpperCase().slice(0, 6);
  const suffix = Math.floor(1000 + Math.random() * 9000);
  return `CA-${clean || 'USER'}-${suffix}`;
}

export async function claimUniqueUsernameDoc(
  uid: string,
  newUsername: string,
  oldUsername?: string
): Promise<{ ok: boolean; error?: string }> {
  const clean = newUsername.replace(/[^\w\s-]/g, '').trim().slice(0, 32);
  if (clean.length < 2) return { ok: false, error: 'Username must be at least 2 characters.' };
  const lower = clean.toLowerCase().replace(/[^a-z0-9_]/g, '_');
  if (!auth.currentUser?.emailVerified) return { ok: true };

  try {
    const existing = await getDoc(doc(db, 'usernames', lower));
    if (existing.exists() && existing.data()?.uid !== uid) {
      return { ok: false, error: 'That username is already taken.' };
    }
    await setDoc(doc(db, 'usernames', lower), {
      usernameLower: lower,
      username: clean,
      uid,
      updatedAt: serverTimestamp(),
    });
    if (oldUsername) {
      const oldLower = oldUsername.toLowerCase().replace(/[^a-z0-9_]/g, '_');
      if (oldLower !== lower) {
        const oldDoc = await getDoc(doc(db, 'usernames', oldLower));
        if (oldDoc.exists() && oldDoc.data()?.uid === uid) {
          await deleteDoc(doc(db, 'usernames', oldLower)).catch(() => {});
        }
      }
    }
    return { ok: true };
  } catch (err) {
    console.warn('Username claim warning:', err);
    return { ok: true };
  }
}

export async function ensureUserProfile(
  uid: string,
  username: string,
  email: string
): Promise<UserProfile> {
  const userPath = `users/${uid}`;
  try {
    const snap = await getDoc(doc(db, 'users', uid));
    if (snap.exists()) {
      const data = snap.data();
      return {
        ...(data as UserProfile),
        createdAt: toIso(data.createdAt),
        updatedAt: toIso(data.updatedAt),
      };
    }

    const baseName = (username || 'GrandPlayer').replace(/[^\w\s-]/g, '').trim().slice(0, 26) || 'Player';
    let safeName = baseName;
    if (auth.currentUser?.emailVerified) {
      const lower = baseName.toLowerCase().replace(/[^a-z0-9_]/g, '_');
      const taken = await getDoc(doc(db, 'usernames', lower));
      if (taken.exists() && taken.data()?.uid !== uid) {
        safeName = `${baseName}_${uid.slice(-4).toUpperCase()}`.slice(0, 32);
      }
    }
    const playerId = generatePlayerId(uid);
    const payload = {
      uid,
      playerId,
      username: safeName,
      displayName: safeName,
      bio: '',
      country: 'Global',
      avatar: AVATAR_OPTIONS[0].url,
      chessExperience: 'Club Player',
      learningJourney: '',
      mentorName: '',
      favoritePlayer: '',
      favoriteOpening: 'Italian Game',
      profileTheme: 'obsidian_gold' as const,
      profileFrame: 'gold_laurel' as const,
      privacySections: {
        stats: true,
        matchHistory: true,
        achievements: true,
        learningJourney: true,
        friends: true,
        favoriteOpenings: true,
      },
      rating: 1200,
      peakRating: 1200,
      puzzleRating: 1200,
      puzzlesSolved: 0,
      xp: 0,
      level: 1,
      points: 100,
      wins: 0,
      losses: 0,
      draws: 0,
      winStreak: 0,
      bestWinStreak: 0,
      totalMoves: 0,
      fastestWinSeconds: 0,
      longestMatchSeconds: 0,
      totalMatchDurationSeconds: 0,
      isBanned: false,
      privacyAllowMessages: 'everyone' as const,
      privacyAllowInvites: 'everyone' as const,
      dailyLoginStreak: 1,
      lastDailyClaim: new Date().toISOString().slice(0, 10),
      lastUsernameChangeAt: '',
      achievements: [],
      following: [],
      blockedUids: [],
      completedVideos: [],
      favoriteVideos: [],
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    if (auth.currentUser?.emailVerified) {
      await setDoc(doc(db, 'users', uid), payload);
      await claimUniqueUsernameDoc(uid, safeName);
      await setDoc(doc(db, 'users', uid, 'private', 'info'), {
        uid,
        email: (email || 'player@chessarena.local').slice(0, 200),
        twoFactorEnabled: false,
        updatedAt: serverTimestamp(),
      });
    }

    return {
      ...payload,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, userPath);
  }
}

export async function updateUserProfileFields(
  uid: string,
  updates: Partial<UserProfile>
): Promise<void> {
  if (!auth.currentUser?.emailVerified) return;
  const path = `users/${uid}`;
  try {
    const allowed: Record<string, unknown> = {
      updatedAt: serverTimestamp(),
    };
    const whitelist = [
      'username',
      'displayName',
      'bio',
      'country',
      'avatar',
      'chessExperience',
      'learningJourney',
      'mentorName',
      'favoritePlayer',
      'favoriteOpening',
      'profileTheme',
      'profileFrame',
      'privacySections',
      'privacyAllowMessages',
      'privacyAllowInvites',
      'rating',
      'peakRating',
      'puzzleRating',
      'puzzlesSolved',
      'xp',
      'level',
      'points',
      'wins',
      'losses',
      'draws',
      'winStreak',
      'bestWinStreak',
      'totalMoves',
      'fastestWinSeconds',
      'longestMatchSeconds',
      'totalMatchDurationSeconds',
      'dailyLoginStreak',
      'lastDailyClaim',
      'lastUsernameChangeAt',
      'achievements',
      'following',
      'blockedUids',
      'completedVideos',
      'favoriteVideos',
    ] as const;

    for (const key of whitelist) {
      if (updates[key] !== undefined) {
        if (key === 'username') {
          allowed[key] = String(updates[key]).slice(0, 32);
        } else if (key === 'avatar') {
          const av = String(updates[key]);
          if (av.length <= 256) allowed[key] = av;
        } else if (Array.isArray(updates[key])) {
          allowed[key] = (updates[key] as string[]).slice(0, key === 'achievements' ? 50 : 200);
        } else {
          allowed[key] = updates[key];
        }
      }
    }
    await updateDoc(doc(db, 'users', uid), allowed);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function saveMatchRecordToFirestore(match: MatchRecord): Promise<void> {
  if (!auth.currentUser?.emailVerified) return;
  const path = `matches/${match.matchId}`;
  try {
    await setDoc(doc(db, 'matches', match.matchId), {
      matchId: match.matchId.slice(0, 128),
      whiteId: match.whiteId.slice(0, 128),
      whiteName: match.whiteName.slice(0, 64),
      whiteRating: match.whiteRating,
      blackId: match.blackId.slice(0, 128),
      blackName: match.blackName.slice(0, 64),
      blackRating: match.blackRating,
      pgn: match.pgn.slice(0, 20000),
      fen: match.fen.slice(0, 200),
      winner: match.winner,
      resultReason: match.resultReason.slice(0, 80),
      timeControl: match.timeControl.slice(0, 32),
      mode: match.mode,
      durationSeconds: Math.max(0, match.durationSeconds),
      moveCount: Math.max(0, match.moveCount),
      ratingDeltaWhite: match.ratingDeltaWhite,
      ratingDeltaBlack: match.ratingDeltaBlack,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function saveRoomChatToFirestore(
  roomId: string,
  msg: ChatMessage
): Promise<void> {
  if (!auth.currentUser?.emailVerified) return;
  const messageId = msg.id.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 128);
  if (!messageId) return;
  try {
    await setDoc(doc(db, 'room_chats', messageId), {
      messageId,
      roomId: roomId.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 128),
      senderUid: msg.senderId.slice(0, 128),
      senderName: msg.senderName.slice(0, 32),
      senderAvatar: (msg.senderAvatar || '').slice(0, 256),
      role: msg.role,
      channel: msg.channel === 'spectator' ? 'spectator' : 'room',
      text: msg.text.slice(0, 300),
      emoji: (msg.emoji || '').slice(0, 16),
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    console.warn('Room chat Firestore sync skipped:', err);
  }
}

export function subscribeRoomChatsFirestore(
  roomId: string,
  cb: (msgs: ChatMessage[]) => void
): () => void {
  if (!auth.currentUser) return () => {};
  const q = query(collection(db, 'room_chats'), where('roomId', '==', roomId), limit(100));
  return onSnapshot(
    q,
    (snap) => {
      const items: ChatMessage[] = snap.docs
        .map((d) => {
          const data = d.data();
          return {
            id: String(data.messageId || d.id),
            senderId: String(data.senderUid || ''),
            senderName: String(data.senderName || 'Player'),
            senderAvatar: data.senderAvatar ? String(data.senderAvatar) : undefined,
            role: (data.role as ChatMessage['role']) || 'player',
            channel: (data.channel as 'room' | 'spectator') || 'room',
            text: String(data.text || ''),
            emoji: data.emoji ? String(data.emoji) : undefined,
            timestamp: toIso(data.createdAt),
          };
        })
        .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      cb(items);
    },
    () => {}
  );
}

export async function fetchLeaderboardUsers(): Promise<UserProfile[]> {
  try {
    const q = query(
      collection(db, 'users'),
      where('isBanned', '==', false),
      orderBy('rating', 'desc'),
      limit(100)
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const data = d.data();
      return {
        ...(data as UserProfile),
        createdAt: toIso(data.createdAt),
        updatedAt: toIso(data.updatedAt),
      };
    });
  } catch (error) {
    console.warn('Leaderboard Firestore query fallback:', error);
    return [];
  }
}

export async function fetchUserMatches(uid: string): Promise<MatchRecord[]> {
  if (!auth.currentUser) return [];
  try {
    const qW = query(
      collection(db, 'matches'),
      where('whiteId', '==', uid),
      orderBy('createdAt', 'desc'),
      limit(25)
    );
    const qB = query(
      collection(db, 'matches'),
      where('blackId', '==', uid),
      orderBy('createdAt', 'desc'),
      limit(25)
    );
    const [sW, sB] = await Promise.all([getDocs(qW), getDocs(qB)]);
    const map = new Map<string, MatchRecord>();
    for (const d of [...sW.docs, ...sB.docs]) {
      const data = d.data();
      map.set(d.id, {
        ...(data as MatchRecord),
        createdAt: toIso(data.createdAt),
      });
    }
    return Array.from(map.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  } catch (error) {
    console.warn('Match history Firestore query fallback:', error);
    return [];
  }
}

export async function fetchLearningVideosFirestore(): Promise<LearningVideo[]> {
  try {
    const snap = await getDocs(collection(db, 'learning_videos'));
    return snap.docs.map((d) => {
      const data = d.data();
      return {
        ...(data as LearningVideo),
        createdAt: toIso(data.createdAt),
      };
    });
  } catch {
    return [];
  }
}

export async function sendFriendRequestDoc(
  fromUid: string,
  fromUsername: string,
  toUid: string,
  toUsername: string
): Promise<void> {
  if (!auth.currentUser?.emailVerified) return;
  const requestId = `fr_${fromUid}_${toUid}_${Date.now()}`.slice(0, 128);
  try {
    await setDoc(doc(db, 'friend_requests', requestId), {
      requestId,
      fromUid,
      fromUsername: fromUsername.slice(0, 32),
      toUid,
      toUsername: toUsername.slice(0, 32),
      status: 'pending',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `friend_requests/${requestId}`);
  }
}

export async function respondFriendRequestDoc(
  requestId: string,
  status: 'accepted' | 'declined' | 'blocked'
): Promise<void> {
  if (!auth.currentUser?.emailVerified) return;
  try {
    await updateDoc(doc(db, 'friend_requests', requestId), {
      status,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `friend_requests/${requestId}`);
  }
}

export function subscribeFriendRequests(
  uid: string,
  cb: (requests: FriendRequest[]) => void
): () => void {
  if (!auth.currentUser) return () => {};
  const qIn = query(collection(db, 'friend_requests'), where('toUid', '==', uid));
  const qOut = query(collection(db, 'friend_requests'), where('fromUid', '==', uid));
  let incoming: FriendRequest[] = [];
  let outgoing: FriendRequest[] = [];

  const emit = () => {
    const merged = new Map<string, FriendRequest>();
    for (const r of [...incoming, ...outgoing]) merged.set(r.requestId, r);
    cb(Array.from(merged.values()));
  };

  const u1 = onSnapshot(
    qIn,
    (snap) => {
      incoming = snap.docs.map((d) => ({
        ...(d.data() as FriendRequest),
        createdAt: toIso(d.data().createdAt),
        updatedAt: toIso(d.data().updatedAt),
      }));
      emit();
    },
    (err) => handleFirestoreError(err, OperationType.LIST, 'friend_requests')
  );

  const u2 = onSnapshot(
    qOut,
    (snap) => {
      outgoing = snap.docs.map((d) => ({
        ...(d.data() as FriendRequest),
        createdAt: toIso(d.data().createdAt),
        updatedAt: toIso(d.data().updatedAt),
      }));
      emit();
    },
    (err) => handleFirestoreError(err, OperationType.LIST, 'friend_requests')
  );

  return () => {
    u1();
    u2();
  };
}

export async function sendDirectMessageDoc(
  senderUid: string,
  recipientUid: string,
  text: string
): Promise<void> {
  if (!auth.currentUser?.emailVerified) return;
  const messageId = `msg_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  try {
    await setDoc(doc(db, 'messages', messageId), {
      messageId,
      senderUid,
      recipientUid,
      text: text.slice(0, 1000),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `messages/${messageId}`);
  }
}

export function subscribeDirectMessages(
  uid: string,
  cb: (messages: DirectMessage[]) => void
): () => void {
  if (!auth.currentUser) return () => {};
  const qSent = query(collection(db, 'messages'), where('senderUid', '==', uid), limit(50));
  const qRecv = query(collection(db, 'messages'), where('recipientUid', '==', uid), limit(50));
  let sent: DirectMessage[] = [];
  let recv: DirectMessage[] = [];

  const emit = () => {
    const merged = new Map<string, DirectMessage>();
    for (const m of [...sent, ...recv]) merged.set(m.messageId, m);
    cb(
      Array.from(merged.values()).sort(
        (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      )
    );
  };

  const u1 = onSnapshot(
    qSent,
    (snap) => {
      sent = snap.docs.map((d) => ({
        ...(d.data() as DirectMessage),
        createdAt: toIso(d.data().createdAt),
      }));
      emit();
    },
    (err) => handleFirestoreError(err, OperationType.LIST, 'messages')
  );

  const u2 = onSnapshot(
    qRecv,
    (snap) => {
      recv = snap.docs.map((d) => ({
        ...(d.data() as DirectMessage),
        createdAt: toIso(d.data().createdAt),
      }));
      emit();
    },
    (err) => handleFirestoreError(err, OperationType.LIST, 'messages')
  );

  return () => {
    u1();
    u2();
  };
}

export async function submitPlayerReportDoc(
  reporterUid: string,
  reportedPlayerId: string,
  reason: string,
  details: string
): Promise<void> {
  if (!auth.currentUser?.emailVerified) return;
  const reportId = `rep_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  try {
    await setDoc(doc(db, 'reports', reportId), {
      reportId,
      reporterUid,
      reportedPlayerId: reportedPlayerId.slice(0, 128),
      reason: reason.slice(0, 120),
      details: details.slice(0, 1000),
      status: 'open',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `reports/${reportId}`);
  }
}

export async function fetchActiveAnnouncementsFirestore(): Promise<Announcement[]> {
  try {
    const q = query(collection(db, 'announcements'), where('active', '==', true), limit(10));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({
      ...(d.data() as Announcement),
      createdAt: toIso(d.data().createdAt),
    }));
  } catch {
    return [];
  }
}

export async function fetchUiConfigFirestore(): Promise<Partial<AppUiConfig> | null> {
  try {
    const snap = await getDoc(doc(db, 'app_config', 'ui'));
    if (!snap.exists()) return null;
    return snap.data() as Partial<AppUiConfig>;
  } catch {
    return null;
  }
}

export type { Tournament, PlayerReport };
