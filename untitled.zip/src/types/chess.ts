export type PieceStyleId = 'staunton' | 'neo' | 'royal' | 'minimal';
export type BoardThemeId = 'classic_wood' | 'modern_marble' | 'midnight' | 'emerald' | 'golden' | 'minimal';

export type AIDifficultyId =
  | 'beginner'
  | 'easy'
  | 'medium'
  | 'hard'
  | 'expert'
  | 'master'
  | 'grandmaster';

export type AIPersonalityId = 'balanced' | 'tactician' | 'fortress' | 'endgame';

export type GameModeType = 'ai' | 'matchmaking' | 'friend' | 'private' | 'tournament' | 'offline';

export type TimeCategory = 'bullet' | 'blitz' | 'rapid' | 'classical' | 'custom' | 'untimed';

export interface TimeControlConfig {
  id: string;
  label: string;
  category: TimeCategory;
  initialSeconds: number;
  incrementSeconds: number;
}

export interface PrivacySections {
  stats: boolean;
  matchHistory: boolean;
  achievements: boolean;
  learningJourney: boolean;
  friends: boolean;
  favoriteOpenings: boolean;
}

export type ProfileThemeId = 'obsidian_gold' | 'royal_emerald' | 'midnight_sapphire' | 'crimson_grandmaster';
export type ProfileFrameId = 'none' | 'gold_laurel' | 'emerald_crest' | 'ivory_border';

export interface UserProfile {
  uid: string;
  playerId: string;
  username: string;
  displayName?: string;
  bio?: string;
  country: string;
  avatar: string;
  chessExperience?: string;
  learningJourney?: string;
  mentorName?: string;
  favoritePlayer?: string;
  favoriteOpening?: string;
  profileTheme?: ProfileThemeId;
  profileFrame?: ProfileFrameId;
  privacySections?: PrivacySections;
  rating: number;
  peakRating: number;
  puzzleRating: number;
  puzzlesSolved: number;
  xp: number;
  level: number;
  points: number;
  wins: number;
  losses: number;
  draws: number;
  winStreak: number;
  bestWinStreak: number;
  totalMoves: number;
  fastestWinSeconds: number;
  longestMatchSeconds: number;
  totalMatchDurationSeconds: number;
  isBanned: boolean;
  banReason?: string;
  privacyAllowMessages: 'everyone' | 'friends' | 'none';
  privacyAllowInvites: 'everyone' | 'friends' | 'none';
  dailyLoginStreak: number;
  lastDailyClaim: string;
  lastUsernameChangeAt?: string;
  achievements: string[];
  following?: string[];
  blockedUids?: string[];
  completedVideos?: string[];
  favoriteVideos?: string[];
  createdAt: string;
  updatedAt: string;
  isGuest?: boolean;
  online?: boolean;
  inGame?: boolean;
}

export interface MatchRecord {
  matchId: string;
  whiteId: string;
  whiteName: string;
  whiteRating: number;
  blackId: string;
  blackName: string;
  blackRating: number;
  pgn: string;
  fen: string;
  winner: 'white' | 'black' | 'draw';
  resultReason: string;
  timeControl: string;
  mode: GameModeType;
  durationSeconds: number;
  moveCount: number;
  ratingDeltaWhite: number;
  ratingDeltaBlack: number;
  createdAt: string;
  isOffline?: boolean;
  synced?: boolean;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  role: 'player' | 'spectator' | 'system';
  channel?: 'room' | 'spectator';
  text: string;
  timestamp: string;
  emoji?: string;
}

export interface RoomParticipant {
  uid: string;
  playerId: string;
  username: string;
  rating: number;
  country: string;
  avatar: string;
  role: 'player' | 'spectator';
  color?: 'w' | 'b';
  connected: boolean;
}

export interface PrivateRoomState {
  roomId: string;
  roomName: string;
  ownerId: string;
  ownerName: string;
  gameMode: string;
  timeControl: TimeControlConfig;
  maxSpectators: number;
  hasPassword: boolean;
  allowSpectatorChat: boolean;
  status: 'waiting' | 'playing' | 'finished' | 'closed';
  fen: string;
  pgn: string;
  turn: 'w' | 'b';
  whiteTimeMs: number;
  blackTimeMs: number;
  lastMoveAt: number | null;
  lastMove?: { from: string; to: string };
  winner?: 'white' | 'black' | 'draw';
  resultReason?: string;
  drawOfferFrom?: string | null;
  participants: RoomParticipant[];
  chat: ChatMessage[];
  elapsedSeconds: number;
  moveNumber: number;
  createdAt: string;
}

export interface LocalMatchSetup {
  difficulty: AIDifficultyId;
  personality: AIPersonalityId;
  playerSide: 'w' | 'b';
  timeControl: TimeControlConfig;
  practiceUndoEnabled: boolean;
}

export interface TournamentMatch {
  id: string;
  round: number;
  whiteUid?: string;
  whiteName: string;
  blackUid?: string;
  blackName: string;
  winnerUid?: string;
  status: 'pending' | 'active' | 'completed';
  roomId?: string;
}

export interface TournamentStanding {
  uid: string;
  username: string;
  rating: number;
  points: number;
  wins: number;
  draws: number;
  losses: number;
}

export interface Tournament {
  tournamentId: string;
  title: string;
  format: 'knockout' | 'round_robin';
  visibility: 'public' | 'private';
  status: 'registration' | 'active' | 'completed';
  timeControl: string;
  maxPlayers: number;
  createdBy: string;
  creatorName: string;
  participants: string[];
  participantDetails: { uid: string; username: string; rating: number; country: string }[];
  matches: TournamentMatch[];
  standings: TournamentStanding[];
  createdAt: string;
  updatedAt: string;
}

export interface PuzzleItem {
  id: string;
  title: string;
  theme: 'mate_in_1' | 'mate_in_2' | 'fork' | 'pin' | 'skewer' | 'endgame' | 'tactic';
  rating: number;
  fen: string;
  solution: string[]; // UCI e.g. ['e2e4', 'e7e5']
  explanation: string;
  isDaily?: boolean;
}

export interface OpeningLesson {
  id: string;
  name: string;
  eco: string;
  side: 'w' | 'b';
  difficulty: 'Beginner' | 'Intermediate' | 'Master';
  moves: string[]; // SAN moves
  description: string;
  keyIdeas: string[];
}

export type VideoCategory =
  | 'Beginner Chess Lessons'
  | 'Chess Rules Explained'
  | 'Opening Principles'
  | 'Tactical Puzzles'
  | 'Endgame Training'
  | 'Advanced Chess Strategies'
  | 'Grandmaster Lessons'
  | 'Chess Game Analysis'
  | 'Famous Chess Matches';

export interface LearningVideo {
  videoId: string;
  youtubeId?: string;
  playlistId?: string;
  title: string;
  description: string;
  category: VideoCategory;
  author: string;
  isPlaylist: boolean;
  createdAt: string;
}

export interface FriendRequest {
  requestId: string;
  fromUid: string;
  fromUsername: string;
  toUid: string;
  toUsername: string;
  status: 'pending' | 'accepted' | 'declined' | 'blocked';
  createdAt: string;
  updatedAt: string;
}

export interface DirectMessage {
  messageId: string;
  senderUid: string;
  recipientUid: string;
  text: string;
  createdAt: string;
}

export interface PlayerReport {
  reportId: string;
  reporterUid: string;
  reportedPlayerId: string;
  reportedUsername?: string;
  reason: string;
  details: string;
  status: 'open' | 'reviewed' | 'resolved' | 'dismissed';
  createdAt: string;
  updatedAt: string;
}

export interface Announcement {
  announcementId: string;
  title: string;
  body: string;
  active: boolean;
  createdAt: string;
}

export interface AppUiConfig {
  siteTitle: string;
  heroHeadline: string;
  heroSubtitle: string;
  heroImageUrl?: string;
  accentColor: string;
  canvasColor: string;
  surfaceColor: string;
  defaultBoardTheme: BoardThemeId;
  defaultPieceStyle: PieceStyleId;
  bannerText: string;
  dailyTip?: string;
  allowGuestPlay: boolean;
  maintenanceMode: boolean;
  showLeaderboards: boolean;
  showTournaments: boolean;
  showTraining: boolean;
  showPlayersDirectory?: boolean;
  navLabels?: {
    dashboard?: string;
    play?: string;
    players?: string;
    training?: string;
    tournaments?: string;
    leaderboards?: string;
  };
  buttonLabels?: {
    playWorldwide?: string;
    playComputer?: string;
    privateRoom?: string;
    dailyPuzzle?: string;
  };
  sectionOrder?: string[];
  updatedAt: string;
}

export interface UiVersionSnapshot {
  versionId: string;
  savedBy: string;
  label: string;
  config: AppUiConfig;
  createdAt: string;
}

export type AdminRole = 'super_admin' | 'moderator';

export interface ModeratorAccount {
  id: string;
  username: string;
  role: AdminRole;
  permissions: string[];
  createdAt: string;
  createdBy: string;
}

export interface AdminAuditLog {
  logId: string;
  actor: string;
  actorRole: AdminRole;
  action: string;
  target?: string;
  details?: string;
  createdAt: string;
}

export interface UserPreferences {
  colorMode: 'dark' | 'light';
  soundEnabled: boolean;
  notifyInvites: boolean;
  notifyMessages: boolean;
  notifyTournaments: boolean;
  highContrast: boolean;
  largeText: boolean;
  reducedMotion: boolean;
}

export interface MoveAnalysisItem {
  ply: number;
  moveSan: string;
  color: 'w' | 'b';
  evalBefore: number;
  evalAfter: number;
  centipawnLoss: number;
  classification: 'Best' | 'Good' | 'Inaccuracy' | 'Mistake' | 'Blunder';
  bestMoveSan?: string;
  fenBefore: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  body: string;
  type: 'info' | 'invite' | 'reward' | 'warning';
  timestamp: string;
  read: boolean;
  roomId?: string;
}
