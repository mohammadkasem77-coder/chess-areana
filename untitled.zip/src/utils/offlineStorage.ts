import { CHESS_PUZZLES } from '../data/trainingData';
import { MatchRecord, PuzzleItem } from '../types/chess';

const OFFLINE_MATCHES_KEY = 'chess_arena_offline_matches_v1';
const OFFLINE_PUZZLES_KEY = 'chess_arena_offline_puzzles_v1';
const OFFLINE_SOLVED_KEY = 'chess_arena_offline_solved_puzzles_v1';

export function saveOfflineMatch(match: MatchRecord): MatchRecord[] {
  const existing = getOfflineMatches();
  const updated = [{ ...match, isOffline: true, synced: false }, ...existing].slice(0, 100);
  try {
    localStorage.setItem(OFFLINE_MATCHES_KEY, JSON.stringify(updated));
  } catch {
    // Ignore storage quota issues gracefully
  }
  return updated;
}

export function getOfflineMatches(): MatchRecord[] {
  try {
    const raw = localStorage.getItem(OFFLINE_MATCHES_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as MatchRecord[];
  } catch {
    return [];
  }
}

export function markOfflineMatchesSynced(matchIds: string[]): MatchRecord[] {
  const existing = getOfflineMatches();
  const set = new Set(matchIds);
  const updated = existing.map((m) => (set.has(m.matchId) ? { ...m, synced: true } : m));
  try {
    localStorage.setItem(OFFLINE_MATCHES_KEY, JSON.stringify(updated));
  } catch {
    // Ignore
  }
  return updated;
}

export function downloadOfflinePuzzlePack(): PuzzleItem[] {
  try {
    localStorage.setItem(OFFLINE_PUZZLES_KEY, JSON.stringify(CHESS_PUZZLES));
  } catch {
    // Ignore
  }
  return CHESS_PUZZLES;
}

export function getDownloadedPuzzlePack(): PuzzleItem[] {
  try {
    const raw = localStorage.getItem(OFFLINE_PUZZLES_KEY);
    if (!raw) return CHESS_PUZZLES;
    return JSON.parse(raw) as PuzzleItem[];
  } catch {
    return CHESS_PUZZLES;
  }
}

export function isPuzzlePackDownloaded(): boolean {
  try {
    return !!localStorage.getItem(OFFLINE_PUZZLES_KEY);
  } catch {
    return false;
  }
}

export function recordOfflinePuzzleSolved(puzzleId: string): string[] {
  const existing = getSolvedPuzzleIds();
  if (!existing.includes(puzzleId)) {
    const next = [...existing, puzzleId];
    try {
      localStorage.setItem(OFFLINE_SOLVED_KEY, JSON.stringify(next));
    } catch {
      // Ignore
    }
    return next;
  }
  return existing;
}

export function getSolvedPuzzleIds(): string[] {
  try {
    const raw = localStorage.getItem(OFFLINE_SOLVED_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as string[];
  } catch {
    return [];
  }
}
